using Microsoft.Maui.ApplicationModel;
using Microsoft.Maui.Networking;
using Microsoft.Maui.Storage;

namespace CentrApp;

public partial class MainPage : ContentPage
{
    // Адрес вашего сайта. Меняется здесь, если домен другой.
    const string SiteUrl = "https://okp-center.gt.tc";

    bool _showingOffline;
    bool _loaded;

    public MainPage()
    {
        InitializeComponent();
        Connectivity.Current.ConnectivityChanged += OnConnectivityChanged;
    }

    protected override void OnAppearing()
    {
        base.OnAppearing();

        // Загружаем сайт один раз — при возврате в приложение страницу не перезагружаем.
        if (_loaded) return;
        _loaded = true;
        LoadAppropriate();
    }

    /// <summary>Появился интернет, а мы на офлайн-странице — сразу открываем сайт.</summary>
    void OnConnectivityChanged(object? sender, ConnectivityChangedEventArgs e)
    {
        if (e.NetworkAccess == NetworkAccess.Internet && _showingOffline)
        {
            MainThread.BeginInvokeOnMainThread(() =>
            {
                _showingOffline = false;
                Web.Source = SiteUrl;
            });
        }
    }

    void LoadAppropriate()
    {
        if (Connectivity.Current.NetworkAccess == NetworkAccess.Internet)
        {
            _showingOffline = false;
            Web.Source = SiteUrl;
        }
        else
        {
            // Открыли приложение без интернета — показываем страницу Центра, а не «динозаврика».
            _ = ShowOfflineAsync();
        }
    }

    async Task ShowOfflineAsync()
    {
        _showingOffline = true;
        try
        {
            using var stream = await FileSystem.OpenAppPackageFileAsync("offline.html");
            using var reader = new StreamReader(stream);
            var html = await reader.ReadToEndAsync();
            Web.Source = new HtmlWebViewSource { Html = html };
        }
        catch
        {
            Web.Source = new HtmlWebViewSource
            {
                Html = "<html><body style='background:#111b21;color:#e9edef;font-family:sans-serif;text-align:center;padding-top:40vh'>" +
                       "<h2>Нет подключения к интернету</h2></body></html>"
            };
        }
    }
}
