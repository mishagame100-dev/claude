using Android.Webkit;
using AWebView = Android.Webkit.WebView;

namespace CentrApp;

/// <summary>
/// Управляет поведением WebView:
///  • при ошибке загрузки главной страницы (нет интернета) показывает нашу offline.html,
///    а не системную страницу с «динозавриком»;
///  • после загрузки страницы отдаёт сайту пуш-токен через window.centrOnPushToken(...);
///  • ссылки на другие сайты открывает во внешнем браузере, наш сайт — внутри приложения.
/// </summary>
public class CentrWebViewClient : WebViewClient
{
    const string Domain = "okp-center.gt.tc";
    public const string OfflineAsset = "file:///android_asset/offline.html";

    public override bool ShouldOverrideUrlLoading(AWebView? view, IWebResourceRequest? request)
    {
        var url = request?.Url?.ToString();
        if (string.IsNullOrEmpty(url) || view is null)
            return false;

        // Служебная схема: сайт сообщает, какой чат сейчас открыт (для подавления
        // уведомлений об уже открытом чате). Ничего не грузим — только запоминаем.
        if (url.StartsWith("centrnative://", StringComparison.OrdinalIgnoreCase))
        {
            HandleNativeSignal(url);
            return true;
        }

        if (url.StartsWith("http://", StringComparison.OrdinalIgnoreCase) ||
            url.StartsWith("https://", StringComparison.OrdinalIgnoreCase))
        {
            // Наш сайт (в т.ч. ссылки на профили/группы) — грузим внутри приложения.
            if (url.Contains(Domain, StringComparison.OrdinalIgnoreCase))
                return false;

            // Любой другой сайт (ссылка из переписки, загрузка вложения и т.п.) — во внешний браузер.
            return OpenExternally(url);
        }

        // mailto:, tel:, intent: и прочее — тоже наружу.
        return OpenExternally(url);
    }

    public override void OnPageFinished(AWebView? view, string? url)
    {
        base.OnPageFinished(view, url);
        // Страница загрузилась — если токен уже есть, отдаём его сайту.
        PushManager.InjectTokenIfAvailable(view);
        // Помечаем страницу как «внутри приложения» и выполняем отложенные действия
        // (открыть чат по уведомлению, «Поделиться в Центр»).
        CentrWeb.OnPageFinished(view);
    }

    // Разбор centrnative://activechat/&lt;id&gt; (id может быть пустым = вышли из чата).
    static void HandleNativeSignal(string url)
    {
        try
        {
            var rest = url.Substring("centrnative://".Length);
            var parts = rest.Split('/', 2);
            var cmd = parts[0];
            var arg = parts.Length > 1 ? Android.Net.Uri.Decode(parts[1].TrimEnd('/')) : "";
            if (cmd.Equals("activechat", StringComparison.OrdinalIgnoreCase))
                AppState.ActiveChatId = string.IsNullOrEmpty(arg) ? null : arg;
        }
        catch { /* игнорируем некорректный сигнал */ }
    }

    public override void OnReceivedError(AWebView? view, IWebResourceRequest? request, WebResourceError? error)
    {
        // Ошибка загрузки именно главной страницы = нет интернета -> показываем страницу Центра.
        if (view is not null && request is not null && request.IsForMainFrame)
        {
            view.LoadUrl(OfflineAsset);
            return;
        }
        base.OnReceivedError(view, request, error);
    }

    static bool OpenExternally(string url)
    {
        try
        {
            var intent = new Android.Content.Intent(Android.Content.Intent.ActionView, Android.Net.Uri.Parse(url));
            intent.AddFlags(Android.Content.ActivityFlags.NewTask);
            Android.App.Application.Context.StartActivity(intent);
        }
        catch { /* нет приложения для такой ссылки — просто игнорируем */ }
        return true;
    }
}
