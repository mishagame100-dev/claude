/* ==========================================================================
 *  ЦЕНТР — КОНФИГУРАЦИЯ  (версия 4)
 *  --------------------------------------------------------------------------
 *  Замените два значения ниже на данные из вашего проекта Supabase:
 *  Dashboard -> Project Settings -> API
 *
 *    SUPABASE_URL      ->  "Project URL"      (напр. https://abcd.supabase.co)
 *    SUPABASE_ANON_KEY ->  ключ "anon public" (его безопасно держать в браузере;
 *                          он работает только вместе с Row Level Security)
 *
 *  Это ПУБЛИЧНЫЕ ключи — они предназначены для фронтенда.
 *  НИКОГДА не вставляйте сюда секретный ключ "service_role".
 * ========================================================================== */
window.CENTR_CONFIG = {
    SUPABASE_URL: "https://gweaxygzunzhaxhmwvoo.supabase.co",
    SUPABASE_ANON_KEY: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd3ZWF4eWd6dW56aGF4aG13dm9vIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODQwOTUxMDksImV4cCI6MjA5OTY3MTEwOX0.hwdYLwABpMc-yzISDJ7o4xbMNaasNLFoRhdbRyqlch0",

    // Публичный базовый URL сайта — используется для ссылок на профили/группы.
    // Оставьте пустым, чтобы определить автоматически из адреса в браузере.
    SITE_URL: "https://okp-center.gt.tc",

    // Имена бакетов хранилища (должны совпадать со schema.sql). Обычно не меняются.
    AVATAR_BUCKET: "avatars",
    MEDIA_BUCKET: "media",

    // Серверы ICE для звонков (WebRTC).
    //  • STUN бесплатные (Google) — хватает, когда хотя бы у одного нормальный NAT.
    //  • TURN НУЖЕН для мобильного интернета/симметричного NAT (иначе часть
    //    звонков не соединится). Свой бесплатный TURN можно поднять на Oracle Cloud
    //    Free Tier (coturn). Раскомментируйте и впишите адрес/логин/пароль:
    // Metered TURN (бесплатный 500 МБ/мес, БЕЗ карты).
    // Сайт сам запрашивает свежие TURN-данные по API-ключу перед звонком.
    // Где взять: dashboard.metered.ca → Developers → API Key.
    METERED_SUBDOMAIN: "okp-center",
    // ПУБЛИЧНЫЙ API Key со страницы TURN Server -> API Docs ("API Key for the credential").
    // Это НЕ "Secret Key" с вкладки Developers — тот нельзя держать во фронтенде.
    METERED_API_KEY: "e09433e4282a48e68a9167f6216425e600cf",

    // Резервные STUN (используются всегда; TURN добавляется автоматически из Metered).
    ICE_SERVERS: [
        { urls: "stun:stun.l.google.com:19302" },
        { urls: "stun:stun1.l.google.com:19302" }
    ],

    // Максимальный размер загружаемого файла в мегабайтах.
    //  • Бесплатный тариф Supabase имеет ЖЁСТКИЙ лимит платформы 50 МБ на файл —
    //    поднять его нельзя, только сжать видео или перейти на Pro.
    //  • На Pro можно поставить больше (до 50 ГБ) — тогда увеличьте это число
    //    И лимит бакета "media" в schema.sql (file_size_limit).
    MAX_UPLOAD_MB: 50
};
