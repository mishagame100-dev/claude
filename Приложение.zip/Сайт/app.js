/* ==========================================================================
 *  ЦЕНТР — ДВИЖОК ПРИЛОЖЕНИЯ  (чистый JS + Supabase JS v2)   ВЕРСИЯ 4
 *  --------------------------------------------------------------------------
 *  Что нового в v4 (исправления багов):
 *    • Загрузка больших файлов (видео с ПК) через возобновляемый протокол TUS
 *      кусками по 6 МБ + индикатор прогресса + понятная ошибка при превышении
 *      лимита. Раньше большой файл «висел» одним POST-запросом.
 *    • Плавная прокрутка к новым сообщениям. Сообщения теперь добавляются в DOM
 *      по одному (без полной перерисовки всего чата), поэтому лента больше не
 *      «дёргается» и не прыгает вверх; при получении сообщения она плавно
 *      опускается к нему.
 *    • Звук уведомления о новом входящем сообщении (Web Audio, без внешних
 *      файлов) + переключатель звука в шапке + вибрация на телефоне.
 *
 *  Разделы:
 *    0.  Инициализация клиента и глобальное состояние
 *    1.  Мелкие DOM / util-хелперы
 *    1b. Звук уведомлений + бейдж непрочитанных при прокрутке
 *    2.  Авторизация (вход / регистрация / сессия)
 *    3.  Профиль и онбординг (кроп аватара + загрузка, ID, ссылка)
 *    3b. Загрузка файлов в Storage (TUS + прогресс)
 *    4.  Кроппер аватара (зум + перемещение -> квадратный экспорт)
 *    5.  Список чатов (загрузка + отрисовка + realtime)
 *    6.  Активный чат (открытие / загрузка / отрисовка + закреплённое)
 *    7.  Композер: текст, медиа, запись голоса
 *    7b. Пересылка сообщений и закрепление/открепление
 *    8.  Галочки прочтения / доставки
 *    9.  Реакции, «удалить у всех», ответ, контекстное меню
 *   10.  Присутствие (в сети / был(а)) + «печатает…» (дебаунс 2 с)
 *   11.  Друзья (заявки, принятие, удаление, список)
 *   12.  Профиль собеседника / инфо контакта + инфо группы
 *   13.  Поиск (чаты + друзья + сообщения в чате)
 *   14.  Модалки (профиль / новый чат / группа / друг / пересылка / лайтбокс)
 *   15.  Диплинки (?u=handle, ?g=groupId)
 *   16.  Realtime-подписки
 *   17.  Мост пуш-уведомлений для нативной оболочки (MAUI)
 *   18.  Запуск
 * ========================================================================== */

/* ------------------------------------------------------------------ *
 *  0. ИНИЦИАЛИЗАЦИЯ КЛИЕНТА И ГЛОБАЛЬНОЕ СОСТОЯНИЕ
 * ------------------------------------------------------------------ */
const CFG = window.CENTR_CONFIG || {};
if (!CFG.SUPABASE_URL || CFG.SUPABASE_URL.includes("YOUR-PROJECT")) {
    alert("⚠️ Центр ещё не настроен.\n\nОткройте config.js и вставьте URL проекта Supabase и анонимный ключ (anon key).");
}
const sb = window.supabase.createClient(CFG.SUPABASE_URL, CFG.SUPABASE_ANON_KEY, {
    auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
    realtime: { params: { eventsPerSecond: 20 } }
});

// Запоминаем исходный hash сразу при загрузке: Supabase может его очистить, а нам нужно
// понять, что пользователь пришёл по ссылке «сброс пароля» / «смена почты».
const INITIAL_HASH = window.location.hash || "";

const REACTION_EMOJIS = ["👍", "❤️", "😂", "😮", "😢", "🙏"];

// Эмодзи разложены по категориям — так их МНОГО и в них легко ориентироваться.
// Верхний ряд пикера — вкладки категорий, ниже — сетка эмодзи выбранной вкладки.
const EMOJI_CATEGORIES = [
    { icon: "😀", name: "Смайлы", emojis: ["😀","😁","😂","🤣","😃","😄","😅","😆","😉","😊","😋","😎","😍","😘","🥰","😗","😙","😚","🙂","🙃","🫠","🤗","🤩","🤔","🫡","🤨","😐","😑","😶","🫥","😏","😒","🙄","😬","🤥","😌","😔","😪","🤤","😴","😷","🤒","🤕","🤢","🤮","🤧","🥵","🥶","🥴","😵","🤯","🤠","🥳","🥸","😇","🤓","🧐","😕","🫤","😟","🙁","☹️","😮","😯","😲","😳","🥺","🥹","😦","😧","😨","😰","😥","😢","😭","😱","😖","😣","😞","😓","😩","😫","🥱","😤","😡","😠","🤬","😈","👿","💀","☠️","💩","🤡","👹","👺","👻","👽","🤖","😺","😸","😹","😻","😼","😽","🙀","😿","😾"] },
    { icon: "👍", name: "Жесты", emojis: ["👍","👎","👌","🤌","🤏","✌️","🤞","🫰","🤟","🤘","🤙","👈","👉","👆","👇","☝️","🫵","👋","🤚","🖐️","✋","🖖","🫱","🫲","🫳","🫴","👏","🙌","👐","🤲","🤝","🙏","✍️","💅","🤳","💪","🦵","🦶","👂","🦻","👃","🧠","🫀","🫁","🦷","👀","👁️","👅","👄","🫦"] },
    { icon: "❤️", name: "Сердца", emojis: ["❤️","🧡","💛","💚","💙","💜","🖤","🤍","🤎","💔","❣️","💕","💞","💓","💗","💖","💘","💝","💟","♥️","💌","💋","😍","🥰","😘","💑","💏","🫶"] },
    { icon: "🐶", name: "Животные", emojis: ["🐶","🐱","🐭","🐹","🐰","🦊","🐻","🐼","🐨","🐯","🦁","🐮","🐷","🐽","🐸","🐵","🙈","🙉","🙊","🐒","🐔","🐧","🐦","🐤","🐣","🦆","🦅","🦉","🦇","🐺","🐗","🐴","🦄","🐝","🪲","🐛","🦋","🐌","🐞","🐜","🦗","🕷️","🦂","🐢","🐍","🦎","🦖","🐙","🦑","🦀","🐠","🐟","🐬","🐳","🐋","🦈","🐊","🐅","🐆","🦓","🦍","🐘","🦛","🐪","🐫","🦒","🐃","🐂","🐄","🐎","🐖","🐏","🐑","🐐","🦌","🐕","🐩","🐈","🐓","🦃","🕊️","🐇","🐿️","🦔"] },
    { icon: "🍔", name: "Еда", emojis: ["🍏","🍎","🍐","🍊","🍋","🍌","🍉","🍇","🍓","🫐","🍈","🍒","🍑","🥭","🍍","🥥","🥝","🍅","🍆","🥑","🥦","🥬","🥒","🌶️","🫑","🌽","🥕","🧄","🧅","🥔","🍠","🥐","🥯","🍞","🥖","🧀","🥚","🍳","🧈","🥞","🧇","🥓","🍗","🍖","🌭","🍔","🍟","🍕","🥪","🌮","🌯","🥙","🧆","🥗","🍝","🍜","🍲","🍛","🍣","🍱","🥟","🍤","🍙","🍚","🍘","🍥","🥠","🍢","🍡","🍧","🍨","🍦","🥧","🧁","🍰","🎂","🍮","🍭","🍬","🍫","🍿","🍩","🍪","🌰","🥜","☕","🍵","🧃","🥤","🧋","🍺","🍻","🥂","🍷","🥃","🍸","🍹","🍾"] },
    { icon: "⚽", name: "Активность", emojis: ["⚽","🏀","🏈","⚾","🥎","🎾","🏐","🏉","🥏","🎱","🪀","🏓","🏸","🏒","🏑","🥍","🏏","🥅","⛳","🪁","🏹","🎣","🤿","🥊","🥋","🎽","🛹","🛼","🛷","⛸️","🥌","🎿","⛷️","🏂","🏋️","🤼","🤸","⛹️","🤺","🤾","🏌️","🏇","🧘","🏄","🏊","🤽","🚣","🧗","🚴","🚵","🏆","🥇","🥈","🥉","🏅","🎖️","🎗️","🎫","🎟️","🎪","🎭","🎨","🎬","🎤","🎧","🎼","🎹","🥁","🎷","🎺","🎸","🪕","🎻","🎲","♟️","🎯","🎳","🎮","🎰"] },
    { icon: "✈️", name: "Путешествия", emojis: ["🚗","🚕","🚙","🚌","🚎","🏎️","🚓","🚑","🚒","🚐","🛻","🚚","🚛","🚜","🛵","🏍️","🛺","🚲","🛴","🚨","🚔","🚍","🚘","🚖","✈️","🛫","🛬","🛩️","🚁","🚀","🛸","⛵","🚤","🛥️","🛳️","⛴️","🚢","⚓","🚏","⛽","🚦","🚥","🗺️","🗿","🗽","🗼","🏰","🏯","🏟️","🎡","🎢","🎠","⛲","⛱️","🏖️","🏝️","🏔️","⛰️","🌋","🗻","🏕️","⛺","🏠","🏡","🏘️","🏙️","🌃","🌉","🌁","🌅","🌄","🌇","🌆","🌊"] },
    { icon: "💡", name: "Предметы", emojis: ["⌚","📱","💻","⌨️","🖥️","🖨️","🖱️","💽","💾","💿","📀","📷","📸","📹","🎥","📞","☎️","📟","📠","📺","📻","🧭","⏰","⏱️","⏲️","🕰️","💡","🔦","🕯️","🔋","🔌","🧰","🔧","🔨","🛠️","⚙️","🧲","🔫","💣","🧨","🔪","🗡️","🛡️","🚬","💊","💉","🩹","🌡️","🔬","🔭","📡","🧴","🧷","🧹","🧺","🧻","🚽","🚿","🛁","🧼","🪒","  ","🔑","🗝️","🚪","🛋️","🛏️","🖼️","🛍️","🎁","🎈","🎀","🎉","🎊","✉️","📩","📨","📧","📦","📚","📖","📝","✏️","🖊️","🖌️","🖍️","📌","📎","🔗","💰","💵","💳","💎"] },
    { icon: "🔣", name: "Символы", emojis: ["✅","❌","❎","➕","➖","➗","✖️","♾️","‼️","⁉️","❓","❔","❗","❕","〰️","💱","💲","   ️","♻️","⚜️","🔱","📛","🔰","⭕","✔️","☑️","🔘","⚪","⚫","🔴","🟠","🟡","🟢","🔵","🟣","🟤","🔺","🔻","🔸","🔹","🔶","🔷","🔳","🔲","▪️","▫️","◾","◽","◼️","◻️","🟥","🟧","🟨","🟩","🟦","🟪","🟫","⬛","⬜","💯","💢","💥","💫","💦","💨","🕳️","💬","💭","🗯️","♠️","♥️","♦️","♣️","🃏","🀄","⭐","🌟","✨","⚡","🔥","🌈","☀️","⛅","☁️","🌙","⏳","⌛"] },
];

const state = {
    user: null,          // auth user
    profile: null,       // мой профиль
    chats: [],           // [{chat, participants, other, lastMessage, unread, typing}]
    activeChatId: null,
    messages: [],        // сообщения активного чата (по возрастанию)
    profilesCache: {},   // userId -> profile
    reactionsByMsg: {},  // messageId -> [reaction rows]
    presence: {},        // userId -> bool online
    replyTo: null,       // сообщение, на которое отвечаем
    editing: null,       // сообщение, которое сейчас редактируем
    typingTimers: {},    // локальные таймеры показа «печатает…»
    searchTerm: "",
    channels: {},        // именованные realtime-каналы
    recorder: null,      // сессия MediaRecorder
    sidebarTab: "chats", // 'chats' | 'friends'
    friends: [],         // принятые друзья
    incoming: [],        // те, кто прислал МНЕ заявку
    outgoing: [],        // те, кому Я отправил заявку
    viewProfile: null,   // профиль в модалке
    pendingDeepLink: null,
    sharePayload: null,  // «Поделиться в Центр»: {kind:'text'|'image', ...}
    pendingShare: null,  // отложенный шэринг до входа в мессенджер
    pinnedIndex: 0,      // индекс показываемого закреплённого сообщения
    unseenCount: 0,      // сколько новых сообщений пришло, пока прокручено вверх
    soundEnabled: true,  // звук уведомлений
    call: null,          // активный звонок (WebRTC): {pc, stream, peerId, chatId, role...}
};

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/* ------------------------------------------------------------------ *
 *  1. DOM / UTIL ХЕЛПЕРЫ
 * ------------------------------------------------------------------ */
const $  = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const el = (id) => document.getElementById(id);

function show(node) { node && node.classList.remove("hidden"); }
function hide(node) { node && node.classList.add("hidden"); }

function esc(str = "") {
    return String(str)
        .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

// Превратить голые ссылки в кликабельные (после экранирования).
function linkify(text = "") {
    return esc(text).replace(/(https?:\/\/[^\s<]+)/g,
        '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>');
}

function initials(name = "?") {
    const parts = name.trim().split(/\s+/);
    if (parts.length === 1) return parts[0].slice(0, 2);
    return (parts[0][0] || "") + (parts[parts.length - 1][0] || "");
}

function toast(message, isError = false) {
    const wrap = el("toast-wrap");
    const t = document.createElement("div");
    t.className = "toast" + (isError ? " error" : "");
    t.textContent = message;
    wrap.appendChild(t);
    setTimeout(() => { t.style.opacity = "0"; t.style.transition = "opacity .3s"; }, 2600);
    setTimeout(() => t.remove(), 3000);
}

function fmtTime(iso) {
    const d = new Date(iso);
    return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
}

function fmtDay(iso) {
    const d = new Date(iso);
    const today = new Date();
    const yest = new Date(); yest.setDate(today.getDate() - 1);
    const same = (a, b) => a.toDateString() === b.toDateString();
    if (same(d, today)) return "Сегодня";
    if (same(d, yest)) return "Вчера";
    return d.toLocaleDateString("ru-RU", { day: "numeric", month: "long", year: d.getFullYear() === today.getFullYear() ? undefined : "numeric" });
}

function fmtLastSeen(iso) {
    if (!iso) return "был(а) недавно";
    const d = new Date(iso);
    const now = new Date();
    const diffMin = Math.round((now - d) / 60000);
    if (diffMin < 1) return "был(а) только что";
    if (diffMin < 60) return `был(а) ${diffMin} мин назад`;
    if (d.toDateString() === now.toDateString()) return `был(а) сегодня в ${fmtTime(iso)}`;
    const yest = new Date(now); yest.setDate(now.getDate() - 1);
    if (d.toDateString() === yest.toDateString()) return `был(а) вчера в ${fmtTime(iso)}`;
    return `был(а) ${d.toLocaleDateString("ru-RU", { day: "numeric", month: "short" })} в ${fmtTime(iso)}`;
}

function fmtDuration(sec) {
    sec = Math.max(0, Math.floor(sec || 0));
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}:${String(s).padStart(2, "0")}`;
}

// Русская форма слова «участник».
function pluralMembers(n) {
    const mod10 = n % 10, mod100 = n % 100;
    if (mod10 === 1 && mod100 !== 11) return "участник";
    if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return "участника";
    return "участников";
}

// Обрезать длинную строку до n символов и добавить многоточие. Нужно, чтобы
// длинная цитата в панели «Ответить»/«Редактирование» над полем ввода НЕ
// растягивала композер и кнопка «Отправить» не уезжала за экран на телефоне.
function clip(str, n = 48) {
    str = String(str || "").replace(/\s+/g, " ").trim();
    return str.length > n ? str.slice(0, n) + "…" : str;
}

function debounce(fn, wait) {
    let t;
    return function (...args) {
        clearTimeout(t);
        t = setTimeout(() => fn.apply(this, args), wait);
    };
}

// Отрисовать аватар в паре <img>/<fallback>.
function paintAvatar(imgEl, fallbackEl, url, name) {
    if (url) {
        imgEl.src = url;
        imgEl.style.display = "block";
        fallbackEl.style.display = "none";
    } else {
        imgEl.removeAttribute("src");
        imgEl.style.display = "none";
        fallbackEl.style.display = "flex";
        fallbackEl.textContent = initials(name || "?");
    }
}

function avatarHTML(url, name, cls = "sm") {
    if (url) {
        return `<span class="avatar ${cls}"><img src="${esc(url)}" alt=""></span>`;
    }
    return `<span class="avatar ${cls}"><span class="avatar-fallback">${esc(initials(name || "?"))}</span></span>`;
}

// ---- Ссылки для шаринга ------------------------------------------------------
function siteBase() {
    let b = (CFG.SITE_URL && CFG.SITE_URL.trim()) ? CFG.SITE_URL.trim() : location.origin;
    return b.replace(/\/+$/, "");
}
function profileLink(profile) {
    const key = (profile && profile.handle) ? profile.handle : (profile ? profile.id : "");
    return `${siteBase()}/?u=${encodeURIComponent(key)}`;
}
function groupLink(chatId) {
    return `${siteBase()}/?g=${encodeURIComponent(chatId)}`;
}
async function copyText(text) {
    try {
        if (navigator.clipboard && window.isSecureContext) {
            await navigator.clipboard.writeText(text);
        } else {
            const ta = document.createElement("textarea");
            ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
            document.body.appendChild(ta); ta.select();
            document.execCommand("copy"); ta.remove();
        }
        toast("Ссылка скопирована");
    } catch (_) {
        toast("Не удалось скопировать", true);
    }
}
function normalizeHandle(raw) {
    return String(raw || "").trim().replace(/^@+/, "").toLowerCase();
}
function validHandle(h) {
    return /^[a-z0-9_]{3,24}$/.test(h);
}
// Очистить поисковый запрос, чтобы он не сломал синтаксис фильтра `or=` в PostgREST.
function safeTerm(raw) {
    return String(raw || "").replace(/^@+/, "").replace(/[^\p{L}\p{N}_ ]/gu, "").trim();
}

/* ------------------------------------------------------------------ *
 *  1b. ЗВУК УВЕДОМЛЕНИЙ + БЕЙДЖ НЕПРОЧИТАННЫХ ПРИ ПРОКРУТКЕ
 * ------------------------------------------------------------------ */
let audioCtx = null;
let lastSoundAt = 0;

// Разблокировать/создать AudioContext (браузеры требуют жест пользователя).
function unlockAudio() {
    try {
        if (!audioCtx) {
            const AC = window.AudioContext || window.webkitAudioContext;
            if (!AC) return;
            audioCtx = new AC();
        }
        if (audioCtx.state === "suspended") audioCtx.resume();
    } catch (_) {}
}

// Короткий приятный «динь» из двух нот (без внешних аудиофайлов).
function playNotifySound() {
    if (!state.soundEnabled) return;
    try {
        unlockAudio();
        if (!audioCtx) return;
        const t0 = audioCtx.currentTime;
        const notes = [[0, 784], [0.11, 1047]]; // G5 -> C6
        notes.forEach(([off, freq]) => {
            const o = audioCtx.createOscillator();
            const g = audioCtx.createGain();
            o.type = "sine";
            o.frequency.value = freq;
            const s = t0 + off;
            g.gain.setValueAtTime(0.0001, s);
            g.gain.exponentialRampToValueAtTime(0.22, s + 0.02);
            g.gain.exponentialRampToValueAtTime(0.0001, s + 0.22);
            o.connect(g); g.connect(audioCtx.destination);
            o.start(s); o.stop(s + 0.24);
        });
    } catch (_) {}
}

// Реакция на входящее сообщение: звук (с антидребезгом) + вибрация в фоне.
function notifyIncoming() {
    const now = Date.now();
    if (state.soundEnabled && now - lastSoundAt > 700) {
        lastSoundAt = now;
        playNotifySound();
    }
    if (document.visibilityState === "hidden" && navigator.vibrate) {
        try { navigator.vibrate(120); } catch (_) {}
    }
}

function updateSoundBtn() {
    const btn = el("sound-toggle");
    if (!btn) return;
    btn.innerHTML = state.soundEnabled
        ? `<svg viewBox="0 0 24 24"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3A4.5 4.5 0 0014 7.97v8.05A4.5 4.5 0 0016.5 12zM14 3.23v2.06a7 7 0 010 13.42v2.06a9 9 0 000-17.54z"/></svg>`
        : `<svg viewBox="0 0 24 24"><path d="M3 9v6h4l5 5V4L7 9H3zm18.19 8.19L4.81 0.81 3.4 2.22l4.78 4.78L7 8H3v6h4l5 5v-6.61l4.78 4.78 1.41-1.41z" opacity=".55"/></svg>`;
    btn.title = state.soundEnabled ? "Звук уведомлений: вкл." : "Звук уведомлений: выкл.";
    btn.style.opacity = state.soundEnabled ? "1" : ".45";
}

function setupSound() {
    state.soundEnabled = localStorage.getItem("centr_sound") !== "0";
    updateSoundBtn();
    const btn = el("sound-toggle");
    if (btn) btn.addEventListener("click", () => {
        state.soundEnabled = !state.soundEnabled;
        localStorage.setItem("centr_sound", state.soundEnabled ? "1" : "0");
        updateSoundBtn();
        if (state.soundEnabled) { unlockAudio(); playNotifySound(); toast("Звук включён"); }
        else toast("Звук выключен");
    });
    // Разблокируем звук при первом же взаимодействии пользователя.
    const unlock = () => { unlockAudio(); document.removeEventListener("click", unlock); document.removeEventListener("keydown", unlock); };
    document.addEventListener("click", unlock);
    document.addEventListener("keydown", unlock);
}

function resetScrollBadge() {
    state.unseenCount = 0;
    const b = el("scroll-bottom-badge");
    if (b) { b.textContent = "0"; hide(b); }
}
function bumpScrollBadge() {
    state.unseenCount = (state.unseenCount || 0) + 1;
    const b = el("scroll-bottom-badge");
    if (b) { b.textContent = String(state.unseenCount); show(b); }
    show(el("scroll-bottom"));
}

/* ------------------------------------------------------------------ *
 *  2. АВТОРИЗАЦИЯ
 * ------------------------------------------------------------------ */

// Перевод типовых ошибок Supabase/сети на русский. Supabase присылает тексты
// и коды на английском («Invalid login credentials» и т.п.) — показываем их
// пользователю по-русски.
function authErrorRu(err) {
    const code = String(err && (err.code || err.error_code || "")).toLowerCase();
    const msg = String(err && err.message ? err.message : err || "").toLowerCase();
    const has = (s) => msg.includes(s);

    if (code === "invalid_credentials" || has("invalid login credentials"))
        return "Неверная почта или пароль.";
    if (code === "email_not_confirmed" || has("email not confirmed"))
        return "Почта не подтверждена. Откройте письмо от Центра и подтвердите адрес, затем войдите.";
    if (code === "user_already_exists" || has("already registered") || has("user already registered") || (has("already") && has("exist")))
        return "Аккаунт с такой почтой уже существует. Перейдите на вкладку «Вход».";
    if (code === "weak_password" || has("password should be at least") || (has("password") && has("least")))
        return "Пароль слишком короткий — минимум 6 символов.";
    if (code === "over_email_send_rate_limit" || has("rate limit") || has("for security purposes") || has("too many requests") || has("429"))
        return "Слишком много попыток. Подождите немного и попробуйте ещё раз.";
    if (has("unable to validate email") || has("invalid format") || (has("email") && has("invalid")))
        return "Неверный формат адреса почты.";
    if (has("signup is disabled") || has("signups not allowed"))
        return "Регистрация временно отключена.";
    if (has("password") && has("required"))
        return "Введите пароль.";
    if (has("email") && has("required"))
        return "Введите адрес почты.";
    // Сетевые сбои (нет интернета / не удалось достучаться до сервера).
    if (has("failed to fetch") || has("networkerror") || has("network error") || has("load failed") || has("fetch"))
        return "Нет соединения с сервером. Проверьте интернет и попробуйте снова.";
    // Иначе — оригинальный текст (если он есть), либо общий русский текст.
    return (err && err.message) ? err.message : "Что-то пошло не так. Попробуйте ещё раз.";
}

function switchAuthTab(which) {
    $$(".auth-tab").forEach(b => b.classList.toggle("active", b.dataset.authtab === which));
    el("login-form").classList.toggle("hidden", which !== "login");
    el("signup-form").classList.toggle("hidden", which !== "signup");
    hide(el("auth-error"));
}

function showAuthError(msg) {
    const box = el("auth-error");
    box.textContent = msg;
    show(box);
}

async function handleSignup(e) {
    e.preventDefault();
    const username = el("signup-username").value.trim();
    const email    = el("signup-email").value.trim();
    const password = el("signup-password").value;
    hide(el("auth-error"));
    const btn = e.target.querySelector("button[type=submit]");
    btn.disabled = true; btn.textContent = "Создаём…";
    try {
        const { data, error } = await sb.auth.signUp({
            email, password,
            options: { data: { username }, emailRedirectTo: siteBase() }
        });
        if (error) throw error;
        if (!data.session) {
            toast("Проверьте почту и подтвердите аккаунт, затем войдите.");
            switchAuthTab("login");
        }
        // onAuthStateChange сделает остальное, когда появится сессия.
    } catch (err) {
        showAuthError(authErrorRu(err));
    } finally {
        btn.disabled = false; btn.textContent = "Создать аккаунт";
    }
}

async function handleLogin(e) {
    e.preventDefault();
    const email    = el("login-email").value.trim();
    const password = el("login-password").value;
    hide(el("auth-error"));
    const btn = e.target.querySelector("button[type=submit]");
    btn.disabled = true; btn.textContent = "Входим…";
    try {
        const { error } = await sb.auth.signInWithPassword({ email, password });
        if (error) throw error;
    } catch (err) {
        showAuthError(authErrorRu(err));
    } finally {
        btn.disabled = false; btn.textContent = "Войти";
    }
}

async function handleLogout() {
    try { await setOffline(); } catch (_) {}
    teardownRealtime();
    await sb.auth.signOut();
    location.href = siteBase();
}

/* ------------------------------------------------------------------ *
 *  2б. ВОССТАНОВЛЕНИЕ / СМЕНА ПАРОЛЯ И ПОЧТЫ (всё через письма)
 * ------------------------------------------------------------------ */
function showRecoveryError(msg) {
    const box = el("recovery-error");
    box.textContent = msg; show(box);
}

function showRecoveryScreen() {
    hide(el("splash")); hide(el("auth-screen")); hide(el("onboarding-screen")); hide(el("messenger"));
    show(el("recovery-screen"));
}

function setupAccountSecurity() {
    // Небольшой хелпер: вешаем обработчик только если элемент есть —
    // чтобы отсутствие одной кнопки не ломало всю остальную логику.
    const on = (id, evt, fn) => { const n = el(id); if (n) n.addEventListener(evt, fn); };

    // «Забыли пароль?» на экране входа.
    on("forgot-password-link", "click", () => {
        el("forgot-email").value = el("login-email").value.trim();
        hide(el("auth-error"));
        openModal("forgot-modal");
    });

    // Отправка письма со ссылкой для сброса пароля.
    on("forgot-send", "click", async () => {
        const btn = el("forgot-send");
        const email = el("forgot-email").value.trim();
        if (!email) { toast("Введите почту", true); return; }
        btn.disabled = true; btn.textContent = "Отправляем…";
        try {
            const { error } = await sb.auth.resetPasswordForEmail(email, { redirectTo: siteBase() });
            if (error) throw error;
            closeModal("forgot-modal");
            toast("Письмо со ссылкой отправлено. Проверьте почту.");
        } catch (err) {
            toast(authErrorRu(err), true);
        } finally {
            btn.disabled = false; btn.textContent = "Отправить ссылку";
        }
    });

    // «Сменить пароль» в настройках (уже вошли) — тоже через письмо.
    on("change-password-btn", "click", async () => {
        const btn = el("change-password-btn");
        const email = state.user?.email;
        if (!email) { toast("Не удалось определить почту", true); return; }
        btn.disabled = true; btn.textContent = "Отправляем…";
        try {
            const { error } = await sb.auth.resetPasswordForEmail(email, { redirectTo: siteBase() });
            if (error) throw error;
            toast("Ссылка для смены пароля отправлена на вашу почту.");
        } catch (err) {
            toast(authErrorRu(err), true);
        } finally {
            btn.disabled = false; btn.textContent = "Сменить пароль";
        }
    });

    // «Сменить почту».
    on("change-email-btn", "click", () => {
        el("new-email").value = "";
        openModal("email-modal");
    });
    on("email-send", "click", async () => {
        const btn = el("email-send");
        const newEmail = el("new-email").value.trim();
        if (!newEmail) { toast("Введите новую почту", true); return; }
        btn.disabled = true; btn.textContent = "Отправляем…";
        try {
            const { error } = await sb.auth.updateUser({ email: newEmail }, { emailRedirectTo: siteBase() });
            if (error) throw error;
            closeModal("email-modal");
            toast("Письмо отправлено на новый адрес. Подтвердите его, чтобы сменить почту.");
        } catch (err) {
            toast(authErrorRu(err), true);
        } finally {
            btn.disabled = false; btn.textContent = "Отправить подтверждение";
        }
    });

    // Экран установки нового пароля (после перехода по ссылке из письма).
    on("recovery-form", "submit", async (e) => {
        e.preventDefault();
        hide(el("recovery-error"));
        const p1 = el("recovery-password").value;
        const p2 = el("recovery-password2").value;
        if (p1.length < 6) { showRecoveryError("Пароль слишком короткий — минимум 6 символов."); return; }
        if (p1 !== p2) { showRecoveryError("Пароли не совпадают."); return; }
        const btn = e.target.querySelector("button[type=submit]");
        btn.disabled = true; btn.textContent = "Сохраняем…";
        try {
            const { error } = await sb.auth.updateUser({ password: p1 });
            if (error) throw error;
            state.recoveryMode = false;
            toast("Пароль обновлён.");
            // Чистый переход на главную сайта (сбрасываем hash с токенами).
            setTimeout(() => { location.href = siteBase() + "/"; }, 700);
            return;
        } catch (err) {
            showRecoveryError(authErrorRu(err));
        } finally {
            btn.disabled = false; btn.textContent = "Сохранить пароль";
        }
    });
}

/* ------------------------------------------------------------------ *
 *  3. ПРОФИЛЬ И ОНБОРДИНГ
 * ------------------------------------------------------------------ */
async function loadMyProfile() {
    const { data, error } = await sb.from("profiles").select("*").eq("id", state.user.id).maybeSingle();
    if (error) { console.error(error); return null; }
    if (data) { state.profile = data; state.profilesCache[data.id] = data; }
    return data;
}

let onboardAvatarFile = null;
function setupOnboardingAvatarPreview() {
    el("onboard-avatar-input").addEventListener("change", async (e) => {
        const file = e.target.files[0];
        e.target.value = "";
        if (!file) return;
        const cropped = await openCropper(file);
        if (!cropped) return;
        onboardAvatarFile = cropped;
        el("onboard-avatar-preview").innerHTML = `<img src="${URL.createObjectURL(cropped)}" alt="">`;
    });
}

async function handleOnboarding(e) {
    e.preventDefault();
    const username = el("onboard-username").value.trim();
    const status   = el("onboard-status").value.trim() || "Привет! Я в Центре.";
    const btn = e.target.querySelector("button[type=submit]");
    btn.disabled = true; btn.textContent = "Сохраняем…";
    hide(el("onboard-error"));
    try {
        let avatar_url = state.profile?.avatar_url || null;
        if (onboardAvatarFile) {
            avatar_url = await uploadToBucket(CFG.AVATAR_BUCKET, onboardAvatarFile, state.user.id);
        }
        const { data, error } = await sb.from("profiles")
            .update({ username, status_text: status, avatar_url })
            .eq("id", state.user.id).select().single();
        if (error) throw error;
        state.profile = data;
        state.profilesCache[data.id] = data;
        localStorage.setItem("centr_onboarded_" + state.user.id, "1");
        enterMessenger();
    } catch (err) {
        const box = el("onboard-error");
        box.textContent = err.message?.includes("duplicate") ? "Это имя уже занято." : authErrorRu(err);
        show(box);
    } finally {
        btn.disabled = false; btn.textContent = "Начать общение";
    }
}

function paintMyAvatar() {
    paintAvatar(el("my-avatar-img"), el("my-avatar-fallback"), state.profile?.avatar_url, state.profile?.username);
}

/* ---- Превью мелодии звонка (файлы лежат на сайте в /sounds/<id>.mp3) ---- */
let __ringtonePreviewAudio = null;
function playRingtonePreview(id) {
    try {
        if (__ringtonePreviewAudio) { __ringtonePreviewAudio.pause(); __ringtonePreviewAudio = null; }
        const base = (CFG.SITE_URL || "").replace(/\/$/, "");
        __ringtonePreviewAudio = new Audio(base + "/sounds/" + (id || "center") + ".mp3");
        __ringtonePreviewAudio.play().catch(function(){});
    } catch (_) {}
}

/* ---- Модалка редактирования профиля ---- */
let profileAvatarFile = null;
function openProfileModal() {
    profileAvatarFile = null;
    el("profile-username").value = state.profile?.username || "";
    el("profile-handle").value = state.profile?.handle || "";
    el("profile-status").value = state.profile?.status_text || "";
    el("profile-link").value = profileLink(state.profile);
    el("profile-email").value = state.user?.email || "";
    if (el("profile-ringtone")) el("profile-ringtone").value = state.profile?.ringtone || localStorage.getItem("centr_ringtone") || "center";
    const prev = el("profile-avatar-preview");
    prev.innerHTML = state.profile?.avatar_url
        ? `<img src="${esc(state.profile.avatar_url)}" alt="">`
        : `<span class="avatar-upload-plus">📷</span>`;
    openModal("profile-modal");
}

function setupProfileModal() {
    el("profile-avatar-input").addEventListener("change", async (e) => {
        const file = e.target.files[0];
        e.target.value = "";
        if (!file) return;
        const cropped = await openCropper(file);
        if (!cropped) return;
        profileAvatarFile = cropped;
        el("profile-avatar-preview").innerHTML = `<img src="${URL.createObjectURL(cropped)}" alt="">`;
    });

    el("profile-copy").addEventListener("click", () => copyText(el("profile-link").value));

    const ringtonePreviewBtn = el("ringtone-preview");
    if (ringtonePreviewBtn) ringtonePreviewBtn.addEventListener("click", () => playRingtonePreview(el("profile-ringtone").value || "center"));
    if (el("profile-ringtone")) el("profile-ringtone").addEventListener("change", () => playRingtonePreview(el("profile-ringtone").value || "center"));

    el("profile-save").addEventListener("click", async () => {
        const btn = el("profile-save");
        const username = el("profile-username").value.trim();
        const handleRaw = normalizeHandle(el("profile-handle").value);
        const status = el("profile-status").value.trim();

        if (username.length < 3) { toast("Имя слишком короткое", true); return; }
        if (handleRaw && !validHandle(handleRaw)) {
            toast("ID: 3–24 символа, латиница/цифры/_", true);
            return;
        }

        btn.disabled = true; btn.textContent = "Сохраняем…";
        try {
            let avatar_url = state.profile?.avatar_url || null;
            if (profileAvatarFile) avatar_url = await uploadToBucket(CFG.AVATAR_BUCKET, profileAvatarFile, state.user.id);
            const patch = { username, status_text: status, avatar_url };
            if (handleRaw) patch.handle = handleRaw;
            const { data, error } = await sb.from("profiles").update(patch)
                .eq("id", state.user.id).select().single();
            if (error) throw error;
            state.profile = data;
            state.profilesCache[data.id] = data;
            try {
                const ringtone = el("profile-ringtone") ? (el("profile-ringtone").value || "center") : "center";
                localStorage.setItem("centr_ringtone", ringtone);
                if (state.profile.ringtone !== ringtone) {
                    const rr = await sb.from("profiles").update({ ringtone }).eq("id", state.user.id).select().single();
                    if (!rr.error && rr.data) { state.profile = rr.data; state.profilesCache[rr.data.id] = rr.data; }
                }
            } catch (_) {}
            paintMyAvatar();
            closeModal("profile-modal");
            toast("Профиль обновлён");
            renderChatList();
        } catch (err) {
            const msg = String(err.message || "");
            if (msg.includes("profiles_handle_key") || (msg.includes("duplicate") && msg.includes("handle"))) {
                toast("Этот ID уже занят", true);
            } else if (msg.includes("duplicate") || msg.includes("profiles_username_key")) {
                toast("Имя уже занято", true);
            } else {
                toast("Не удалось обновить профиль", true);
            }
        } finally {
            btn.disabled = false; btn.textContent = "Сохранить";
        }
    });
}

/* ------------------------------------------------------------------ *
 *  3b. ЗАГРУЗКА ФАЙЛОВ В STORAGE  (TUS для больших файлов + прогресс)
 *      Почему так: обычный .upload() отправляет файл ОДНИМ POST-запросом.
 *      Для больших видео с ПК это медленно и часто «висит» (обрыв —
 *      и всё сначала). TUS грузит кусками по 6 МБ, умеет докачивать и
 *      сообщает прогресс. Мелкие файлы грузим обычным способом.
 * ------------------------------------------------------------------ */
function fileExt(file) {
    if (file.name && file.name.includes(".")) return file.name.split(".").pop();
    if (file.type && file.type.includes("/")) return file.type.split("/")[1];
    return "bin";
}

async function uploadToBucket(bucket, file, folder, onProgress) {
    const ext = fileExt(file);
    const path = `${folder}/${Date.now()}_${Math.random().toString(36).slice(2, 8)}.${ext}`;
    const RESUMABLE_MIN = 6 * 1024 * 1024; // 6 МБ

    if (window.tus && file.size > RESUMABLE_MIN) {
        await tusUpload(bucket, path, file, onProgress);
    } else {
        if (onProgress) onProgress(0.05);
        const { error } = await sb.storage.from(bucket).upload(path, file, {
            cacheControl: "3600", upsert: false, contentType: file.type || undefined
        });
        if (error) throw error;
        if (onProgress) onProgress(1);
    }
    const { data } = sb.storage.from(bucket).getPublicUrl(path);
    return data.publicUrl;
}

// Возобновляемая загрузка через TUS-эндпоинт Supabase Storage.
function tusUpload(bucket, path, file, onProgress) {
    return new Promise(async (resolve, reject) => {
        let token = null;
        try {
            const { data } = await sb.auth.getSession();
            token = data && data.session ? data.session.access_token : null;
        } catch (_) {}
        if (!token) { reject(new Error("Нет активной сессии для загрузки")); return; }

        const endpoint = `${String(CFG.SUPABASE_URL).replace(/\/+$/, "")}/storage/v1/upload/resumable`;
        const upload = new window.tus.Upload(file, {
            endpoint,
            retryDelays: [0, 1000, 3000, 5000, 10000],
            headers: { authorization: `Bearer ${token}`, "x-upsert": "true" },
            uploadDataDuringCreation: true,
            removeFingerprintOnSuccess: true,
            chunkSize: 6 * 1024 * 1024,   // ВАЖНО: Supabase требует ровно 6 МБ
            metadata: {
                bucketName: bucket,
                objectName: path,
                contentType: file.type || "application/octet-stream",
                cacheControl: "3600"
            },
            onError: (err) => reject(err),
            onProgress: (uploaded, total) => { if (onProgress && total) onProgress(uploaded / total); },
            onSuccess: () => resolve()
        });

        upload.findPreviousUploads()
            .then((prev) => { if (prev && prev.length) upload.resumeFromPreviousUpload(prev[0]); upload.start(); })
            .catch(() => upload.start());
    });
}

// Плавающий индикатор прогресса загрузки (создаётся динамически).
function showUploadProgress(label) {
    const wrap = el("toast-wrap");
    const node = document.createElement("div");
    node.className = "toast upload-toast";
    node.innerHTML = `<div class="ut-label"><span class="ut-text">${esc(label)}</span> <span class="ut-pct">0%</span></div>
                      <div class="ut-bar"><span></span></div>`;
    wrap.appendChild(node);
    const pctEl = node.querySelector(".ut-pct");
    const barEl = node.querySelector(".ut-bar > span");
    let done = false;
    return {
        update(p) {
            const pct = Math.max(0, Math.min(100, Math.round((p || 0) * 100)));
            pctEl.textContent = pct + "%";
            barEl.style.width = pct + "%";
        },
        finish() {
            if (done) return; done = true;
            pctEl.textContent = "100%"; barEl.style.width = "100%";
            setTimeout(() => { node.style.opacity = "0"; node.style.transition = "opacity .3s"; }, 250);
            setTimeout(() => node.remove(), 650);
        },
        fail() {
            if (done) return; done = true;
            node.classList.add("error");
            node.querySelector(".ut-text").textContent = "Ошибка загрузки";
            setTimeout(() => { node.style.opacity = "0"; node.style.transition = "opacity .3s"; }, 1600);
            setTimeout(() => node.remove(), 2100);
        }
    };
}

/* ------------------------------------------------------------------ *
 *  4. КРОППЕР АВАТАРА (зум + перемещение)
 *     Возвращает Promise<File|null> с квадратным JPEG-кропом.
 * ------------------------------------------------------------------ */
let cropState = null;

function openCropper(file) {
    return new Promise((resolve) => {
        const img = el("cropper-img");
        const url = URL.createObjectURL(file);
        cropState = { resolve, url, active: false, dragging: false };

        openModal("cropper-modal");
        el("cropper-zoom").value = 1;

        img.onload = () => {
            requestAnimationFrame(() => {
                const stage = el("cropper-stage");
                const size = stage.clientWidth || 300;
                cropState.natW = img.naturalWidth;
                cropState.natH = img.naturalHeight;
                cropState.size = size;
                cropState.baseScale = Math.max(size / cropState.natW, size / cropState.natH);
                cropState.scale = cropState.baseScale;
                cropState.tx = (size - cropState.natW * cropState.scale) / 2;
                cropState.ty = (size - cropState.natH * cropState.scale) / 2;
                cropState.active = true;
                cropperPaint();
                el("cropper-zoom").value = 1;
            });
        };
        img.src = url;
    });
}

function cropperPaint() {
    const c = cropState; if (!c) return;
    const dw = c.natW * c.scale, dh = c.natH * c.scale;
    c.tx = Math.min(0, Math.max(c.size - dw, c.tx));
    c.ty = Math.min(0, Math.max(c.size - dh, c.ty));
    el("cropper-img").style.transform = `translate(${c.tx}px, ${c.ty}px) scale(${c.scale})`;
}

function cropperZoomTo(newScale, ax, ay) {
    const c = cropState; if (!c) return;
    ax = (ax == null) ? c.size / 2 : ax;
    ay = (ay == null) ? c.size / 2 : ay;
    newScale = Math.max(c.baseScale, Math.min(c.baseScale * 4, newScale));
    const ix = (ax - c.tx) / c.scale;
    const iy = (ay - c.ty) / c.scale;
    c.scale = newScale;
    c.tx = ax - ix * c.scale;
    c.ty = ay - iy * c.scale;
    cropperPaint();
    el("cropper-zoom").value = (c.scale / c.baseScale).toFixed(2);
}

function closeCropper(result) {
    const c = cropState;
    hide(el("cropper-modal"));
    if (c) {
        try { URL.revokeObjectURL(c.url); } catch (_) {}
        const res = c.resolve; cropState = null;
        res && res(result || null);
    }
}

function cropperExport() {
    const c = cropState;
    return new Promise((resolve) => {
        const out = 512;
        const canvas = document.createElement("canvas");
        canvas.width = out; canvas.height = out;
        const ctx = canvas.getContext("2d");
        const sSize = c.size / c.scale;
        const sx = -c.tx / c.scale;
        const sy = -c.ty / c.scale;
        try {
            ctx.drawImage(el("cropper-img"), sx, sy, sSize, sSize, 0, 0, out, out);
        } catch (_) {}
        canvas.toBlob((blob) => {
            const f = new File([blob], `avatar_${Date.now()}.jpg`, { type: "image/jpeg" });
            resolve(f);
        }, "image/jpeg", 0.9);
    });
}

function setupCropper() {
    const stage = el("cropper-stage");

    el("cropper-zoom").addEventListener("input", (e) => {
        if (!cropState) return;
        cropperZoomTo(cropState.baseScale * parseFloat(e.target.value));
    });

    stage.addEventListener("wheel", (e) => {
        if (!cropState || !cropState.active) return;
        e.preventDefault();
        const rect = stage.getBoundingClientRect();
        const factor = e.deltaY < 0 ? 1.08 : 0.92;
        cropperZoomTo(cropState.scale * factor, e.clientX - rect.left, e.clientY - rect.top);
    }, { passive: false });

    const start = (x, y) => {
        if (!cropState || !cropState.active) return;
        cropState.dragging = true;
        cropState.sx = x; cropState.sy = y;
        cropState.stx = cropState.tx; cropState.sty = cropState.ty;
        stage.classList.add("grabbing");
    };
    const move = (x, y) => {
        const c = cropState;
        if (!c || !c.dragging) return;
        c.tx = c.stx + (x - c.sx);
        c.ty = c.sty + (y - c.sy);
        cropperPaint();
    };
    const end = () => { if (cropState) cropState.dragging = false; stage.classList.remove("grabbing"); };

    stage.addEventListener("mousedown", (e) => { e.preventDefault(); start(e.clientX, e.clientY); });
    window.addEventListener("mousemove", (e) => move(e.clientX, e.clientY));
    window.addEventListener("mouseup", end);

    stage.addEventListener("touchstart", (e) => { const t = e.touches[0]; start(t.clientX, t.clientY); }, { passive: true });
    stage.addEventListener("touchmove", (e) => {
        if (!cropState) return;
        if (e.touches.length === 2) {
            // щипок для зума
            const [a, b] = e.touches;
            const dist = Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
            const rect = stage.getBoundingClientRect();
            const mx = (a.clientX + b.clientX) / 2 - rect.left;
            const my = (a.clientY + b.clientY) / 2 - rect.top;
            if (cropState.pinch) {
                cropperZoomTo(cropState.scale * (dist / cropState.pinch), mx, my);
            }
            cropState.pinch = dist;
            cropState.dragging = false;
            e.preventDefault();
        } else {
            const t = e.touches[0];
            move(t.clientX, t.clientY);
        }
    }, { passive: false });
    stage.addEventListener("touchend", () => { end(); if (cropState) cropState.pinch = null; });

    el("cropper-apply").addEventListener("click", async () => {
        if (!cropState) return;
        const file = await cropperExport();
        closeCropper(file);
    });
    el("cropper-cancel").addEventListener("click", () => closeCropper(null));
    el("cropper-cancel-2").addEventListener("click", () => closeCropper(null));
}

/* ------------------------------------------------------------------ *
 *  5. СПИСОК ЧАТОВ
 * ------------------------------------------------------------------ */
async function cacheProfiles(ids) {
    const missing = [...new Set(ids)].filter(id => id && !state.profilesCache[id]);
    if (!missing.length) return;
    const { data } = await sb.from("profiles").select("*").in("id", missing);
    (data || []).forEach(p => { state.profilesCache[p.id] = p; });
}

// Построить полную модель чатов для сайдбара.
async function loadChats() {
    const { data: myParts, error: pErr } = await sb.from("chat_participants")
        .select("chat_id").eq("user_id", state.user.id);
    if (pErr) { console.error(pErr); return; }
    const chatIds = (myParts || []).map(r => r.chat_id);
    if (!chatIds.length) { state.chats = []; state.chatsLoaded = true; renderChatList(); saveChatsCache(); return; }

    const { data: chatRows } = await sb.from("chats").select("*").in("id", chatIds);
    const { data: allParts } = await sb.from("chat_participants").select("*").in("chat_id", chatIds);
    await cacheProfiles((allParts || []).map(p => p.user_id));

    // Последнее сообщение и число непрочитанных тянем для всех чатов параллельно — так намного быстрее.
    const chats = await Promise.all((chatRows || []).map(async (chat) => {
        const participants = (allParts || []).filter(p => p.chat_id === chat.id);
        const otherPart = participants.find(p => p.user_id !== state.user.id);
        const other = otherPart ? state.profilesCache[otherPart.user_id] : null;

        const [{ data: lastArr }, { count }] = await Promise.all([
            sb.from("messages").select("*").eq("chat_id", chat.id).order("created_at", { ascending: false }).limit(1),
            sb.from("messages").select("id", { count: "exact", head: true }).eq("chat_id", chat.id).eq("is_read", false).neq("sender_id", state.user.id),
        ]);
        const lastMessage = (lastArr || [])[0] || null;
        return { chat, participants, other, lastMessage, unread: count || 0, typing: null };
    }));

    chats.sort((a, b) => new Date(b.lastMessage?.created_at || b.chat.created_at) - new Date(a.lastMessage?.created_at || a.chat.created_at));
    state.chats = chats;
    state.chatsLoaded = true;
    renderChatList();
    saveChatsCache();
    if (state.activeChatId) { updateChatHeaderStatus(); }
}

// Кэш списка чатов в localStorage — чтобы при следующем входе показать его мгновенно.
function saveChatsCache() {
    try {
        const slim = state.chats.map(e => ({ chat: e.chat, participants: e.participants, other: e.other, lastMessage: e.lastMessage, unread: e.unread, typing: null }));
        localStorage.setItem("centr_chats_" + state.user.id, JSON.stringify(slim));
    } catch (_) {}
}

// Мгновенно поднимаем сохранённый список чатов из кэша (до загрузки из сети).
function hydrateChatsCache() {
    try {
        const raw = localStorage.getItem("centr_chats_" + state.user.id);
        if (!raw) return false;
        const cached = JSON.parse(raw);
        if (Array.isArray(cached) && cached.length) {
            state.chats = cached;
            cached.forEach(e => { if (e.other) state.profilesCache[e.other.id] = e.other; });
            renderChatList();
            return true;
        }
    } catch (_) {}
    return false;
}

function chatTitle(entry) {
    if (entry.chat.is_group) return entry.chat.name || "Группа";
    return entry.other?.username || "Неизвестно";
}
function chatAvatarUrl(entry) {
    if (entry.chat.is_group) return entry.chat.avatar_url || null;
    return entry.other?.avatar_url || null;
}

function snippetForMessage(m) {
    if (!m) return "";
    if (m.is_deleted) return "🚫 Сообщение удалено";
    if (m.media_type === "image") return "📷 Фото";
    if (m.media_type === "video") return "🎬 Видео";
    if (m.media_type === "voice") return "🎤 Голосовое сообщение";
    if (m.media_type === "audio") return "🎵 Аудио";
    if (m.media_url) return "📎 Вложение";
    return m.text || "";
}

function checkIcon(status) { // 'pending' | 'sent' | 'delivered' | 'read'
    if (status === "pending") {
        return `<span class="check pending"><svg viewBox="0 0 24 24"><path d="M11.5 7v5.2l4 2.4.8-1.3-3.3-2V7z"/><path d="M12 3a9 9 0 100 18 9 9 0 000-18zm0 16a7 7 0 110-14 7 7 0 010 14z"/></svg></span>`;
    }
    if (status === "sent") {
        return `<span class="check"><svg viewBox="0 0 18 18"><path d="M13.6 4.5l-6.3 8.2-3-2.9-1 1 4 3.9 7.3-9.5z"/></svg></span>`;
    }
    // Двойная галочка как изначально, только вторую чуть сдвинул вправо — лёгкий заметный зазор.
    const cls = status === "read" ? "check read" : "check";
    return `<span class="${cls}"><svg viewBox="0 0 20 18"><path d="M8.6 13.2l-3-2.9-1 1 4 3.9 7.3-9.5-1-.8z"/><path d="M14.2 4.9l-6.2 8.1.9.9 7.3-9.5z" opacity=".9"/></svg></span>`;
}

function outgoingStatus(m) {
    if (m._pending) return "pending";
    if (m.is_read) return "read";
    if (m.is_delivered) return "delivered";
    return "sent";
}

function renderChatList() {
    const list = el("chat-list");
    let entries = state.chats;

    if (state.searchTerm && state.sidebarTab === "chats") {
        const q = state.searchTerm.toLowerCase();
        entries = entries.filter(e => chatTitle(e).toLowerCase().includes(q));
    }

    if (!state.chats.length) {
        hide(list);
        // Не показываем «чатов пока нет», пока не завершилась первая загрузка — иначе мелькает при входе.
        if (state.chatsLoaded) show(el("chat-list-empty")); else hide(el("chat-list-empty"));
        return;
    }
    hide(el("chat-list-empty")); show(list);

    list.innerHTML = entries.map(entry => {
        const title = chatTitle(entry);
        const url = chatAvatarUrl(entry);
        const active = entry.chat.id === state.activeChatId ? " active" : "";
        const unreadCls = entry.unread > 0 ? " unread" : "";
        const time = entry.lastMessage ? fmtTime(entry.lastMessage.created_at) : "";
        const online = !entry.chat.is_group && entry.other && state.presence[entry.other.id];

        let snippet, snippetCls = "chat-item-snippet";
        if (entry.typing) { snippet = "печатает…"; snippetCls += " typing"; }
        else {
            const m = entry.lastMessage;
            let check = "";
            if (m && m.sender_id === state.user.id && !m.is_deleted) {
                check = `<span class="chat-item-check">${checkIcon(outgoingStatus(m))}</span>`;
            }
            const prefix = entry.chat.is_group && m && !m.is_deleted && m.sender_id !== state.user.id
                ? `${esc((state.profilesCache[m.sender_id]?.username) || "").split(" ")[0]}: ` : "";
            snippet = `${check}${prefix}${esc(snippetForMessage(m))}`;
        }

        return `
        <div class="chat-item${active}${unreadCls}" data-chat="${entry.chat.id}">
            <span class="avatar">
                ${url ? `<img src="${esc(url)}" alt="">` : `<span class="avatar-fallback">${esc(initials(title))}</span>`}
                ${online ? '<span class="online-dot"></span>' : ""}
            </span>
            <div class="chat-item-main">
                <div class="chat-item-row">
                    <span class="chat-item-name">${esc(title)}</span>
                    <span class="chat-item-time">${time}</span>
                </div>
                <div class="chat-item-sub">
                    <span class="${snippetCls}">${snippet}</span>
                    ${entry.unread > 0 ? `<span class="chat-badge">${entry.unread}</span>` : ""}
                </div>
            </div>
        </div>`;
    }).join("");

    list.querySelectorAll(".chat-item").forEach(node => {
        node.addEventListener("click", () => openChat(node.dataset.chat));
    });
}

/* ------------------------------------------------------------------ *
 *  6. АКТИВНЫЙ ЧАТ
 * ------------------------------------------------------------------ */
function getChatEntry(chatId) { return state.chats.find(e => e.chat.id === chatId); }

async function openChat(chatId) {
    if (!chatId) return;
    state.activeChatId = chatId;
    state.replyTo = null;
    state.pinnedIndex = 0;
    resetScrollBadge();
    updateReplyPreview();
    cancelEdit(true);
    notifyNativeActiveChat(chatId);
    hide(el("chat-search-bar"));
    hide(el("pinned-bar"));

    const entry = getChatEntry(chatId);
    hide(el("welcome-screen"));
    show(el("chat-view"));
    el("messenger").classList.add("chat-open");

    const title = entry ? chatTitle(entry) : "Чат";
    const url = entry ? chatAvatarUrl(entry) : null;
    paintAvatar(el("chat-header-avatar-img"), el("chat-header-avatar-fallback"), url, title);
    el("chat-header-name").textContent = title;
    updateChatHeaderStatus();
    refreshActiveChatOther();
    toggleCallButton(entry);

    renderChatList();

    el("messages").innerHTML = `<div class="day-sep">Загрузка…</div>`;
    await loadMessages(chatId);

    subscribeTyping(chatId);
    await markChatRead(chatId);
}

async function loadMessages(chatId) {
    const { data, error } = await sb.from("messages")
        .select("*").eq("chat_id", chatId).order("created_at", { ascending: true }).limit(500);
    if (error) { console.error(error); return; }
    state.messages = data || [];

    const ids = state.messages.map(m => m.id);
    state.reactionsByMsg = {};
    if (ids.length) {
        const { data: reacts } = await sb.from("message_reactions").select("*").in("message_id", ids);
        (reacts || []).forEach(r => {
            (state.reactionsByMsg[r.message_id] ||= []).push(r);
        });
    }
    await cacheProfiles([
        ...state.messages.map(m => m.sender_id),
        ...state.messages.map(m => m.forwarded_from).filter(Boolean)
    ]);
    if (chatId !== state.activeChatId) return;
    renderMessages();
    renderPinnedBar();
    scrollMessagesToBottom(true);
    resetScrollBadge();
}

function renderMessages() {
    const box = el("messages");
    if (!state.messages.length) {
        box.innerHTML = `<div class="day-sep">Пока нет сообщений — поздоровайтесь 👋</div>`;
        return;
    }
    state.messages.sort((a, b) => new Date(a.created_at) - new Date(b.created_at));

    const entry = getChatEntry(state.activeChatId);
    const isGroup = entry?.chat.is_group;
    let html = "";
    let lastDay = "";
    let prevSender = null;

    for (const m of state.messages) {
        const day = fmtDay(m.created_at);
        if (day !== lastDay) { html += `<div class="day-sep">${day}</div>`; lastDay = day; prevSender = null; }
        html += renderMessageHTML(m, isGroup, prevSender === m.sender_id);
        prevSender = m.sender_id;
    }
    box.innerHTML = html;
    wireMessageEvents(box);
}

function renderMessageHTML(m, isGroup, grouped) {
    const out = m.sender_id === state.user.id;
    const sender = state.profilesCache[m.sender_id];

    let replyHTML = "";
    if (m.reply_to_message_id) {
        const rep = state.messages.find(x => x.id === m.reply_to_message_id);
        const repName = rep ? (rep.sender_id === state.user.id ? "Вы" : (state.profilesCache[rep.sender_id]?.username || "Пользователь")) : "Сообщение";
        const repText = rep ? snippetForMessage(rep) : "Исходное сообщение";
        replyHTML = `<div class="reply-quote" data-jump="${m.reply_to_message_id}">
            <div class="reply-quote-name">${esc(repName)}</div>
            <div class="reply-quote-text">${esc(repText)}</div></div>`;
    }

    let fwdHTML = "";
    if (m.forwarded_from && !m.is_deleted) {
        const origName = (m.forwarded_from === state.user.id) ? "" : (state.profilesCache[m.forwarded_from]?.username || "");
        fwdHTML = `<div class="fwd-label">↪ Переслано${origName ? ` от <b>${esc(origName)}</b>` : ""}</div>`;
    }

    let bodyHTML = "";
    let mediaClass = "";
    if (m.is_deleted) {
        bodyHTML = `<div class="bubble-text">🚫 Сообщение удалено</div>`;
    } else {
        if (m.media_url) {
            mediaClass = " has-media";
            if (m.media_type === "image") {
                bodyHTML += `<div class="bubble-media"><img src="${esc(m.media_url)}" alt="" data-lightbox="image"></div>`;
            } else if (m.media_type === "video") {
                bodyHTML += `<div class="bubble-media"><video src="${esc(m.media_url)}" controls preload="metadata"></video></div>`;
            } else if (m.media_type === "voice" || m.media_type === "audio") {
                bodyHTML += renderVoiceHTML(m);
            } else {
                bodyHTML += `<div class="bubble-media"><a href="${esc(m.media_url)}" target="_blank" rel="noopener">📎 Скачать вложение</a></div>`;
            }
        }
        if (m.text) bodyHTML += `<div class="bubble-text">${linkify(m.text)}</div>`;
    }

    let meta = `<span class="bubble-time">${fmtTime(m.created_at)}</span>`;
    if (m.edited_at && !m.is_deleted) meta = `<span class="edited-mark" title="Изменено">изм.</span>` + meta;
    if (m.is_pinned && !m.is_deleted) meta = `<span class="pin-mark" title="Закреплено">📌</span>` + meta;
    if (out && !m.is_deleted) meta += checkIcon(outgoingStatus(m));

    const reactions = state.reactionsByMsg[m.id] || [];
    let reactHTML = "";
    if (reactions.length) {
        const byEmoji = {};
        reactions.forEach(r => { (byEmoji[r.emoji] ||= []).push(r); });
        reactHTML = `<div class="reactions">` + Object.entries(byEmoji).map(([emoji, arr]) => {
            const mine = arr.some(r => r.user_id === state.user.id) ? " mine" : "";
            return `<span class="reaction-pill${mine}" data-react-emoji="${esc(emoji)}" data-msg="${m.id}">${emoji}<span class="rc">${arr.length}</span></span>`;
        }).join("") + `</div>`;
    }

    const senderName = (isGroup && !out && !m.is_deleted)
        ? `<div class="bubble-sender" data-openuser="${m.sender_id}">${esc(sender?.username || "Пользователь")}</div>` : "";
    const actionsBtn = m.is_deleted ? "" : `<button class="msg-actions-btn" data-menu="${m.id}"><svg viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg></button>`;

    return `
    <div class="msg-row ${out ? "out" : "in"}${grouped ? " grouped" : ""}" data-msg-row="${m.id}">
        <div class="bubble${m.is_deleted ? " deleted" : ""}${mediaClass}" data-bubble="${m.id}">
            ${senderName}${fwdHTML}${replyHTML}${bodyHTML}
            <span class="bubble-meta">${meta}</span>
            ${actionsBtn}
        </div>
    </div>
    <div class="react-holder ${out ? "out" : "in"}" data-holder="${m.id}">${reactHTML}</div>`;
}

function renderVoiceHTML(m) {
    let bars = "";
    for (let i = 0; i < 32; i++) {
        const seed = (m.id.charCodeAt(i % m.id.length) * (i + 3)) % 100;
        const h = 20 + (seed % 70);
        bars += `<span style="height:${h}%"></span>`;
    }
    return `
    <div class="voice-player" data-voice="${esc(m.media_url)}" data-msg="${m.id}">
        <button class="voice-play-btn" data-vplay><svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg></button>
        <div class="voice-wave" data-vwave>${bars}</div>
        <span class="voice-time" data-vtime>0:00</span>
    </div>`;
}

// Навесить обработчики на сообщения ВНУТРИ указанного контейнера (root).
// Для полной перерисовки root = #messages; для добавления одного сообщения —
// временный контейнер (обработчики сохраняются при переносе узлов).
function wireMessageEvents(root) {
    root = root || document;
    $$("[data-lightbox]", root).forEach(node => node.addEventListener("click", () => openLightbox(node.src, "image")));
    $$(".bubble-media video", root).forEach(v => v.addEventListener("dblclick", () => openLightbox(v.src, "video")));
    $$("[data-jump]", root).forEach(node => node.addEventListener("click", () => jumpToMessage(node.dataset.jump)));
    $$("[data-openuser]", root).forEach(node => node.addEventListener("click", (e) => { e.stopPropagation(); openUserProfile(node.dataset.openuser); }));

    $$("[data-menu]", root).forEach(btn => btn.addEventListener("click", (e) => {
        e.stopPropagation();
        openContextMenu(btn.dataset.menu, e.clientX, e.clientY);
    }));

    $$("[data-react-emoji]", root).forEach(pill => pill.addEventListener("click", () => {
        toggleReaction(pill.dataset.msg, pill.dataset.reactEmoji);
    }));

    $$("[data-bubble]", root).forEach(b => {
        b.addEventListener("contextmenu", (e) => { e.preventDefault(); openContextMenu(b.dataset.bubble, e.clientX, e.clientY); });
        let lpTimer;
        b.addEventListener("touchstart", (e) => {
            lpTimer = setTimeout(() => {
                const t = e.touches[0];
                openContextMenu(b.dataset.bubble, t.clientX, t.clientY);
            }, 480);
        }, { passive: true });
        b.addEventListener("touchend", () => clearTimeout(lpTimer));
        b.addEventListener("touchmove", () => clearTimeout(lpTimer));
    });

    $$("[data-voice]", root).forEach(setupVoicePlayer);
}

// Добавить ОДНО сообщение в конец ленты (без полной перерисовки).
function appendMessageRow(m, animate) {
    const box = el("messages");
    if (!box) return;
    // Если сейчас показан placeholder («Пока нет сообщений …») — убрать его.
    if (!box.querySelector("[data-msg-row]")) box.innerHTML = "";

    const entry = getChatEntry(state.activeChatId);
    const isGroup = entry?.chat.is_group;

    const idx = state.messages.findIndex(x => x.id === m.id);
    const prev = idx > 0 ? state.messages[idx - 1] : null;
    const needDay = !prev || fmtDay(prev.created_at) !== fmtDay(m.created_at);
    const grouped = !!prev && !needDay && prev.sender_id === m.sender_id;

    if (needDay) {
        const sep = document.createElement("div");
        sep.className = "day-sep";
        sep.textContent = fmtDay(m.created_at);
        box.appendChild(sep);
    }

    const tmp = document.createElement("div");
    tmp.innerHTML = renderMessageHTML(m, isGroup, grouped);
    if (animate) {
        const bub = tmp.querySelector(".bubble");
        if (bub) bub.classList.add("animate-in");
    }
    wireMessageEvents(tmp);
    while (tmp.firstChild) box.appendChild(tmp.firstChild);
}

// Заменить узлы одного сообщения на месте (без сброса прокрутки).
function replaceMessageNode(id, m) {
    const row = document.querySelector('[data-msg-row="' + id + '"]');
    if (!row) return false;
    const holder = document.querySelector('[data-holder="' + id + '"]');
    const entry = getChatEntry(state.activeChatId);
    const isGroup = entry?.chat.is_group;
    const grouped = row.classList.contains("grouped");

    const tmp = document.createElement("div");
    tmp.innerHTML = renderMessageHTML(m, isGroup, grouped);
    wireMessageEvents(tmp);
    const newRow = tmp.querySelector("[data-msg-row]");
    const newHolder = tmp.querySelector("[data-holder]");
    if (newRow) row.replaceWith(newRow);
    if (holder && newHolder) holder.replaceWith(newHolder);
    else if (newHolder && newRow) newRow.after(newHolder);
    return true;
}

function removeMessageNode(id) {
    const row = document.querySelector('[data-msg-row="' + id + '"]');
    const holder = document.querySelector('[data-holder="' + id + '"]');
    if (row) row.remove();
    if (holder) holder.remove();
}

function scrollMessagesToBottom(force, smooth) {
    const box = el("messages");
    if (!box) return;
    const nearBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 160;
    if (force || nearBottom) {
        if (smooth && typeof box.scrollTo === "function") {
            box.scrollTo({ top: box.scrollHeight, behavior: "smooth" });
        } else {
            box.scrollTop = box.scrollHeight;
        }
    }
}

function jumpToMessage(id) {
    const row = document.querySelector(`[data-msg-row="${id}"] .bubble`);
    if (!row) return;
    row.scrollIntoView({ behavior: "smooth", block: "center" });
    row.classList.add("highlight");
    setTimeout(() => row.classList.remove("highlight"), 1500);
}

/* ---- Панель закреплённых сообщений ---- */
function pinnedMessages() {
    return state.messages
        .filter(m => m.is_pinned && !m.is_deleted)
        .sort((a, b) => new Date(a.pinned_at || a.created_at) - new Date(b.pinned_at || b.created_at));
}

function renderPinnedBar() {
    const bar = el("pinned-bar");
    if (!bar) return;
    const pinned = pinnedMessages();
    if (!pinned.length) { hide(bar); state.pinnedIndex = 0; return; }
    if (state.pinnedIndex >= pinned.length) state.pinnedIndex = 0;
    const m = pinned[state.pinnedIndex];
    el("pinned-title").textContent = pinned.length > 1
        ? `Закреплённые сообщения (${state.pinnedIndex + 1}/${pinned.length})`
        : "Закреплённое сообщение";
    const who = m.sender_id === state.user.id ? "Вы" : (state.profilesCache[m.sender_id]?.username || "Пользователь");
    el("pinned-text").textContent = `${who}: ${snippetForMessage(m)}`;

    el("pinned-body").onclick = () => {
        jumpToMessage(m.id);
        if (pinned.length > 1) { state.pinnedIndex = (state.pinnedIndex + 1) % pinned.length; renderPinnedBar(); }
    };
    el("pinned-unpin").onclick = (e) => { e.stopPropagation(); togglePin(m.id); };
    show(bar);
}

function updateChatHeaderStatus() {
    const entry = getChatEntry(state.activeChatId);
    const statusEl = el("chat-header-status");
    if (!entry) { statusEl.textContent = ""; return; }
    if (entry.chat.is_group) {
        statusEl.className = "chat-header-status";
        statusEl.textContent = `${entry.participants.length} ${pluralMembers(entry.participants.length)}`;
        return;
    }
    if (entry.typing) { statusEl.className = "chat-header-status typing"; statusEl.textContent = "печатает…"; return; }
    const other = entry.other;
    if (other && state.presence[other.id]) {
        statusEl.className = "chat-header-status online";
        statusEl.textContent = "в сети";
    } else {
        statusEl.className = "chat-header-status";
        statusEl.textContent = fmtLastSeen(other?.last_seen);
    }
}

// Подтягиваем свежий профиль собеседника (в т.ч. last_seen), чтобы «был(а) в сети»
// показывался корректно и не зависел от задержек realtime-UPDATE профилей.
async function refreshActiveChatOther() {
    const entry = getChatEntry(state.activeChatId);
    if (!entry || entry.chat.is_group || !entry.other) return;
    try {
        const { data } = await sb.from("profiles").select("*").eq("id", entry.other.id).single();
        if (data) {
            entry.other = data;
            state.profilesCache[data.id] = data;
            updateChatHeaderStatus();
        }
    } catch (_) {}
}

/* ------------------------------------------------------------------ *
 *  7. КОМПОЗЕР — текст, медиа, голос
 * ------------------------------------------------------------------ */
function setupComposer() {
    const input = el("message-input");

    input.addEventListener("input", () => {
        input.style.height = "auto";
        input.style.height = Math.min(input.scrollHeight, 130) + "px";
        const hasText = input.value.trim().length > 0;
        el("send-btn").classList.toggle("hidden", !hasText);
        el("mic-btn").classList.toggle("hidden", hasText);
        broadcastTyping();
    });

    input.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendText(); }
    });

    el("send-btn").addEventListener("click", sendText);

    el("attach-btn").addEventListener("click", () => el("file-input").click());
    el("file-input").addEventListener("change", (e) => {
        const file = e.target.files[0];
        e.target.value = "";
        if (!file) return;
        // Фото — через редактор (предпросмотр + обрезка + подпись), остальное (аудио) — сразу.
        if (file.type.startsWith("image/")) openImageComposer(file);
        else sendMedia(file);
    });

    // Кнопка «Камера»: на телефоне открывает камеру, снимок попадает в тот же редактор.
    el("camera-btn").addEventListener("click", () => el("camera-input").click());
    el("camera-input").addEventListener("change", (e) => {
        const file = e.target.files[0];
        e.target.value = "";
        if (file) openImageComposer(file);
    });

    buildEmojiPicker();
    setupImageComposer();
    el("emoji-btn").addEventListener("click", (e) => {
        e.stopPropagation();
        el("emoji-picker").classList.toggle("hidden");
    });

    setupRecorderControls();
}

function buildEmojiPicker() {
    const picker = el("emoji-picker");
    picker.innerHTML = `
        <div class="emoji-tabs" id="emoji-tabs">
            ${EMOJI_CATEGORIES.map((c, i) => `<button type="button" class="emoji-tab${i === 0 ? " active" : ""}" data-cat="${i}" title="${esc(c.name)}">${c.icon}</button>`).join("")}
        </div>
        <div class="emoji-grid" id="emoji-grid"></div>`;

    const grid = picker.querySelector("#emoji-grid");
    const renderCat = (idx) => {
        const cat = EMOJI_CATEGORIES[idx] || EMOJI_CATEGORIES[0];
        grid.innerHTML = cat.emojis.map(e => `<button type="button">${e}</button>`).join("");
        grid.querySelectorAll("button").forEach(b => b.addEventListener("click", () => insertEmoji(b.textContent)));
        grid.scrollTop = 0;
    };
    picker.querySelectorAll(".emoji-tab").forEach(tab => tab.addEventListener("click", () => {
        picker.querySelectorAll(".emoji-tab").forEach(t => t.classList.toggle("active", t === tab));
        renderCat(Number(tab.dataset.cat));
    }));
    renderCat(0);
}

// Вставить эмодзи в п  зицию курсора (а не просто в конец поля ввода).
function insertEmoji(emoji) {
    const input = el("message-input");
    const start = input.selectionStart ?? input.value.length;
    const end = input.selectionEnd ?? input.value.length;
    input.value = input.value.slice(0, start) + emoji + input.value.slice(end);
    const pos = start + emoji.length;
    input.dispatchEvent(new Event("input"));
    input.focus();
    try { input.setSelectionRange(pos, pos); } catch (_) {}
}

async function insertMessage(payload) {
    const tempId = "temp_" + Date.now() + "_" + Math.random().toString(36).slice(2, 8);
    const replyId = state.replyTo?.id || null;
    const temp = {
        id: tempId,
        chat_id: state.activeChatId,
        sender_id: state.user.id,
        created_at: new Date().toISOString(),
        is_read: false, is_delivered: false, is_deleted: false, is_pinned: false,
        reply_to_message_id: replyId,
        forwarded_from: null,
        text: payload.text || null,
        media_url: payload.media_url || null,
        media_type: payload.media_type || null,
        _pending: true
    };
    state.messages.push(temp);
    appendMessageRow(temp, true);
    scrollMessagesToBottom(true, true);
    resetScrollBadge();

    state.replyTo = null; updateReplyPreview();

    const insertRow = {
        chat_id: temp.chat_id,
        sender_id: state.user.id,
        text: temp.text,
        media_url: temp.media_url,
        media_type: temp.media_type,
        reply_to_message_id: replyId
    };
    const { data, error } = await sb.from("messages").insert(insertRow).select().single();

    if (error) {
        toast("Не удалось отправить сообщение", true);
        state.messages = state.messages.filter(x => x.id !== tempId);
        removeMessageNode(tempId);
        return;
    }

    const stillIdx = state.messages.findIndex(x => x.id === tempId);
    if (stillIdx >= 0) {
        // realtime-эхо ещё не пришло — заменяем временное сообщение настоящим.
        state.messages[stillIdx] = data;
        replaceMessageNode(tempId, data);
    } else if (!state.messages.some(x => x.id === data.id)) {
        // временного уже нет и настоящего нет — просто добавим.
        state.messages.push(data);
        appendMessageRow(data, false);
    }
    bumpChatEntry(data);
}

function sendText() {
    if (state.editing) { commitEdit(); return; }   // режим редактирования
    const input = el("message-input");
    const text = input.value.trim();
    if (!text || !state.activeChatId) return;
    input.value = "";
    input.style.height = "auto";
    input.dispatchEvent(new Event("input"));
    stopTypingBroadcast();
    insertMessage({ text });
}

async function sendMedia(file) {
    if (!state.activeChatId) return;

    // Видео отключено, чтобы не переполнять базу данных.
    if (file.type && file.type.startsWith("video/")) {
        toast("Отправка видео отключена. Можно отправить фото, аудио или голосовое сообщение.", true);
        return;
    }

    const maxMb = Number(CFG.MAX_UPLOAD_MB) || 50;
    if (file.size > maxMb * 1024 * 1024) {
        toast(`Файл ${(file.size / 1048576).toFixed(1)} МБ превышает лимит ${maxMb} МБ. Сожмите видео или увеличьте лимит бакета в Supabase (на бесплатном тарифе максимум 50 МБ).`, true);
        return;
    }

    const type = file.type.startsWith("image/") ? "image"
               : file.type.startsWith("video/") ? "video"
               : file.type.startsWith("audio/") ? "audio" : "file";
    const typeRu = { image: "фото", video: "видео", audio: "аудио", file: "файл" }[type];

    const prog = showUploadProgress(`Загрузка (${typeRu})`);
    try {
        const url = await uploadToBucket(CFG.MEDIA_BUCKET, file, state.activeChatId, (p) => prog.update(p));
        prog.finish();
        await insertMessage({ media_url: url, media_type: type });
    } catch (err) {
        console.error(err);
        prog.fail();
        toast("Не удалось загрузить: " + (err?.message || "ошибка сети"), true);
    }
}

/* ------------------------------------------------------------------ *
 *  7a. РЕДАКТОР ИСХОДЯЩЕГО ФОТО (предпросмотр + обрезка + сжатие + подпись)
 *      Открывается при выборе картинки скрепкой или съёмке камерой.
 *      Перед отправкой фото уменьшается (до 1600 px по длинной стороне,
 *      JPEG q0.85) — это заметно экономит место в базе.
 * ------------------------------------------------------------------ */
let imgComposer = null;

function openImageComposer(file) {
    if (!state.activeChatId) { toast("Сначала откройте чат", true); return; }
    if (!file || !file.type.startsWith("image/")) { sendMedia(file); return; }

    const maxMb = Number(CFG.MAX_UPLOAD_MB) || 50;
    if (file.size > maxMb * 1024 * 1024) {
        toast(`Файл ${(file.size / 1048576).toFixed(1)} МБ превышает лимит ${maxMb} МБ.`, true);
        return;
    }

    const img = el("imgsend-img");
    const url = URL.createObjectURL(file);
    imgComposer = { file, url, cropOn: false, rect: null, dispW: 0, dispH: 0, drag: null };
    el("imgsend-caption").value = "";
    hide(el("imgsend-crop"));
    hide(el("imgsend-resetbtn"));

    img.onload = () => {
        requestAnimationFrame(() => {
            imgComposer.dispW = img.clientWidth;
            imgComposer.dispH = img.clientHeight;
        });
    };
    img.src = url;
    openModal("imgsend-modal");
}

function closeImageComposer() {
    if (imgComposer) { try { URL.revokeObjectURL(imgComposer.url); } catch (_) {} }
    imgComposer = null;
    el("imgsend-img").removeAttribute("src");
    closeModal("imgsend-modal");
}

function paintCrop() {
    const c = imgComposer; if (!c || !c.rect) return;
    const box = el("imgsend-crop");
    box.style.left = c.rect.x + "px";
    box.style.top = c.rect.y + "px";
    box.style.width = c.rect.w + "px";
    box.style.height = c.rect.h + "px";
}

function enableCrop() {
    const c = imgComposer; if (!c) return;
    c.dispW = el("imgsend-img").clientWidth;
    c.dispH = el("imgsend-img").clientHeight;
    // Стартовая рамка — 80% по центру.
    const w = Math.round(c.dispW * 0.8), h = Math.round(c.dispH * 0.8);
    c.rect = { x: Math.round((c.dispW - w) / 2), y: Math.round((c.dispH - h) / 2), w, h };
    c.cropOn = true;
    show(el("imgsend-crop"));
    show(el("imgsend-resetbtn"));
    paintCrop();
}

function disableCrop() {
    const c = imgComposer; if (!c) return;
    c.cropOn = false; c.rect = null;
    hide(el("imgsend-crop"));
    hide(el("imgsend-resetbtn"));
}

function clampRect() {
    const c = imgComposer; if (!c || !c.rect) return;
    const MIN = 30;
    let r = c.rect;
    r.w = Math.max(MIN, Math.min(r.w, c.dispW));
    r.h = Math.max(MIN, Math.min(r.h, c.dispH));
    r.x = Math.max(0, Math.min(r.x, c.dispW - r.w));
    r.y = Math.max(0, Math.min(r.y, c.dispH - r.h));
}

function setupImageComposer() {
    const stage = el("imgsend-stage");
    const cropBox = el("imgsend-crop");

    el("imgsend-close").addEventListener("click", closeImageComposer);
    el("imgsend-cancel").addEventListener("click", closeImageComposer);
    el("imgsend-cropbtn").addEventListener("click", () => {
        if (!imgComposer) return;
        imgComposer.cropOn ? disableCrop() : enableCrop();
    });
    el("imgsend-resetbtn").addEventListener("click", disableCrop);
    el("imgsend-send").addEventListener("click", doSendImage);

    // Перемещение и изменение рамки обрезки (Pointer Events — мышь и тач сразу).
    const onDown = (e) => {
        const c = imgComposer;
        if (!c || !c.cropOn || !c.rect) return;
        const rect = el("imgsend-img").getBoundingClientRect();
        const px = e.clientX - rect.left, py = e.clientY - rect.top;
        const handle = e.target.closest("[data-h]");
        c.drag = {
            mode: handle ? "resize" : "move",
            corner: handle ? handle.dataset.h : null,
            sx: px, sy: py, start: { ...c.rect }
        };
        try { stage.setPointerCapture(e.pointerId); } catch (_) {}
        e.preventDefault();
    };
    const onMove = (e) => {
        const c = imgComposer;
        if (!c || !c.drag || !c.rect) return;
        const rect = el("imgsend-img").getBoundingClientRect();
        const px = e.clientX - rect.left, py = e.clientY - rect.top;
        const dx = px - c.drag.sx, dy = py - c.drag.sy;
        const s = c.drag.start;
        if (c.drag.mode === "move") {
            c.rect.x = s.x + dx; c.rect.y = s.y + dy;
        } else {
            const co = c.drag.corner;
            if (co === "tl") { c.rect.x = s.x + dx; c.rect.y = s.y + dy; c.rect.w = s.w - dx; c.rect.h = s.h - dy; }
            else if (co === "tr") { c.rect.y = s.y + dy; c.rect.w = s.w + dx; c.rect.h = s.h - dy; }
            else if (co === "bl") { c.rect.x = s.x + dx; c.rect.w = s.w - dx; c.rect.h = s.h + dy; }
            else if (co === "br") { c.rect.w = s.w + dx; c.rect.h = s.h + dy; }
        }
        clampRect();
        paintCrop();
        e.preventDefault();
    };
    const onUp = (e) => { if (imgComposer) imgComposer.drag = null; try { stage.releasePointerCapture(e.pointerId); } catch (_) {} };

    stage.addEventListener("pointerdown", onDown);
    stage.addEventListener("pointermove", onMove);
    stage.addEventListener("pointerup", onUp);
    stage.addEventListener("pointercancel", onUp);
    cropBox.addEventListener("pointerdown", onDown);
}

// Экспорт с учётом обрезки и уменьшением до 1600 px по длинной стороне.
function exportComposedImage() {
    return new Promise((resolve) => {
        const c = imgComposer;
        const img = el("imgsend-img");
        const natW = img.naturalWidth, natH = img.naturalHeight;
        let sx = 0, sy = 0, sw = natW, sh = natH;

        if (c.cropOn && c.rect && c.dispW && c.dispH) {
            const scaleX = natW / c.dispW, scaleY = natH / c.dispH;
            sx = Math.round(c.rect.x * scaleX);
            sy = Math.round(c.rect.y * scaleY);
            sw = Math.round(c.rect.w * scaleX);
            sh = Math.round(c.rect.h * scaleY);
        }

        const MAX = 1600;
        let outW = sw, outH = sh;
        if (Math.max(sw, sh) > MAX) {
            const k = MAX / Math.max(sw, sh);
            outW = Math.round(sw * k); outH = Math.round(sh * k);
        }

        const canvas = document.createElement("canvas");
        canvas.width = outW; canvas.height = outH;
        const ctx = canvas.getContext("2d");
        try { ctx.drawImage(img, sx, sy, sw, sh, 0, 0, outW, outH); } catch (_) {}
        canvas.toBlob((blob) => {
            if (!blob) { resolve(null); return; }
            resolve(new File([blob], `photo_${Date.now()}.jpg`, { type: "image/jpeg" }));
        }, "image/jpeg", 0.85);
    });
}

async function doSendImage() {
    if (!imgComposer) return;
    const caption = el("imgsend-caption").value.trim();
    const btn = el("imgsend-send");
    btn.disabled = true; btn.textContent = "Отправка…";
    try {
        const file = await exportComposedImage();
        closeImageComposer();
        if (!file) { toast("Не удалось обработать фото", true); return; }

        const prog = showUploadProgress("Загрузка (фото)");
        try {
            const url = await uploadToBucket(CFG.MEDIA_BUCKET, file, state.activeChatId, (p) => prog.update(p));
            prog.finish();
            await insertMessage({ media_url: url, media_type: "image", text: caption || null });
        } catch (err) {
            console.error(err);
            prog.fail();
            toast("Не удалось загрузить фото", true);
        }
    } finally {
        btn.disabled = false; btn.textContent = "Отправить";
    }
}

/* ---- Запись голоса (MediaRecorder API) ---- */
function setupRecorderControls() {
    el("mic-btn").addEventListener("click", startRecording);
    el("recording-cancel").addEventListener("click", () => stopRecording(false));
    el("recording-send").addEventListener("click", () => stopRecording(true));
}

async function startRecording() {
    if (!state.activeChatId) return;
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || !window.MediaRecorder) {
        toast("Запись голоса недоступна на этом устройстве", true);
        return;
    }

    // В Android WebView активный AudioContext (звук уведомлений) занимает
    // аудиоподс      стему, и микрофон не открывается → NotReadableError.
    // Поэтому на время записи приостанавливаем звук уведомлений.
    try { if (audioCtx && audioCtx.state === "running") await audioCtx.suspend(); } catch (_) {}

    let stream = null;
    let micErr = null;
    // На части Android WebView встроенная обработка звука (эхо-/шумоподавление)
    // не может стартовать и даёт NotReadableError. Поэтому пробуем несколько
    // вариантов по очереди: сначала «сырой» микрофон без обработки, затем обычный.
    const micVariants = [
        { audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false } },
        { audio: true },
    ];
    for (let i = 0; i < micVariants.length && !stream; i++) {
        try {
            stream = await navigator.mediaDevices.getUserMedia(micVariants[i]);
        } catch (err) {
            micErr = err;
            console.error("getUserMedia variant " + i + ":", err);
            // Устройство «не завелось» — ждём и пробуем следующий вариант.
            if (err.name === "NotReadableError" || err.name === "AbortError") {
                await new Promise(r => setTimeout(r, 500));
                continue;
            }
            // Другая ошибка (напр. NotAllowedError) — пробовать дальше бессмысленно.
            break;
        }
    }

    if (!stream) {
        try { if (audioCtx && audioCtx.state === "suspended") audioCtx.resume(); } catch (_) {}
        toast("Не удалось получить доступ к микрофону. Попробуйте ещё раз.", true);
        return;
    }

    try {
        const mime = MediaRecorder.isTypeSupported("audio/webm") ? "audio/webm"
                   : MediaRecorder.isTypeSupported("audio/mp4") ? "audio/mp4" : "";
        const mr = new MediaRecorder(stream, mime ? { mimeType: mime } : undefined);
        const chunks = [];
        mr.ondataavailable = (e) => { if (e.data.size) chunks.push(e.data); };
        mr.onstop = () => {
            stream.getTracks().forEach(t => t.stop());
            try { if (audioCtx && audioCtx.state === "suspended") audioCtx.resume(); } catch (_) {}
            clearInterval(state.recorder.interval);
            hide(el("recording-bar"));
            show(el("composer"));
            if (state.recorder.send && chunks.length) {
                const blob = new Blob(chunks, { type: mime || "audio/webm" });
                const ext = (mime || "audio/webm").includes("mp4") ? "m4a" : "webm";
                const file = new File([blob], `voice_${Date.now()}.${ext}`, { type: blob.type });
                uploadVoice(file);
            }
            state.recorder = null;
        };

        state.recorder = { mr, stream, chunks, send: false, seconds: 0, interval: null };
        mr.start();

        hide(el("composer"));
        show(el("recording-bar"));
        el("recording-time").textContent = "0:00";
        state.recorder.interval = setInterval(() => {
            state.recorder.seconds++;
            el("recording-time").textContent = fmtDuration(state.recorder.seconds);
            if (state.recorder.seconds >= 300) stopRecording(true);
        }, 1000);
    } catch (err) {
        console.error(err);
        try { stream.getTracks().forEach(t => t.stop()); } catch (_) {}
        try { if (audioCtx && audioCtx.state === "suspended") audioCtx.resume(); } catch (_) {}
        toast("Не удалось начать запись голоса", true);
    }
}

function stopRecording(send) {
    if (!state.recorder) return;
    state.recorder.send = send;
    if (state.recorder.mr.state !== "inactive") state.recorder.mr.stop();
}

async function uploadVoice(file) {
    const prog = showUploadProgress("Отправка голосового");
    try {
        const url = await uploadToBucket(CFG.MEDIA_BUCKET, file, state.activeChatId, (p) => prog.update(p));
        prog.finish();
        await insertMessage({ media_url: url, media_type: "voice" });
    } catch (err) {
        console.error(err);
        prog.fail();
        toast("Не удалось отправить голосовое", true);
    }
}

function setupVoicePlayer(container) {
    const url = container.dataset.voice;
    const playBtn = container.querySelector("[data-vplay]");
    const wave = container.querySelector("[data-vwave]");
    const timeEl = container.querySelector("[data-vtime]");
    const bars = Array.from(wave.children);
    const audio = new Audio(url);
    let ready = false;

    audio.addEventListener("loadedmetadata", () => {
        ready = true;
        if (isFinite(audio.duration)) timeEl.textContent = fmtDuration(audio.duration);
    });
    audio.addEventListener("timeupdate", () => {
        const pct = audio.currentTime / (audio.duration || 1);
        const upto = Math.floor(pct * bars.length);
        bars.forEach((b, i) => b.classList.toggle("played", i <= upto));
        timeEl.textContent = fmtDuration(audio.currentTime);
    });
    audio.addEventListener("ended", () => {
        playBtn.innerHTML = `<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>`;
        bars.forEach(b => b.classList.remove("played"));
        if (isFinite(audio.duration)) timeEl.textContent = fmtDuration(audio.duration);
    });

    playBtn.addEventListener("click", () => {
        document.querySelectorAll("audio").forEach(a => { if (a !== audio) a.pause(); });
        if (audio.paused) {
            audio.play();
            playBtn.innerHTML = `<svg viewBox="0 0 24 24"><path d="M6 5h4v14H6zM14 5h4v14h-4z"/></svg>`;
        } else {
            audio.pause();
            playBtn.innerHTML = `<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>`;
        }
    });

    wave.addEventListener("click", (e) => {
        if (!ready || !isFinite(audio.duration)) return;
        const rect = wave.getBoundingClientRect();
        const pct = (e.clientX - rect.left) / rect.width;
        audio.currentTime = pct * audio.duration;
    });
}

/* ------------------------------------------------------------------ *
 *  7b. ПЕРЕСЫЛКА + ЗАКРЕПЛЕНИЕ
 * ------------------------------------------------------------------ */
const forwardSelection = new Map();   // key -> target
const forwardCandidates = new Map();  // key -> target (для поиска выбранного)
let forwardSourceMsg = null;

function forwardTargets() {
    const targets = [];
    state.chats.forEach(entry => {
        targets.push({
            key: "chat:" + entry.chat.id, type: "chat", chatId: entry.chat.id,
            title: chatTitle(entry), url: chatAvatarUrl(entry),
            handle: entry.chat.is_group ? "" : (entry.other?.handle || ""),
            isGroup: entry.chat.is_group
        });
    });
    const directUserIds = new Set(state.chats.filter(e => !e.chat.is_group && e.other).map(e => e.other.id));
    state.friends.forEach(p => {
        if (!directUserIds.has(p.id)) {
            targets.push({ key: "user:" + p.id, type: "user", userId: p.id, title: p.username, url: p.avatar_url, handle: p.handle || "", isGroup: false });
        }
    });
    return targets;
}

function openForwardModal(msgId) {
    const m = state.messages.find(x => x.id === msgId);
    if (!m || m.is_deleted) return;
    forwardSourceMsg = m;
    state.sharePayload = null;
    forwardSelection.clear();
    forwardCandidates.clear();
    el("forward-search").value = "";
    el("forward-chips").innerHTML = "";
    el("forward-send").disabled = true;
    el("forward-send").textContent = "Переслать";
    const who = m.sender_id === state.user.id ? "Вы" : (state.profilesCache[m.sender_id]?.username || "Пользователь");
    el("forward-preview").innerHTML = `<div class="fp-name">${esc(who)}</div><div class="fp-text">${esc(clip(snippetForMessage(m), 80))}</div>`;
    openModal("forward-modal");
    renderForwardTargets(forwardTargets());
    el("forward-search").focus();
}

// Окно «Поделиться в Центр»: то же окно выбора чатов, но источник — не сообщение,
// а текст/картинка, пришедшие из другого приложения.
function openShareModal(payload) {
    if (!payload) return;
    forwardSourceMsg = null;
    state.sharePayload = payload;
    state.pendingShare = null;
    forwardSelection.clear();
    forwardCandidates.clear();
    el("forward-search").value = "";
    el("forward-chips").innerHTML = "";
    el("forward-send").disabled = true;
    el("forward-send").textContent = "Отправить";
    let preview;
    if (payload.kind === "image") {
        preview = `<div class="fp-name">📷 Фото</div><div class="fp-text">Выберите, кому отправить</div>`;
    } else {
        preview = `<div class="fp-name">✉️ Сообщение</div><div class="fp-text">${esc(clip(payload.text, 80))}</div>`;
    }
    el("forward-preview").innerHTML = preview;
    // Модальные окна лежат вне #messenger — переключение вкладки не мешает.
    switchSidebarTab("chats");
    openModal("forward-modal");
    renderForwardTargets(forwardTargets());
    el("forward-search").focus();
}

function renderForwardTargets(targets) {
    const box = el("forward-list");
    targets.forEach(t => forwardCandidates.set(t.key, t));
    if (!targets.length) { box.innerHTML = `<div class="section-label">Ничего не найдено</div>`; return; }
    box.innerHTML = targets.map(t => {
        const sel = forwardSelection.has(t.key) ? " selected" : "";
        const sub = t.handle ? "@" + esc(t.handle) : (t.isGroup ? "группа" : "чат");
        return `<div class="user-item${sel}" data-fwd="${esc(t.key)}">
            ${avatarHTML(t.url, t.title, "sm")}
            <div class="user-item-info">
                <div class="user-item-name">${esc(t.title)}</div>
                <div class="user-item-handle">${sub}</div>
            </div>
            <div class="user-item-check">✓</div>
        </div>`;
    }).join("");
    box.querySelectorAll("[data-fwd]").forEach(node => node.addEventListener("click", () => {
        const key = node.dataset.fwd;
        if (forwardSelection.has(key)) forwardSelection.delete(key);
        else forwardSelection.set(key, forwardCandidates.get(key));
        node.classList.toggle("selected");
        renderForwardChips();
    }));
}

function renderForwardChips() {
    const chips = el("forward-chips");
    chips.innerHTML = [...forwardSelection.values()].map(t =>
        `<span class="chip">${esc(t.title)}<button data-fwdremove="${esc(t.key)}">✕</button></span>`).join("");
    chips.querySelectorAll("[data-fwdremove]").forEach(b => b.addEventListener("click", () => {
        forwardSelection.delete(b.dataset.fwdremove);
        renderForwardChips();
        const node = document.querySelector(`[data-fwd="${b.dataset.fwdremove}"]`);
        node && node.classList.remove("selected");
    }));
    el("forward-send").disabled = forwardSelection.size < 1;
}

function setupForward() {
    el("forward-search").addEventListener("input", debounce(async () => {
        const term = el("forward-search").value.trim();
        let targets = forwardTargets();
        if (term) {
            const q = term.toLowerCase().replace(/^@+/, "");
            targets = targets.filter(t => t.title.toLowerCase().includes(q) || (t.handle || "").toLowerCase().includes(q));
            const users = await searchProfiles(term);
            const existing = new Set(targets.map(t => t.key));
            const directUserIds = new Set(state.chats.filter(e => !e.chat.is_group && e.other).map(e => e.other.id));
            users.forEach(u => {
                const key = "user:" + u.id;
                if (!existing.has(key) && !directUserIds.has(u.id)) {
                    targets.push({ key, type: "user", userId: u.id, title: u.username, url: u.avatar_url, handle: u.handle || "", isGroup: false });
                }
            });
        }
        renderForwardTargets(targets);
    }, 220));
    el("forward-send").addEventListener("click", doForward);
}

async function doForward() {
    const src = forwardSourceMsg;
    const share = state.sharePayload;
    if ((!src && !share) || !forwardSelection.size) return;
    const btn = el("forward-send");
    const defaultLabel = share ? "Отправить" : "Переслать";
    btn.disabled = true; btn.textContent = share ? "Отправляем…" : "Пересылаем…";

    // Для картинки из «Поделиться» — грузим один раз и переиспользуем ссылку.
    let sharedImageUrl = null;
    let lastChatId = null;
    try {
        if (share && share.kind === "image") {
            const file = dataUrlToFile(share.dataUrl, `shared_${Date.now()}.jpg`);
            if (!file) throw new Error("Не удалось прочитать изображение");
            sharedImageUrl = await uploadToBucket(CFG.MEDIA_BUCKET, file, "shared/" + state.user.id);
        }

        for (const t of forwardSelection.values()) {
            let chatId = t.chatId;
            if (t.type === "user") {
                const { data, error } = await sb.rpc("get_or_create_direct_chat", { other_user: t.userId });
                if (error) throw error;
                chatId = data;
            }

            let row;
            if (share) {
                row = {
                    chat_id: chatId,
                    sender_id: state.user.id,
                    text: share.kind === "text" ? share.text : (share.caption || null),
                    media_url: share.kind === "image" ? sharedImageUrl : null,
                    media_type: share.kind === "image" ? "image" : null
                };
            } else {
                const origin = src.forwarded_from || src.sender_id;
                row = {
                    chat_id: chatId,
                    sender_id: state.user.id,
                    text: src.text || null,
                    media_url: src.media_url || null,
                    media_type: src.media_type || null,
                    forwarded_from: origin
                };
            }
            const { error: insErr } = await sb.from("messages").insert(row);
            if (insErr) throw insErr;
            lastChatId = chatId;
        }

        const count = forwardSelection.size;
        state.sharePayload = null;
        closeModal("forward-modal");
        toast(count > 1 ? `Отправлено в ${count} чата(ов)` : (share ? "Отправлено" : "Сообщение переслано"));
        await loadChats();
        if (lastChatId) { switchSidebarTab("chats"); await openChat(lastChatId); }
    } catch (err) {
        console.error(err);
        toast(err.message || "Не удалось отправить", true);
    } finally {
        btn.disabled = false; btn.textContent = defaultLabel;
    }
}

async function togglePin(msgId) {
    const m = state.messages.find(x => x.id === msgId);
    if (!m) return;
    const newVal = !m.is_pinned;
    const patch = newVal
        ? { is_pinned: true, pinned_at: new Date().toISOString(), pinned_by: state.user.id }
        : { is_pinned: false, pinned_at: null, pinned_by: null };
    const { error } = await sb.from("messages").update(patch).eq("id", msgId);
    if (error) { console.error(error); toast("Не удалось изменить закрепление", true); return; }
    Object.assign(m, patch);
    state.pinnedIndex = 0;
    replaceMessageNode(msgId, m);
    renderPinnedBar();
    toast(newVal ? "Сообщение закреплено" : "Сообщение откреплено");
}

/* ------------------------------------------------------------------ *
 *  8. ГАЛОЧКИ ПРОЧТЕНИЯ / ДОСТАВКИ
 * ------------------------------------------------------------------ */
async function markChatRead(chatId) {
    const entry = getChatEntry(chatId);
    if (entry) { entry.unread = 0; renderChatList(); }
    await sb.from("messages").update({ is_read: true, is_delivered: true })
        .eq("chat_id", chatId).neq("sender_id", state.user.id).eq("is_read", false);
    // Сразу сообщаем собеседнику, что его сообщения прочитаны (мгновенные синие галочки).
    broadcastRead(chatId);
}

// Помечаем НАШИ исходящие сообщения как прочитанные прямо в открытой ленте —
// по мгновенному сигналу от собеседника (broadcast), без ожидания realtime-UPDATE БД.
function markMyOutgoingRead() {
    let changed = false;
    state.messages.forEach(m => {
        if (m.sender_id === state.user.id && !m.is_read) {
            m.is_read = true;
            m.is_delivered = true;
            replaceMessageNode(m.id, m);
            changed = true;
        }
    });
    if (changed) {
        const entry = getChatEntry(state.activeChatId);
        if (entry && entry.lastMessage && entry.lastMessage.sender_id === state.user.id) {
            entry.lastMessage.is_read = true;
            entry.lastMessage.is_delivered = true;
        }
        renderChatList();
    }
}

// Broadcast «я прочитал» в канал текущего чата — собеседник мгновенно увидит синие галочки.
function broadcastRead(chatId) {
    try {
        if (typingChannel && state.activeChatId === chatId) {
            typingChannel.send({ type: "broadcast", event: "read", payload: { user_id: state.user.id } });
        }
    } catch (_) {}
}

async function markDelivered(m) {
    if (m.sender_id === state.user.id) return;
    if (!m.is_delivered) {
        await sb.from("messages").update({ is_delivered: true }).eq("id", m.id);
    }
}

/* ------------------------------------------------------------------ *
 *  9. РЕАКЦИИ / УДАЛЕНИЕ / ОТВЕТ / КОНТЕКСТНОЕ МЕНЮ
 * ------------------------------------------------------------------ */
let ctxMessageId = null;
function openContextMenu(msgId, x, y) {
    const m = state.messages.find(z => z.id === msgId);
    if (!m || m.is_deleted) return;
    ctxMessageId = msgId;
    const menu = el("context-menu");
    const delItem = menu.querySelector('[data-action="delete"]');
    delItem.style.display = (m && m.sender_id === state.user.id) ? "flex" : "none";
    // Изменить можно только СВОЁ текстовое сообщение.
    const editItem = menu.querySelector('[data-action="edit"]');
    if (editItem) editItem.style.display = (m && m.sender_id === state.user.id && m.text) ? "flex" : "none";
    const copyItem = menu.querySelector('[data-action="copy"]');
    copyItem.style.display = (m && m.text) ? "flex" : "none";
    const pinItem = menu.querySelector('[data-action="pin"]');
    if (pinItem) pinItem.textContent = m.is_pinned ? "📌 Открепить" : "📌 Закрепить";

    show(menu);
    const mw = menu.offsetWidth, mh = menu.offsetHeight;
    let px = Math.min(x, window.innerWidth - mw - 10);
    let py = Math.min(y, window.innerHeight - mh - 10);
    menu.style.left = Math.max(8, px) + "px";
    menu.style.top = Math.max(8, py) + "px";
}
function closeContextMenu() { hide(el("context-menu")); ctxMessageId = null; }

function setupContextMenu() {
    const menu = el("context-menu");
    menu.querySelectorAll("[data-emoji]").forEach(btn => btn.addEventListener("click", () => {
        toggleReaction(ctxMessageId, btn.dataset.emoji);
        closeContextMenu();
    }));
    menu.querySelectorAll("[data-action]").forEach(li => li.addEventListener("click", () => {
        const act = li.dataset.action;
        if (act === "reply") startReply(ctxMessageId);
        else if (act === "edit") startEdit(ctxMessageId);
        else if (act === "forward") openForwardModal(ctxMessageId);
        else if (act === "pin") togglePin(ctxMessageId);
        else if (act === "delete") deleteForEveryone(ctxMessageId);
        else if (act === "copy") {
            const m = state.messages.find(x => x.id === ctxMessageId);
            if (m?.text) { copyText(m.text); }
        }
        closeContextMenu();
    }));
    document.addEventListener("click", (e) => { if (!menu.contains(e.target)) closeContextMenu(); });
}

async function toggleReaction(msgId, emoji) {
    if (!msgId) return;
    const existing = (state.reactionsByMsg[msgId] || []).find(r => r.user_id === state.user.id);
    if (existing && existing.emoji === emoji) {
        await sb.from("message_reactions").delete().eq("message_id", msgId).eq("user_id", state.user.id);
    } else {
        await sb.from("message_reactions").upsert(
            { message_id: msgId, user_id: state.user.id, emoji },
            { onConflict: "message_id,user_id" }
        );
    }
    await refreshReactions(msgId);
}

async function refreshReactions(msgId) {
    const { data } = await sb.from("message_reactions").select("*").eq("message_id", msgId);
    state.reactionsByMsg[msgId] = data || [];
    const m = state.messages.find(x => x.id === msgId);
    if (m) replaceMessageNode(msgId, m);
}

async function deleteForEveryone(msgId) {
    const m = state.messages.find(x => x.id === msgId);
    if (!m || m.sender_id !== state.user.id) return;
    const { error } = await sb.from("messages")
        .update({ is_deleted: true, text: "Сообщение удалено", media_url: null, media_type: null, is_pinned: false, pinned_at: null, pinned_by: null })
        .eq("id", msgId);
    if (error) { toast("Не удалось удалить", true); return; }
    m.is_deleted = true; m.text = "Сообщение удалено"; m.media_url = null; m.media_type = null; m.is_pinned = false;
    replaceMessageNode(msgId, m);
    renderPinnedBar();
}

function startReply(msgId) {
    const m = state.messages.find(x => x.id === msgId);
    if (!m) return;
    cancelEdit();              // ответ и редактирование — взаимоисключающие
    state.replyTo = m;
    updateReplyPreview();
    el("message-input").focus();
}

/* ---- Редактирование своего сообщения ---- */
function startEdit(msgId) {
    const m = state.messages.find(x => x.id === msgId);
    if (!m || m.is_deleted || m.sender_id !== state.user.id) return;
    if (!m.text) { toast("Можно изменить только текст сообщения", true); return; }
    state.replyTo = null; updateReplyPreview();   // выходим из режима ответа
    state.editing = m;
    updateEditPreview();
    const input = el("message-input");
    input.value = m.text;
    input.dispatchEvent(new Event("input"));       // покажет кнопку «Отправить», подгонит высоту
    input.focus();
    try { input.setSelectionRange(input.value.length, input.value.length); } catch (_) {}
}

function updateEditPreview() {
    const box = el("edit-preview");
    if (!box) return;
    if (!state.editing) { hide(box); return; }
    el("edit-preview-text").textContent = clip(state.editing.text, 60);
    show(box);
}

function cancelEdit(clearInput) {
    if (!state.editing) return;
    state.editing = null;
    updateEditPreview();
    if (clearInput) {
        const input = el("message-input");
        input.value = "";
        input.dispatchEvent(new Event("input"));
    }
}

async function commitEdit() {
    const m = state.editing;
    if (!m) return;
    const input = el("message-input");
    const text = input.value.trim();
    if (!text) { toast("Сообщение не может быть пустым", true); return; }
    if (text === m.text) { cancelEdit(true); return; }   // ничего не изменилось

    const editedAt = new Date().toISOString();
    // Пытаемся сохранить и отметку времени изменения. Если столбца edited_at
    // ещё нет в базе — повторяем без него (сообщение всё равно изменится).
    let { error } = await sb.from("messages").update({ text, edited_at: editedAt }).eq("id", m.id);
    let gotEdited = !error;
    if (error) {
        const res = await sb.from("messages").update({ text }).eq("id", m.id);
        error = res.error;
    }
    if (error) { console.error(error); toast("Не удалось изменить сообщение", true); return; }

    m.text = text;
    if (gotEdited) m.edited_at = editedAt;
    const idx = state.messages.findIndex(x => x.id === m.id);
    if (idx >= 0) state.messages[idx] = { ...state.messages[idx], text, edited_at: m.edited_at };
    replaceMessageNode(m.id, state.messages[idx] || m);

    // Обновим сниппет в списке чатов, если это последнее сообщение.
    const entry = getChatEntry(m.chat_id);
    if (entry && entry.lastMessage && entry.lastMessage.id === m.id) {
        entry.lastMessage = { ...entry.lastMessage, text };
        renderChatList();
    }

    cancelEdit(true);
    toast("Сообщение изменено");
}

function updateReplyPreview() {
    const box = el("reply-preview");
    if (!state.replyTo) { hide(box); return; }
    const m = state.replyTo;
    const name = m.sender_id === state.user.id ? "Вы" : (state.profilesCache[m.sender_id]?.username || "Пользователь");
    el("reply-preview-name").textContent = name;
    el("reply-preview-text").textContent = clip(snippetForMessage(m), 48);
    show(box);
}

/* ------------------------------------------------------------------ *
 *  10. ПРИСУТСТВИЕ + «ПЕЧАТАЕТ…»
 * ------------------------------------------------------------------ */
function subscribePresence() {
    const channel = sb.channel("online-users", { config: { presence: { key: state.user.id } } });
    channel.on("presence", { event: "sync" }, () => {
        const st = channel.presenceState();
        const online = {};
        Object.keys(st).forEach(uid => { online[uid] = true; });
        state.presence = online;
        renderChatList();
        updateChatHeaderStatus();
        // Собеседник   олько что вышел из сети — обновим его last_seen, чтобы время было точным.
        const activeEntry = getChatEntry(state.activeChatId);
        if (activeEntry && !activeEntry.chat.is_group && activeEntry.other && !online[activeEntry.other.id]) {
            refreshActiveChatOther();
        }
    });
    channel.subscribe(async (status) => {
        if (status === "SUBSCRIBED") {
            await channel.track({ user_id: state.user.id, online_at: new Date().toISOString() });
        }
    });
    state.channels.presence = channel;
}

async function setOffline() {
    if (state.user) {
        await sb.from("profiles").update({ last_seen: new Date().toISOString() }).eq("id", state.user.id);
    }
    if (state.channels.presence) { try { await state.channels.presence.untrack(); } catch (_) {} }
}

function startHeartbeat() {
    const beat = () => {
        if (state.user) sb.from("profiles").update({ last_seen: new Date().toISOString() }).eq("id", state.user.id);
    };
    beat();                    // сразу отмечаем присутствие при входе
    setInterval(beat, 30000);  // и далее каждые 30 секунд
}

/* ------------------------------------------------------------------ *
 *  ПРИНУДИТЕЛЬНЫЙ СБРОС КЕША У ВСЕХ КЛИЕНТОВ
 *  Версия статики хранится в app_settings.asset_version. Админка
 *  (отдельный локальный файл) повышает её; здесь мы ловим изменение
 *  через realtime и перезагружаемся с новой версией в ?v=..., что
 *  заставляет браузер и WebView скачать свежие app.js / style.css.
 * ------------------------------------------------------------------ */
function currentAssetVersion() {
    return parseInt(localStorage.getItem("centr_asset_v") || "1", 10) || 1;
}

async function checkAssetVersion() {
    try {
        const { data, error } = await sb.from("app_settings").select("asset_version").eq("id", 1).maybeSingle();
        if (error || !data) return;
        const remote = parseInt(data.asset_version, 10) || 1;
        if (remote > currentAssetVersion()) forceRefreshApp(remote);
    } catch (_) {}
}

function subscribeAppSettings() {
    const ch = sb.channel("app-settings")
        .on("postgres_changes",
            { event: "UPDATE", schema: "public", table: "app_settings" },
            (payload) => {
                const remote = parseInt(payload.new && payload.new.asset_version, 10) || 1;
                if (remote > currentAssetVersion()) forceRefreshApp(remote);
            })
        .subscribe();
    state.channels.appSettings = ch;
    // На случай, если обновление случилось, пока клиент был закрыт.
    checkAssetVersion();
}

async function forceRefreshApp(newVersion) {
    try {
        localStorage.setItem("centr_asset_v", String(newVersion));
        // Чистим кэш списка чатов, чтобы не остались старые данные.
        Object.keys(localStorage).forEach(k => { if (k.indexOf("centr_chats_") === 0) localStorage.removeItem(k); });
        if (window.caches && caches.keys) {
            const names = await caches.keys();
            await Promise.all(names.map(n => caches.delete(n)));
        }
    } catch (_) {}
    // Нативная оболочка умеет чистить кеш WebView — если мост есть, зовём его.
    if (window.CentrNative && typeof window.CentrNative.clearCache === "function") {
        try { window.CentrNative.clearCache(); return; } catch (_) {}
    }
    location.reload();
}

/* ---- Трансляция «печатае  …» (на активный чат), дебаунс 2 секунды ---- */
let typingChannel = null;
let typingSentAt = 0;
let typingStopTimer = null;

function subscribeTyping(chatId) {
    if (typingChannel) { sb.removeChannel(typingChannel); typingChannel = null; }
    typingChannel = sb.channel(`typing:${chatId}`);
    typingChannel.on("broadcast", { event: "typing" }, (payload) => {
        const { user_id, typing } = payload.payload;
        if (user_id === state.user.id) return;
        const entry = getChatEntry(chatId);
        if (!entry) return;
        entry.typing = typing ? user_id : null;
        clearTimeout(state.typingTimers[chatId]);
        if (typing) {
            state.typingTimers[chatId] = setTimeout(() => { entry.typing = null; updateChatHeaderStatus(); renderChatList(); }, 4000);
        }
        updateChatHeaderStatus();
        renderChatList();
    });
    // Мгновенные «прочитано»: собеседник открыл чат и прочитал наши сообщения.
    typingChannel.on("broadcast", { event: "read" }, (payload) => {
        if (payload.payload && payload.payload.user_id === state.user.id) return;
        markMyOutgoingRead();
    });
    typingChannel.subscribe();
}

function broadcastTyping() {
    if (!typingChannel || !state.activeChatId) return;
    const now = Date.now();
    if (now - typingSentAt > 1500) {
        typingSentAt = now;
        typingChannel.send({ type: "broadcast", event: "typing", payload: { user_id: state.user.id, typing: true } });
    }
    clearTimeout(typingStopTimer);
    typingStopTimer = setTimeout(stopTypingBroadcast, 2000);
}

function stopTypingBroadcast() {
    clearTimeout(typingStopTimer);
    typingSentAt = 0;
    if (typingChannel) {
        typingChannel.send({ type: "broadcast", event: "typing", payload: { user_id: state.user.id, typing: false } });
    }
}

/* ------------------------------------------------------------------ *
 *  11. ДРУЗЬЯ
 * ------------------------------------------------------------------ */
async function loadFriends() {
    const me = state.user.id;
    const { data, error } = await sb.from("friendships")
        .select("*")
        .or(`requester_id.eq.${me},addressee_id.eq.${me}`);
    if (error) { console.error(error); return; }

    const rows = data || [];
    const otherIds = rows.map(r => r.requester_id === me ? r.addressee_id : r.requester_id);
    await cacheProfiles(otherIds);

    state.friends = [];
    state.incoming = [];
    state.outgoing = [];

    rows.forEach(r => {
        const otherId = r.requester_id === me ? r.addressee_id : r.requester_id;
        const prof = state.profilesCache[otherId];
        if (!prof) return;
        if (r.status === "accepted") state.friends.push(prof);
        else if (r.status === "pending" && r.addressee_id === me) state.incoming.push(prof);
        else if (r.status === "pending" && r.requester_id === me) state.outgoing.push(prof);
    });

    state.friends.sort((a, b) => (a.username || "").localeCompare(b.username || ""));
    updateFriendsBadge();
    if (state.sidebarTab === "friends") renderFriends();
}

function updateFriendsBadge() {
    const badge = el("friends-badge");
    const n = state.incoming.length;
    badge.textContent = n;
    badge.classList.toggle("hidden", n === 0);
}

function friendStatusWith(userId) {
    if (state.friends.some(p => p.id === userId)) return "friends";
    if (state.incoming.some(p => p.id === userId)) return "incoming";
    if (state.outgoing.some(p => p.id === userId)) return "outgoing";
    return "none";
}

function renderFriends() {
    const reqBox = el("friend-requests");
    const listBox = el("friends-list");
    const label = el("friends-list-label");
    const empty = el("friends-empty");

    // Входящие заявки
    if (state.incoming.length) {
        reqBox.innerHTML = `<div class="section-label">Заявки в друзья (${state.incoming.length})</div>` +
            state.incoming.map(p => `
            <div class="request-item">
                <span class="avatar" data-openuser="${p.id}">
                    ${p.avatar_url ? `<img src="${esc(p.avatar_url)}" alt="">` : `<span class="avatar-fallback">${esc(initials(p.username))}</span>`}
                </span>
                <div class="user-item-info" data-openuser="${p.id}">
                    <div class="user-item-name">${esc(p.username)}</div>
                    <div class="user-item-handle">@${esc(p.handle || "")}</div>
                </div>
                <div class="request-actions">
                    <button class="request-accept" data-accept="${p.id}" title="Принять">✓</button>
                    <button class="request-decline" data-decline="${p.id}" title="Отклонить">✕</button>
                </div>
            </div>`).join("");
    } else {
        reqBox.innerHTML = "";
    }

    // Список друзей (с учётом поиска в сайдбаре)
    let friends = state.friends;
    if (state.searchTerm) {
        const q = state.searchTerm.toLowerCase();
        friends = friends.filter(p => (p.username || "").toLowerCase().includes(q) || (p.handle || "").toLowerCase().includes(q));
    }

    if (!state.friends.length) {
        label.classList.add("hidden");
        listBox.innerHTML = "";
        show(empty);
    } else {
        label.classList.remove("hidden");
        hide(empty);
        listBox.innerHTML = friends.map(p => {
            const online = state.presence[p.id] ? '<span class="online-dot"></span>' : "";
            return `
            <div class="user-item" data-friend="${p.id}">
                <span class="avatar">
                    ${p.avatar_url ? `<img src="${esc(p.avatar_url)}" alt="">` : `<span class="avatar-fallback">${esc(initials(p.username))}</span>`}
                    ${online}
                </span>
                <div class="user-item-info">
                    <div class="user-item-name">${esc(p.username)}</div>
                    <div class="user-item-status">${esc(p.status_text || "@" + (p.handle || ""))}</div>
                </div>
                <div class="user-item-action">
                    <button class="mini-btn" data-message="${p.id}">Написать</button>
                </div>
            </div>`;
        }).join("");
    }

    // навешиваем обработчики
    reqBox.querySelectorAll("[data-accept]").forEach(b => b.addEventListener("click", () => respondFriendRequest(b.dataset.accept, true)));
    reqBox.querySelectorAll("[data-decline]").forEach(b => b.addEventListener("click", () => respondFriendRequest(b.dataset.decline, false)));
    reqBox.querySelectorAll("[data-openuser]").forEach(n => n.addEventListener("click", () => openUserProfile(n.dataset.openuser)));
    listBox.querySelectorAll("[data-message]").forEach(b => b.addEventListener("click", (e) => { e.stopPropagation(); startDirectChat(b.dataset.message); }));
    listBox.querySelectorAll("[data-friend]").forEach(n => n.addEventListener("click", () => openUserProfile(n.dataset.friend)));
}

async function sendFriendRequest(userId) {
    try {
        const { data, error } = await sb.rpc("send_friend_request", { addressee: userId });
        if (error) throw error;
        if (data === "accepted") toast("Теперь вы друзья 🎉");
        else toast("Заявка отправлена");
        await loadFriends();
        return data;
    } catch (err) {
        console.error(err);
        toast(err.message || "Не удалось   тправить заявку", true);
        return null;
    }
}

async function respondFriendRequest(requesterId, accept) {
    try {
        const { error } = await sb.rpc("respond_friend_request", { requester: requesterId, accept });
        if (error) throw error;
        toast(accept ? "Заявка принята" : "Заявка отклонена");
        await loadFriends();
        if (accept) await loadChats();
    } catch (err) {
        console.error(err);
        toast(err.message || "Не удалось обработать заявку", true);
    }
}

async function removeFriend(userId) {
    try {
        const { error } = await sb.rpc("remove_friend", { other: userId });
        if (error) throw error;
        toast("Удалено");
        await loadFriends();
    } catch (err) {
        console.error(err);
        toast(err.message || "Не удалось удалить", true);
    }
}

function switchSidebarTab(tab) {
    state.sidebarTab = tab;
    $$(".sidebar-tab").forEach(b => b.classList.toggle("active", b.dataset.tab === tab));
    el("panel-chats").classList.toggle("hidden", tab !== "chats");
    el("panel-friends").classList.toggle("hidden", tab !== "friends");
    el("search-input").placeholder = tab === "friends" ? "Поиск друзей…" : "Поиск чатов…";
    if (tab === "friends") renderFriends(); else renderChatList();
}

/* ------------------------------------------------------------------ *
 *  12. ПРОФИЛЬ СОБЕСЕДНИКА / ИНФО КОНТАКТА + ИНФО ГРУППЫ
 * ------------------------------------------------------------------ */
async function fetchProfile(userId) {
    if (state.profilesCache[userId]) return state.profilesCache[userId];
    const { data } = await sb.from("profiles").select("*").eq("id", userId).maybeSingle();
    if (data) state.profilesCache[data.id] = data;
    return data;
}

async function openUserProfile(userId) {
    const prof = await fetchProfile(userId);
    if (!prof) { toast("Профиль не найден", true); return; }
    state.viewProfile = prof;

    paintAvatar(el("up-avatar-img"), el("up-avatar-fallback"), prof.avatar_url, prof.username);
    el("up-avatar").onclick = () => { if (prof.avatar_url) openLightbox(prof.avatar_url, "image"); };
    el("up-name").textContent = prof.username || "Пользователь";
    el("up-handle").textContent = prof.handle ? "@" + prof.handle : "";
    el("up-status").textContent = prof.status_text || "";
    el("up-link").value = profileLink(prof);
    el("up-copy").onclick = () => copyText(el("up-link").value);

    const presenceEl = el("up-presence");
    if (userId === state.user.id) {
        presenceEl.textContent = "Это вы";
    } else if (state.presence[userId]) {
        presenceEl.textContent = "в сети";
    } else {
        presenceEl.textContent = fmtLastSeen(prof.last_seen);
    }

    const btnFriend = el("up-friend");
    const btnRemove = el("up-remove-friend");
    const btnMsg = el("up-message");

    hide(btnFriend); hide(btnRemove); hide(btnMsg);

    if (userId !== state.user.id) {
        show(btnMsg);
        btnMsg.textContent = "Написать";
        btnMsg.onclick = () => { closeModal("userprofile-modal"); startDirectChat(userId); };

        const status = friendStatusWith(userId);
        if (status === "friends") {
            show(btnRemove);
            btnRemove.textContent = "Удалить из друзей";
            btnRemove.onclick = async () => { await removeFriend(userId); closeModal("userprofile-modal"); };
        } else if (status === "incoming") {
            show(btnFriend);
            btnFriend.textContent = "Принять заявку";
            btnFriend.onclick = async () => { await respondFriendRequest(userId, true); await loadChats(); closeModal("userprofile-modal"); };
            show(btnRemove);
            btnRemove.textContent = "Отклонить";
            btnRemove.onclick = async () => { await respondFriendRequest(userId, false); closeModal("userprofile-modal"); };
        } else if (status === "outgoing") {
            show(btnFriend);
            btnFriend.textContent = "Заявка отправлена";
            btnFriend.disabled = true;
            show(btnRemove);
            btnRemove.textContent = "Отменить заявку";
            btnRemove.onclick = async () => { await removeFriend(userId); closeModal("userprofile-modal"); };
        } else {
            show(btnFriend);
            btnFriend.disabled = false;
            btnFriend.textContent = "Добавить в друзья";
            btnFriend.onclick = async () => { await sendFriendRequest(userId); openUserProfile(userId); };
        }
    }
    // сбросить disabled при повторном использовании
    if (friendStatusWith(userId) !== "outgoing") el("up-friend").disabled = false;

    openModal("userprofile-modal");
}

async function openUserProfileByKey(key) {
    let query = sb.from("profiles").select("*");
    query = UUID_RE.test(key) ? query.eq("id", key) : query.eq("handle", normalizeHandle(key));
    const { data } = await query.maybeSingle();
    if (!data) { toast("Пользователь не найден", true); return; }
    state.profilesCache[data.id] = data;
    openUserProfile(data.id);
}

/* ---- Инфо группы ---- */
function openGroupInfo() {
    const entry = getChatEntry(state.activeChatId);
    if (!entry || !entry.chat.is_group) return;

    paintAvatar(el("gi-avatar-img"), el("gi-avatar-fallback"), entry.chat.avatar_url, entry.chat.name);
    el("gi-name").textContent = entry.chat.name || "Группа";
    el("gi-count").textContent = `${entry.participants.length} ${pluralMembers(entry.participants.length)}`;
    el("gi-link").value = groupLink(entry.chat.id);
    el("gi-copy").onclick = () => copyText(el("gi-link").value);
    el("gi-add-member").onclick = () => openAddMemberModal(entry.chat.id);
    el("gi-leave").onclick = () => leaveGroup(entry.chat.id);

    // Смена аватара группы: выбор файла → кроппер → загрузка → обновление chats.
    el("gi-avatar-input").onchange = async (e) => {
        const file = e.target.files[0];
        e.target.value = "";
        if (!file) return;
        const cropped = await openCropper(file);
        if (!cropped) return;
        try {
            const url = await uploadToBucket(CFG.AVATAR_BUCKET, cropped, "group_" + entry.chat.id);
            const { error } = await sb.from("chats").update({ avatar_url: url }).eq("id", entry.chat.id);
            if (error) throw error;
            entry.chat.avatar_url = url;
            paintAvatar(el("gi-avatar-img"), el("gi-avatar-fallback"), url, entry.chat.name);
            if (state.activeChatId === entry.chat.id) {
                paintAvatar(el("chat-header-avatar-img"), el("chat-header-avatar-fallback"), url, entry.chat.name);
            }
            renderChatList();
            saveChatsCache();
            toast("Аватар группы обновлён");
        } catch (err) {
            console.error(err);
            toast(err.message || "Не удалось обновить аватар", true);
        }
    };

    // Переименование группы.
    el("gi-rename").onclick = async () => {
        const name = prompt("Название группы:", entry.chat.name || "");
        if (name == null) return;
        const trimmed = name.trim();
        if (!trimmed) { toast("Название не может быть пустым", true); return; }
        try {
            const { error } = await sb.from("chats").update({ name: trimmed }).eq("id", entry.chat.id);
            if (error) throw error;
            entry.chat.name = trimmed;
            el("gi-name").textContent = trimmed;
            if (state.activeChatId === entry.chat.id) el("chat-header-name").textContent = trimmed;
            updateChatHeaderStatus();
            renderChatList();
            saveChatsCache();
            toast("Группа переименована");
        } catch (err) {
            console.error(err);
            toast(err.message || "Не удалось переименовать", true);
        }
    };

    renderGroupMembers(entry);
    openModal("groupinfo-modal");
}

function renderGroupMembers(entry) {
    const box = el("gi-members");
    const members = entry.participants
        .map(p => state.profilesCache[p.user_id])
        .filter(Boolean);
    box.innerHTML = members.map(p => {
        const isMe = p.id === state.user.id;
        const online = state.presence[p.id] ? '<span class="online-dot"></span>' : "";
        return `
        <div class="user-item" data-member="${p.id}">
            <span class="avatar">
                ${p.avatar_url ? `<img src="${esc(p.avatar_url)}" alt="">` : `<span class="avatar-fallback">${esc(initials(p.username))}</span>`}
                ${online}
            </span>
            <div class="user-item-info">
                <div class="user-item-name">${esc(p.username)}${isMe ? ' <span class="gi-you">(вы)</span>' : ""}</div>
                <div class="user-item-status">@${esc(p.handle || "")}</div>
            </div>
        </div>`;
    }).join("");
    box.querySelectorAll("[data-member]").forEach(n => n.addEventListener("click", () => {
        const id = n.dataset.member;
        if (id !== state.user.id) openUserProfile(id);
    }));
}

async function leaveGroup(chatId) {
    if (!confirm("Выйти из этой группы?")) return;
    try {
        const { error } = await sb.from("chat_participants").delete()
            .eq("chat_id", chatId).eq("user_id", state.user.id);
        if (error) throw error;
        closeModal("groupinfo-modal");
        state.activeChatId = null;
        show(el("welcome-screen"));
        hide(el("chat-view"));
        el("messenger").classList.remove("chat-open");
        await loadChats();
        toast("Вы вышли из группы");
    } catch (err) {
        console.error(err);
        toast(err.message || "Не удалось выйти", true);
    }
}

let addMemberChatId = null;
function openAddMemberModal(chatId) {
    addMemberChatId = chatId;
    el("addmember-search").value = "";
    openModal("addmember-modal");
    renderAddMemberList(state.friends);
    el("addmember-search").focus();
}

function existingMemberIds(chatId) {
    const entry = getChatEntry(chatId);
    return new Set((entry?.participants || []).map(p => p.user_id));
}

function renderAddMemberList(users) {
    const box = el("addmember-list");
    const already = existingMemberIds(addMemberChatId);
    const list = users.filter(u => u.id !== state.user.id);
    if (!list.length) { box.innerHTML = `<div class="section-label">Никого не найдено</div>`; return; }
    box.innerHTML = list.map(u => {
        const inGroup = already.has(u.id);
        return `
        <div class="user-item">
            ${avatarHTML(u.avatar_url, u.username, "sm")}
            <div class="user-item-info">
                <div class="user-item-name">${esc(u.username)}</div>
                <div class="user-item-handle">@${esc(u.handle || "")}</div>
            </div>
            <div class="user-item-action">
                ${inGroup ? `<button class="mini-btn ghost" disabled>В группе</button>`
                          : `<button class="mini-btn" data-add="${u.id}">Добавить</button>`}
            </div>
        </div>`;
    }).join("");
    box.querySelectorAll("[data-add]").forEach(b => b.addEventListener("click", () => addGroupMember(b.dataset.add)));
}

function setupAddMember() {
    el("addmember-search").addEventListener("input", debounce(async () => {
        const term = el("addmember-search").value.trim();
        if (!term) { renderAddMemberList(state.friends); return; }
        const users = await searchProfiles(term);
        renderAddMemberList(users);
    }, 220));
}

async function addGroupMember(userId) {
    try {
        const { error } = await sb.rpc("add_group_member", { _chat_id: addMemberChatId, _user_id: userId });
        if (error) throw error;
        toast("Участник добавлен");
        await loadChats();
        const entry = getChatEntry(addMemberChatId);
        if (entry) { renderGroupMembers(entry); el("gi-count").textContent = `${entry.participants.length} ${pluralMembers(entry.participants.length)}`; }
        renderAddMemberList(state.friends);
    } catch (err) {
        console.error(err);
        toast(err.message || "Не удалось добавить", true);
    }
}

/* ---- Вступление в группу по ссылке-приглашению ---- */
let joinGroupId = null;
async function promptJoinGroup(chatId) {
    joinGroupId = chatId;
    // Уже участник? Просто открыть.
    if (isMyChat(chatId)) { openChat(chatId); return; }
    try {
        const { data, error } = await sb.rpc("group_preview", { _chat_id: chatId });
        if (error) throw error;
        const g = (data || [])[0];
        if (!g) { toast("Группа не найдена", true); return; }
        paintAvatar(el("jg-avatar-img"), el("jg-avatar-fallback"), g.avatar_url, g.name);
        el("jg-name").textContent = g.name || "Группа";
        el("jg-count").textContent = `${g.member_count} ${pluralMembers(Number(g.member_count))}`;
        el("jg-join").onclick = () => joinGroup(chatId);
        openModal("joingroup-modal");
    } catch (err) {
        console.error(err);
        toast("Не удалось открыть приглашение", true);
    }
}

async function joinGroup(chatId) {
    try {
        const { data, error } = await sb.rpc("join_group_by_id", { _chat_id: chatId });
        if (error) throw error;
        closeModal("joingroup-modal");
        await loadChats();
        await openChat(data || chatId);
        toast("Вы вступили в группу");
    } catch (err) {
        console.error(err);
        toast(err.message || "Не удалось вступить", true);
    }
}

/* ------------------------------------------------------------------ *
 *  13. ПОИСК
 * ------------------------------------------------------------------ */
function setupSearch() {
    const input = el("search-input");
    const clear = el("search-clear");
    input.addEventListener("input", debounce(() => {
        state.searchTerm = input.value.trim();
        clear.classList.toggle("hidden", !state.searchTerm);
        if (state.sidebarTab === "friends") renderFriends();
        else renderChatList();
    }, 150));
    clear.addEventListener("click", () => {
        input.value = ""; state.searchTerm = ""; hide(clear);
        if (state.sidebarTab === "friends") renderFriends(); else renderChatList();
    });

    el("chat-search-btn").addEventListener("click", () => {
        el("chat-search-bar").classList.toggle("hidden");
        el("chat-search-input").focus();
    });
    el("chat-search-close").addEventListener("click", () => {
        hide(el("chat-search-bar"));
        el("chat-search-input").value = "";
        renderMessages();
    });
    el("chat-search-input").addEventListener("input", debounce(() => filterInChat(el("chat-search-input").value.trim()), 150));
}

// Поиск пользователей по ID / имени (для нового чата, друзей, участников группы).
async function searchProfiles(term) {
    const t = safeTerm(term);
    if (t.length < 1) return [];
    // ВНИМАНИЕ: внутри `or=(...)` в PostgREST маска ILIKE — это `*` (а не `%`).
    const { data } = await sb.from("profiles").select("*")
        .or(`handle.ilike.*${t}*,username.ilike.*${t}*`)
        .neq("id", state.user.id).limit(20);
    (data || []).forEach(p => { state.profilesCache[p.id] = p; });
    return data || [];
}

function filterInChat(term) {
    if (!term) { renderMessages(); return; }
    const q = term.toLowerCase();
    renderMessages();
    $$("[data-msg-row]").forEach(row => {
        const txt = row.querySelector(".bubble-text")?.textContent?.toLowerCase() || "";
        const match = txt.includes(q);
        row.style.display = match ? "" : "none";
        if (match) {
            const b = row.querySelector(".bubble-text");
            if (b) b.innerHTML = b.innerHTML.replace(new RegExp(`(${term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")})`, "ig"), '<mark style="background:#f6c14355;color:inherit">$1</mark>');
        }
    });
}

/* ------------------------------------------------------------------ *
 *  14. МОДАЛКИ + СТАРТ ЧАТА
 * ------------------------------------------------------------------ */
function openModal(id) { show(el(id)); }
function closeModal(id) { hide(el(id)); }

function userItemHTML(u) {
    return `
    <div class="user-item" data-user="${u.id}">
        ${avatarHTML(u.avatar_url, u.username, "sm")}
        <div class="user-item-info">
            <div class="user-item-name">${esc(u.username)}</div>
            <div class="user-item-handle">@${esc(u.handle || "")}</div>
        </div>
    </div>`;
}

function setupModals() {
    $$("[data-close-modal]").forEach(btn => btn.addEventListener("click", () => closeModal(btn.dataset.closeModal)));
    $$(".modal-overlay").forEach(ov => ov.addEventListener("click", (e) => { if (e.target === ov) hide(ov); }));

    el("my-avatar").addEventListener("click", openProfileModal);
    el("new-chat-btn").addEventListener("click", openNewChatModal);
    el("empty-new-chat").addEventListener("click", openNewChatModal);
    el("new-group-btn").addEventListener("click", openNewGroupModal);
    el("logout-btn").addEventListener("click", handleLogout);
    setupAccountSecurity();   // восстановление/смена пароля и смена почты (через письма)
    el("add-friend-btn").addEventListener("click", openAddFriendModal);

    // вкладки сайдбара
    $$(".sidebar-tab").forEach(b => b.addEventListener("click", () => switchSidebarTab(b.dataset.tab)));

    el("chat-back-btn").addEventListener("click", () => {
        el("messenger").classList.remove("chat-open");
        state.activeChatId = null;
        notifyNativeActiveChat("");   // из чата вышли — уведомления снова разрешены
        renderChatList();
    });
    el("reply-cancel").addEventListener("click", () => { state.replyTo = null; updateReplyPreview(); });
    el("edit-cancel").addEventListener("click", () => cancelEdit(true));

    // шапка -> профиль контакта или инфо группы
    const openActiveInfo = () => {
        const entry = getChatEntry(state.activeChatId);
        if (!entry) return;
        if (entry.chat.is_group) openGroupInfo();
        else if (entry.other) openUserProfile(entry.other.id);
    };
    el("chat-header-info").addEventListener("click", openActiveInfo);
    el("chat-info-btn").addEventListener("click", openActiveInfo);

    el("lightbox-close").addEventListener("click", closeLightbox);
    el("lightbox").addEventListener("click", (e) => { if (e.target === el("lightbox")) closeLightbox(); });

    document.addEventListener("keydown", (e) => {
        if (e.key === "Escape") { $$(".modal-overlay").forEach(hide); closeLightbox(); closeContextMenu(); el("emoji-picker").classList.add("hidden"); }
    });
    document.addEventListener("click", (e) => {
        const picker = el("emoji-picker");
        if (!picker.classList.contains("hidden") && !picker.contains(e.target) && e.target.id !== "emoji-btn") picker.classList.add("hidden");
    });
}

/* ---- Новый чат (1:1) — поиск по ID + друзья ---- */
function openNewChatModal() {
    el("newchat-search").value = "";
    openModal("newchat-modal");
    renderNewChatFriends();
    el("newchat-search").focus();
}
function renderNewChatFriends() {
    const box = el("newchat-user-list");
    if (!state.friends.length) {
        box.innerHTML = `<div class="section-label">Добавьте друзей, чтобы быстро начинать чаты</div>`;
        return;
    }
    box.innerHTML = `<div class="section-label">Друзья</div>` + state.friends.map(userItemHTML).join("");
    box.querySelectorAll("[data-user]").forEach(n => n.addEventListener("click", () => startDirectChat(n.dataset.user)));
}
function renderNewChatResults(users) {
    const box = el("newchat-user-list");
    if (!users.length) { box.innerHTML = `<div class="section-label">Никого не найдено по этому ID</div>`; return; }
    box.innerHTML = `<div class="section-label">Результаты</div>` + users.map(userItemHTML).join("");
    box.querySelectorAll("[data-user]").forEach(n => n.addEventListener("click", () => startDirectChat(n.dataset.user)));
}

async function startDirectChat(otherUserId) {
    try {
        const { data, error } = await sb.rpc("get_or_create_direct_chat", { other_user: otherUserId });
        if (error) throw error;
        const chatId = data;
        closeModal("newchat-modal");
        closeModal("userprofile-modal");
        el("search-input").value = ""; state.searchTerm = ""; hide(el("search-clear"));
        switchSidebarTab("chats");
        await loadChats();
        await openChat(chatId);
    } catch (err) {
        console.error(err);
        toast(err.message || "Не удалось открыть чат", true);
    }
}

function setupNewChatSearch() {
    el("newchat-search").addEventListener("input", debounce(async () => {
        const term = el("newchat-search").value.trim();
        if (!term) { renderNewChatFriends(); return; }
        const users = await searchProfiles(term);
        renderNewChatResults(users);
    }, 220));
}

/* ---- Модалка «Добавить друга» ---- */
function openAddFriendModal() {
    el("addfriend-search").value = "";
    el("addfriend-results").innerHTML = "";
    el("addfriend-myid").textContent = "@" + (state.profile?.handle || "—");
    openModal("addfriend-modal");
    el("addfriend-search").focus();
}
function friendActionButton(u) {
    const s = friendStatusWith(u.id);
    if (s === "friends") return `<button class="mini-btn ghost" disabled>В друзьях</button>`;
    if (s === "outgoing") return `<button class="mini-btn ghost" disabled>Отправлено</button>`;
    if (s === "incoming") return `<button class="mini-btn" data-accept="${u.id}">Принять</button>`;
    return `<button class="mini-btn" data-add="${u.id}">Добавить</button>`;
}
function renderAddFriendResults(users) {
    const box = el("addfriend-results");
    if (!users.length) { box.innerHTML = `<div class="section-label">Никого не найдено</div>`; return; }
    box.innerHTML = users.map(u => `
        <div class="user-item">
            <span data-openuser="${u.id}" style="display:flex;align-items:center;gap:12px;flex:1;min-width:0;">
                ${avatarHTML(u.avatar_url, u.username, "sm")}
                <span class="user-item-info">
                    <span class="user-item-name">${esc(u.username)}</span>
                    <span class="user-item-handle">@${esc(u.handle || "")}</span>
                </span>
            </span>
            <div class="user-item-action">${friendActionButton(u)}</div>
        </div>`).join("");
    box.querySelectorAll("[data-add]").forEach(b => b.addEventListener("click", async () => {
        await sendFriendRequest(b.dataset.add);
        const users2 = await searchProfiles(el("addfriend-search").value.trim());
        renderAddFriendResults(users2);
    }));
    box.querySelectorAll("[data-accept]").forEach(b => b.addEventListener("click", async () => {
        await respondFriendRequest(b.dataset.accept, true);
        await loadChats();
        const users2 = await searchProfiles(el("addfriend-search").value.trim());
        renderAddFriendResults(users2);
    }));
    box.querySelectorAll("[data-openuser]").forEach(n => n.addEventListener("click", () => openUserProfile(n.dataset.openuser)));
}
function setupAddFriend() {
    el("addfriend-search").addEventListener("input", debounce(async () => {
        const term = el("addfriend-search").value.trim();
        if (!term) { el("addfriend-results").innerHTML = ""; return; }
        const users = await searchProfiles(term);
        renderAddFriendResults(users);
    }, 220));
    el("addfriend-copymine").addEventListener("click", () => copyText(profileLink(state.profile)));
}

/* ---- Новая группа ---- */
const groupSelection = new Map();
function openNewGroupModal() {
    groupSelection.clear();
    el("newgroup-name").value = "";
    el("newgroup-search").value = "";
    el("newgroup-chips").innerHTML = "";
    el("newgroup-create").disabled = true;
    openModal("newgroup-modal");
    renderGroupUserList(state.friends);
}
function renderGroupUserList(users) {
    const box = el("newgroup-user-list");
    const list = users.filter(u => u.id !== state.user.id);
    if (!list.length) { box.innerHTML = `<div class="section-label">Нет друзей — найдите по ID</div>`; return; }
    box.innerHTML = list.map(u => {
        const sel = groupSelection.has(u.id) ? " selected" : "";
        return `<div class="user-item${sel}" data-guser="${u.id}">
            ${avatarHTML(u.avatar_url, u.username, "sm")}
            <div class="user-item-info"><div class="user-item-name">${esc(u.username)}</div><div class="user-item-handle">@${esc(u.handle || "")}</div></div>
            <div class="user-item-check">✓</div>
        </div>`;
    }).join("");
    box.querySelectorAll("[data-guser]").forEach(node => node.addEventListener("click", () => {
        const id = node.dataset.guser;
        if (groupSelection.has(id)) groupSelection.delete(id);
        else groupSelection.set(id, users.find(u => u.id === id) || state.profilesCache[id]);
        node.classList.toggle("selected");
        renderGroupChips();
    }));
}
function renderGroupChips() {
    const chips = el("newgroup-chips");
    chips.innerHTML = [...groupSelection.values()].map(u =>
        `<span class="chip">${esc(u.username)}<button data-remove="${u.id}">✕</button></span>`).join("");
    chips.querySelectorAll("[data-remove]").forEach(b => b.addEventListener("click", () => {
        groupSelection.delete(b.dataset.remove);
        renderGroupChips();
        const node = document.querySelector(`[data-guser="${b.dataset.remove}"]`);
        node && node.classList.remove("selected");
    }));
    el("newgroup-create").disabled = groupSelection.size < 1;
}
function setupNewGroup() {
    el("newgroup-search").addEventListener("input", debounce(async () => {
        const term = el("newgroup-search").value.trim();
        if (!term) { renderGroupUserList(state.friends); return; }
        const users = await searchProfiles(term);
        renderGroupUserList(users);
    }, 220));
    el("newgroup-create").addEventListener("click", async () => {
        const name = el("newgroup-name").value.trim() || "Новая группа";
        const members = [...groupSelection.keys()];
        const btn = el("newgroup-create");
        btn.disabled = true; btn.textContent = "Создаём…";
        try {
            const { data, error } = await sb.rpc("create_group_chat", { group_name: name, members });
            if (error) throw error;
            closeModal("newgroup-modal");
            switchSidebarTab("chats");
            await loadChats();
            await openChat(data);
            toast("Группа создана");
        } catch (err) {
            console.error(err);
            toast(err.message || "Не удалось создать группу", true);
        } finally {
            btn.disabled = false; btn.textContent = "Создать группу";
        }
    });
}

/* ---- Лайтбокс ---- */
function openLightbox(src, type) {
    const content = el("lightbox-content");
    content.innerHTML = type === "video"
        ? `<video src="${esc(src)}" controls autoplay></video>`
        : `<img src="${esc(src)}" alt="">`;
    show(el("lightbox"));
}
function closeLightbox() {
    el("lightbox-content").innerHTML = "";
    hide(el("lightbox"));
}

/* ------------------------------------------------------------------ *
 *  15. ДИПЛИНКИ  (?u=handle|id  |  ?g=groupId)
 * ------------------------------------------------------------------ */
function captureDeepLink() {
    const params = new URLSearchParams(location.search);
    const u = params.get("u");
    const g = params.get("g");
    const c = params.get("c");   // ?c=<chatId> — открыть конкретный чат (из уведомления)
    if (u) state.pendingDeepLink = { type: "user", value: u };
    else if (g) state.pendingDeepLink = { type: "group", value: g };
    else if (c) state.pendingDeepLink = { type: "chat", value: c };
    // убрать query, чтобы обновление страницы не повторяло действие
    if (u || g || c) history.replaceState({}, document.title, location.pathname);
}

async function runDeepLink() {
    const dl = state.pendingDeepLink;
    if (!dl) return;
    state.pendingDeepLink = null;
    if (dl.type === "user") await openUserProfileByKey(dl.value);
    else if (dl.type === "group") await promptJoinGroup(dl.value);
    else if (dl.type === "chat") await openChatDeepLink(dl.value);
}

// Открыть чат по id (из уведомления/ссылки) и прокрутить к последним сообщениям.
async function openChatDeepLink(chatId) {
    if (!chatId) return;
    chatId = String(chatId);
    if (!isMyChat(chatId)) { try { await loadChats(); } catch (_) {} }
    switchSidebarTab("chats");
    await openChat(chatId);
    scrollMessagesToBottom(true, false);
}

/* ------------------------------------------------------------------ *
 *  16. REALTIME-ПОДПИСКИ
 * ------------------------------------------------------------------ */
function subscribeRealtime() {
    const msgChannel = sb.channel("db-messages")
        .on("postgres_changes", { event: "INSERT", schema: "public", table: "messages" }, handleMessageInsert)
        .on("postgres_changes", { event: "UPDATE", schema: "public", table: "messages" }, handleMessageUpdate)
        .subscribe();

    const reactChannel = sb.channel("db-reactions")
        .on("postgres_changes", { event: "*", schema: "public", table: "message_reactions" }, handleReactionChange)
        .subscribe();

    const profChannel = sb.channel("db-profiles")
        .on("postgres_changes", { event: "UPDATE", schema: "public", table: "profiles" }, handleProfileUpdate)
        .subscribe();

    const partChannel = sb.channel("db-participants")
        .on("postgres_changes", { event: "INSERT", schema: "public", table: "chat_participants" }, (payload) => {
            if (payload.new.user_id === state.user.id) loadChats();
            else if (state.activeChatId === payload.new.chat_id) loadChats();
        })
        .on("postgres_changes", { event: "DELETE", schema: "public", table: "chat_participants" }, () => {
            loadChats();
        })
        .subscribe();

    const friendChannel = sb.channel("db-friendships")
        .on("postgres_changes", { event: "*", schema: "public", table: "friendships" }, () => {
            loadFriends();
        })
        .subscribe();

    state.channels.messages = msgChannel;
    state.channels.reactions = reactChannel;
    state.channels.profiles = profChannel;
    state.channels.participants = partChannel;
    state.channels.friendships = friendChannel;
}

function isMyChat(chatId) { return state.chats.some(e => e.chat.id === chatId); }

// Совпадает ли временное (оптимистичное) сообщение с пришедшим по realtime.
function sameMessage(a, b) {
    return !!a && !!b && a.sender_id === b.sender_id
        && (a.text || null) === (b.text || null)
        && (a.media_url || null) === (b.media_url || null)
        && (a.media_type || null) === (b.media_type || null);
}

async function handleMessageInsert(payload) {
    const m = payload.new;
    if (!isMyChat(m.chat_id)) { await loadChats(); return; }

    const incoming = m.sender_id !== state.user.id;

    if (m.chat_id === state.activeChatId) {
        // 1) Уже есть это сообщение (например, наше эхо после reconcile) — пропускаем.
        if (state.messages.some(x => x.id === m.id)) { bumpChatEntry(m); return; }

        // 2) Наше собственное эхо, а временное ещё висит — заменяем временное настоящим.
        if (!incoming) {
            const tmpIdx = state.messages.findIndex(x => x._pending && sameMessage(x, m));
            if (tmpIdx >= 0) {
                const tempId = state.messages[tmpIdx].id;
                state.messages[tmpIdx] = m;
                replaceMessageNode(tempId, m);
                bumpChatEntry(m);
                return;
            }
        }

        // 3) Новое сообщение — добавляем в конец ленты.
        const need = [m.sender_id];
        if (m.forwarded_from) need.push(m.forwarded_from);
        await cacheProfiles(need);

        const box = el("messages");
        const wasNear = box.scrollHeight - box.scrollTop - box.clientHeight < 160;

        state.messages.push(m);
        appendMessageRow(m, true);
        renderPinnedBar();

        if (incoming) {
            // Чат открыт и приложение на экране — пользователь и так видит сообщение,
            // поэтому НЕ звеним. Если приложение свёрнуто — даём знать (вибрация/звук).
            if (document.hidden) notifyIncoming();
            const entry = getChatEntry(m.chat_id);
            if (entry) entry.unread = 0;                 // чат открыт — считаем прочитанным
            sb.from("messages").update({ is_read: true, is_delivered: true }).eq("id", m.id);
            broadcastRead(m.chat_id);                    // мгновенно сообщаем отправителю «прочитано»
        }

        if (wasNear || !incoming) {
            scrollMessagesToBottom(true, true);          // плавно опускаемся к новому
            resetScrollBadge();
        } else {
            bumpScrollBadge();                           // читаем историю — не дёргаем, только счётчик
        }
    } else {
        await markDelivered(m);
        const entry = getChatEntry(m.chat_id);
        if (entry && incoming) entry.unread = (entry.unread || 0) + 1;
        if (incoming) notifyIncoming();
    }
    bumpChatEntry(m);
}

function handleMessageUpdate(payload) {
    const m = payload.new;
    if (!isMyChat(m.chat_id)) return;
    if (m.chat_id === state.activeChatId) {
        const idx = state.messages.findIndex(x => x.id === m.id);
        if (idx >= 0) {
            state.messages[idx] = { ...state.messages[idx], ...m };
            replaceMessageNode(m.id, state.messages[idx]);   // точечно, без сброса прокрутки
            renderPinnedBar();
        }
    }
    const entry = getChatEntry(m.chat_id);
    if (entry && entry.lastMessage && entry.lastMessage.id === m.id) {
        entry.lastMessage = { ...entry.lastMessage, ...m };
        renderChatList();
    }
}

async function handleReactionChange(payload) {
    const row = payload.new || payload.old;
    if (!row) return;
    if (state.messages.some(m => m.id === row.message_id)) {
        await refreshReactions(row.message_id);
    }
}

function handleProfileUpdate(payload) {
    const p = payload.new;
    state.profilesCache[p.id] = p;
    state.chats.forEach(e => { if (e.other && e.other.id === p.id) e.other = p; });
    state.friends = state.friends.map(f => f.id === p.id ? p : f);
    state.incoming = state.incoming.map(f => f.id === p.id ? p : f);
    state.outgoing = state.outgoing.map(f => f.id === p.id ? p : f);
    if (state.user && p.id === state.user.id) { state.profile = p; paintMyAvatar(); }
    renderChatList();
    if (state.sidebarTab === "friends") renderFriends();
    updateChatHeaderStatus();
}

function bumpChatEntry(m) {
    const entry = getChatEntry(m.chat_id);
    if (!entry) return;
    entry.lastMessage = m;
    state.chats.sort((a, b) =>
        new Date(b.lastMessage?.created_at || b.chat.created_at) - new Date(a.lastMessage?.created_at || a.chat.created_at));
    renderChatList();
}

function teardownRealtime() {
    Object.values(state.channels).forEach(ch => { try { sb.removeChannel(ch); } catch (_) {} });
    if (typingChannel) { try { sb.removeChannel(typingChannel); } catch (_) {} }
    state.channels = {};
    typingChannel = null;
}

/* ------------------------------------------------------------------ *
 *  17. МОСТ ПУШ-УВЕДОМЛЕНИЙ ДЛЯ НАТИВНОЙ ОБОЛОЧКИ (MAUI)
 * ------------------------------------------------------------------ */
async function saveDeviceToken(token, platform) {
    if (!token || !state.user) return;
    try {
        await sb.from("device_tokens").upsert(
            { user_id: state.user.id, token: token, platform: platform || "android", updated_at: new Date().toISOString() },
            { onConflict: "token" }
        );
    } catch (e) {
        console.warn("Не удалось сохранить пуш-токен:", e && e.message);
    }
}
// Вызывается из нативного кода (MAUI) после получения/обновления FCM-токена.
window.centrOnPushToken = function (token, platform) {
    window.__centrPushToken = { token, platform: platform || "android" };
    saveDeviceToken(token, platform);
};

/* ---- Сигналы в нативную оболочку через служебную схему centrnative:// ----
 *  Нативный WebViewClient перехватывает такие «переходы» и не даёт странице
 *  реально куда-то уйти. Так приложение узнаёт, какой чат сейчас открыт, чтобы
 *  НЕ слать пуш-уведомление о сообщении из уже открытого чата (задача 9). */
function nativeSignal(path) {
    if (!window.__CENTR_NATIVE__) return;
    try {
        const f = document.createElement("iframe");
        f.style.display = "none";
        f.src = "centrnative://" + path;
        (document.body || document.documentElement).appendChild(f);
        setTimeout(() => { try { f.remove(); } catch (_) {} }, 0);
    } catch (_) {}
}
function notifyNativeActiveChat(chatId) {
    nativeSignal("activechat/" + encodeURIComponent(chatId || ""));
}

// Открыть конкретный чат по нажатию на уведомление (вызывает нативная оболочка).
window.centrOpenChat = function (chatId) {
    if (!chatId) return;
    chatId = String(chatId);
    const ready = state.user && el("messenger") && !el("messenger").classList.contains("hidden");
    if (ready) { openChatDeepLink(chatId); }
    else { state.pendingDeepLink = { type: "chat", value: chatId }; }
};

/* ---- Приём «Поделиться в Центр» из других приложений (задача 7) ----
 *  Нативная оболочка (Android ACTION_SEND) передаёт сюда текст или картинку.
 *  Открываем окно выбора чатов (т   же, что и «Переслать») и   тправляем. */
function centrHandleShare(payload) {
    const ready = state.user && el("messenger") && !el("messenger").classList.contains("hidden");
    if (ready && state.chats) { openShareModal(payload); }
    else { state.pendingShare = payload; }   // отложим до входа в мессенджер
}
window.centrShareText = function (text) {
    if (!text) return;
    centrHandleShare({ kind: "text", text: String(text) });
};
window.centrShareImage = function (dataUrl, mime) {
    if (!dataUrl) return;
    centrHandleShare({ kind: "image", dataUrl: String(dataUrl), mime: mime || "image/jpeg" });
};

// data:base64 -> File (для картинки, пришедшей из «Поделиться»).
function dataUrlToFile(dataUrl, name) {
    try {
        const [head, b64] = dataUrl.split(",");
        const mime = (head.match(/data:([^;]+)/) || [])[1] || "image/jpeg";
        const bin = atob(b64);
        const arr = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
        return new File([arr], name || `shared_${Date.now()}.jpg`, { type: mime });
    } catch (_) { return null; }
}

/* ------------------------------------------------------------------ *
 *  18. ЗАПУСК
 * ------------------------------------------------------------------ */
function enterMessenger() {
    hide(el("splash")); hide(el("auth-screen")); hide(el("onboarding-screen"));
    show(el("messenger"));
    paintMyAvatar();

    subscribePresence();
    subscribeRealtime();
    subscribeAppSettings();
    subscribeCallSignaling();
    startHeartbeat();
    hydrateChatsCache();   // мгновенно показываем кэшированный список
    loadChats();           // затем тихо обновляем из сети
    loadFriends();

    // Если нативная оболочка уже передала пуш-токен до входа — сохраняем сейчас.
    if (window.__centrPushToken) saveDeviceToken(window.__centrPushToken.token, window.__centrPushToken.platform);

    // Если приложение открыли нажатием на уведомление о звонке до входа — обработаем.
    if (state.pendingCallIntent) { const ci = state.pendingCallIntent; state.pendingCallIntent = null; setTimeout(() => processCallIntent(ci), 400); }

    const box = el("messages");
    box.addEventListener("scroll", () => {
        const far = box.scrollHeight - box.scrollTop - box.clientHeight > 300;
        if (!far) resetScrollBadge();
        el("scroll-bottom").classList.toggle("hidden", !far && (state.unseenCount || 0) === 0);
    });
    el("scroll-bottom").addEventListener("click", () => { scrollMessagesToBottom(true, true); resetScrollBadge(); });

    // Обработать отложенный диплинк профиля/группы/чата и отложенный шэринг.
    setTimeout(() => {
        runDeepLink();
        if (state.pendingShare) { const p = state.pendingShare; state.pendingShare = null; openShareModal(p); }
    }, 500);
}

async function routeAfterAuth() {
    await loadMyProfile();

    if (!state.profile) {
        await sb.from("profiles").insert({ id: state.user.id, username: "user_" + state.user.id.slice(0, 5) });
        await loadMyProfile();
    }

    const onboardedFlag = localStorage.getItem("centr_onboarded_" + state.user.id);
    const firstTime = !onboardedFlag && !state.profile.avatar_url;

    if (firstTime) {
        hide(el("splash")); hide(el("auth-screen"));
        el("onboard-username").value = state.profile.username || "";
        el("onboard-status").value = state.profile.status_text || "";
        show(el("onboarding-screen"));
    } else {
        localStorage.setItem("centr_onboarded_" + state.user.id, "1");
        enterMessenger();
    }
}

function showAuthScreen() {
    hide(el("splash")); hide(el("messenger")); hide(el("onboarding-screen"));
    show(el("auth-screen"));
}

/* ------------------------------------------------------------------ *
 *  Фикс экранной клавиатуры (мобильный WebView приложения + браузер)
 * ------------------------------------------------------------------
 *  Проблема: в приложении-обёртке (Android WebView внутри MAUI) при
 *  открытии клавиатуры окно не всегда уменьшается, поэтому панель ввода
 *  и кнопка микрофона прячутся за клавиату  ой (видна только полов  на
 *  поля ввода). На сайте в браузере это лечит сам браузер, а в обёртке —
 *  нет.
 *
 *  Решение: жёстко привязываем высоту корневого контейнера #app к
 *  реальной видимой области window.visualViewport (пространство НАД
 *  клавиатурой) и гасим «пролистывание» окна, которое делает Android в
 *  режиме adjustPan. Панель ввода живёт в flex-колонке внизу #app, поэтому
 *  она всегда оказывается ровно над клавиатурой.
 *
 *  Модалки/лайтбокс/тосты лежат ВНЕ #app, поэтому transform на #app на них
 *  не влияет (не ломает position: fixed).
 */
function setupKeyboardViewport() {
    const vv = window.visualViewport;
    const app = el("app");
    if (!vv || !app) return;

    let raf = 0;
    const apply = () => {
        raf = 0;
        // Высота видимой области без клавиатуры.
        app.style.height = vv.height + "px";
        // Если система «сдвинула» окно вверх (adjustPan) — компенсируем сдвиг.
        app.style.transform = vv.offsetTop ? `translateY(${vv.offsetTop}px)` : "";
        // Android в режиме adjustPan прокручивает всю страницу — возвращаем её на место.
        if (window.scrollX || window.scrollY) window.scrollTo(0, 0);
    };
    const schedule = () => { if (!raf) raf = requestAnimationFrame(apply); };

    vv.addEventListener("resize", schedule);
    vv.addEventListener("scroll", schedule);
    window.addEventListener("orientationchange", () => setTimeout(apply, 300));
    apply();

    // Поставил курсор в поле ввода — подматываем ленту вниз, чтобы последнее
    // сообщение и панель ввода были видны над клавиатурой.
    const input = el("message-input");
    if (input) {
        input.addEventListener("focus", () => setTimeout(() => scrollMessagesToBottom(false, true), 350));
    }
}

function wireStaticEvents() {
    $$(".auth-tab").forEach(b => b.addEventListener("click", () => switchAuthTab(b.dataset.authtab)));
    el("login-form").addEventListener("submit", handleLogin);
    el("signup-form").addEventListener("submit", handleSignup);
    el("onboarding-form").addEventListener("submit", handleOnboarding);
    setupOnboardingAvatarPreview();
    setupProfileModal();
    setupCropper();
    setupComposer();
    setupContextMenu();
    setupCalls();
    setupSearch();
    setupModals();
    setupNewChatSearch();
    setupNewGroup();
    setupAddFriend();
    setupAddMember();
    setupForward();
    setupSound();
    setupKeyboardViewport();

    // pagehide надёжнее beforeunload: срабатывает и при закрытии вкладки, и при
    // сворачивании WebView в нативной оболочке — так last_seen пишется корректно.
    window.addEventListener("pagehide", () => { if (state.user) setOffline(); });
    document.addEventListener("visibilitychange", () => {
        if (!state.user) return;
        if (document.visibilityState === "hidden") {
            setOffline();
        } else {
            // Возврат в приложение: сразу освежаем last_seen и переподписываемся на presence.
            sb.from("profiles").update({ last_seen: new Date().toISOString() }).eq("id", state.user.id);
            const ch = state.channels.presence;
            if (ch) { try { ch.track({ user_id: state.user.id, online_at: new Date().toISOString() }); } catch (_) {} }
            refreshActiveChatOther();
        }
    });
}

async function main() {
    captureDeepLink();
    wireStaticEvents();

    // Пользователь пришёл по ссылке из письма для сброса пароля / смены почты.
    // Проверяем и hash (implicit flow), и query (?code=... / ?error=...).
    const authHint = INITIAL_HASH + " " + (window.location.search || "");
    if (authHint.includes("type=recovery")) state.recoveryMode = true;
    if (authHint.includes("type=email_change")) setTimeout(() => toast("Почта обновлена."), 800);
    // Если Supabase вернул ошибку в ссылке (напр. ссылка просрочена) — покажем понятно.
    if (authHint.includes("error_description=") || authHint.includes("error=access_denied")) {
        const m = decodeURIComponent(authHint).match(/error_description=([^&\s]+)/);
        setTimeout(() => toast("Ссылка недействительна или устарела. Запросите новое письмо." + (m ? " (" + m[1].replace(/\+/g, " ") + ")" : ""), true), 900);
    }

    sb.auth.onAuthStateChange((event, session) => {
        if (event === "PASSWORD_RECOVERY") {
            state.recoveryMode = true;
            if (session?.user) state.user = session.user;
            showRecoveryScreen();
            return;
        }
        if (session?.user) {
            const changedUser = state.user?.id !== session.user.id;
            state.user = session.user;
            if (state.recoveryMode) { showRecoveryScreen(); return; }
            if (event === "SIGNED_IN" && changedUser) routeAfterAuth();
        } else if (event === "SIGNED_OUT") {
            state.user = null;
            showAuthScreen();
        }
    });

    const { data: { session } } = await sb.auth.getSession();
    if (state.recoveryMode) {
        if (session?.user) state.user = session.user;
        showRecoveryScreen();
        return;
    }
    if (session?.user) {
        state.user = session.user;
        await routeAfterAuth();
    } else {
        showAuthScreen();
    }
}

// Запускаем main СРАЗУ, если DOM уже готов (app.js может грузиться версионируемо/
// асинхронно), иначе ждём DOMContentLoaded. Без этого при отложенной загрузке
// событие уже прошло бы, main() не вызывался и приложение висло на загрузке.
/* ================================================================== *
 *  ЗВОНКИ — WebRTC аудио 1-на-1
 *  ------------------------------------------------------------------
 *  Сигналинг: Supabase Realtime broadcast. Каждый слушает свой
 *  канал rtc:<своё_id>; чтобы отправить пиру — вещаем в rtc:<peer_id>.
 *  Медиа идёт напрямую P2P (сервер не нагружается). STUN/TURN —
 *  из config.js (CENTR_CONFIG.ICE_SERVERS).
 * ================================================================== */
const CALL_RING_TIMEOUT = 35000;

function staticIceServers() {
    const cfg = window.CENTR_CONFIG && window.CENTR_CONFIG.ICE_SERVERS;
    return (Array.isArray(cfg) && cfg.length) ? cfg.slice()
        : [{ urls: "stun:stun.l.google.com:19302" }, { urls: "stun:stun1.l.google.com:19302" }];
}

// Синхронно возвращает уже загруженный список (STUN + TURN).
let _iceCache = null, _iceCacheAt = 0;
function callIceServers() {
    return (_iceCache && _iceCache.length) ? _iceCache : staticIceServers();
}

// Подгружает TURN-данные Metered по API-ключу и кэширует (~50 мин).
// Если сеть/ключ не сработали — тихо откатываемся на STUN.
async function ensureIceServers() {
    const cfg = window.CENTR_CONFIG || {};
    const sub = cfg.METERED_SUBDOMAIN, key = cfg.METERED_API_KEY;
    if (_iceCache && (Date.now() - _iceCacheAt) < 50 * 60 * 1000) return _iceCache;
    let servers = staticIceServers();
    if (sub && key) {
        try {
            const r = await fetch("https://" + sub + ".metered.live/api/v1/turn/credentials?apiKey=" + encodeURIComponent(key));
            if (r.ok) {
                const list = await r.json();
                if (Array.isArray(list) && list.length) servers = servers.concat(list);
            }
        } catch (e) { console.warn("Metered TURN fetch failed:", e); }
    }
    _iceCache = servers; _iceCacheAt = Date.now();
    return _iceCache;
}

// Каналы для ОТПРАВКИ сигналов пиру (кэшируем по peerId).
// ВАЖНО: channel.subscribe() асинхронный. Пока канал не получил статус
// "SUBSCRIBED", вызовы .send() молча теряются. Раньше первый сигнал
// ("invite" с SDP-offer'ом) отправлялся сразу после subscribe() и терялся,
// поэтому у собеседника входящий звонок не появлялся. Теперь копим сигналы
// в очередь и отправляем их, как только канал реально подпишется.
const _rtcSendChannels = {};
function _getRtcSendChannel(peerId) {
    let entry = _rtcSendChannels[peerId];
    if (entry) return entry;
    const ch = sb.channel(`rtc:${peerId}`);
    entry = { ch, ready: false, queue: [] };
    _rtcSendChannels[peerId] = entry;
    ch.subscribe((status) => {
        if (status === "SUBSCRIBED") {
            entry.ready = true;
            const pending = entry.queue.splice(0);
            pending.forEach(payload => {
                try { ch.send({ type: "broadcast", event: "signal", payload }); } catch (_) {}
            });
        } else if (status === "CHANNEL_ERROR" || status === "TIMED_OUT" || status === "CLOSED") {
            // Пересоздадим канал при следующей отправке.
            try { sb.removeChannel(ch); } catch (_) {}
            if (_rtcSendChannels[peerId] === entry) delete _rtcSendChannels[peerId];
        }
    });
    return entry;
}
function rtcSend(peerId, type, extra) {
    const entry = _getRtcSendChannel(peerId);
    const payload = Object.assign(
        { type, from: state.user.id, fromName: (state.profile && state.profile.username) || "Пользователь" },
        extra || {}
    );
    if (entry.ready) {
        try { entry.ch.send({ type: "broadcast", event: "signal", payload }); } catch (_) {}
    } else {
        entry.queue.push(payload);
    }
}

// Подписка на СВОЙ канал — сюда приходят входящие звонки и ответы.
function subscribeCallSignaling() {
    if (!state.user || state.channels.rtc) return;
    const ch = sb.channel(`rtc:${state.user.id}`, { config: { broadcast: { self: false } } });
    ch.on("broadcast", { event: "signal" }, ({ payload }) => handleCallSignal(payload));
    ch.subscribe();
    state.channels.rtc = ch;
    ensureIceServers();  // заранее подгружаем TURN, чтобы первый звонок был быстрым
}

// Просим Supabase Edge Function разослать пуш о звонке на устройства собеседника.
// type: "call" — входящий звонок, "call_cancel" — снять уведомление (не ответили/отменили).
function notifyCallPush(peerId, chatId, type) {
    if (!peerId) return;
    try {
        sb.functions.invoke("push-on-call", {
            body: {
                type: type || "call",
                to_user: peerId,
                chat_id: chatId || null,
                caller_id: state.user && state.user.id,
                caller_name: (state.profile && state.profile.username) || "Пользователь",
            },
        }).catch(() => {});
    } catch (_) {}
}

/* ---- Мост из нативной оболочки: приём/отклонение звонка из пуш-уведомления ----
 *  Нативная плашка (Принять/Отклонить) вызывает эти функции. Если мессенджер ещё
 *  не готов (приложение только открылось по уведомлению) — откладываем действие. */
function processCallIntent(intent) {
    subscribeCallSignaling();
    if (intent.action === "decline") {
        rtcSend(intent.peerId, "reject", {});
        state.autoAcceptPeer = null;
        return;
    }
    state.autoAcceptPeer = intent.peerId;
    if (state.call && state.call.role === "callee" && state.call.peerId === intent.peerId && state.call.offer && !state.call.pc) {
        state.autoAcceptPeer = null; acceptCall();
    } else {
        rtcSend(intent.peerId, "ready", { chatId: intent.chatId });
    }
}
function handleCallIntent(action, peerId, chatId, callId) {
    if (!peerId) return;
    const intent = { action, peerId: String(peerId), chatId: chatId || null, callId: callId || null };
    const ready = state.user && el("messenger") && !el("messenger").classList.contains("hidden");
    if (ready) processCallIntent(intent);
    else state.pendingCallIntent = intent;
}
window.centrAcceptCall  = (peerId, chatId, callId) => handleCallIntent("accept",  peerId, chatId, callId);
window.centrDeclineCall = (peerId, chatId, callId) => handleCallIntent("decline", peerId, chatId, callId);

// Кнопка звонка видна только в личных чатах.
function toggleCallButton(entry) {
    const btn = el("chat-call-btn");
    if (!btn) return;
    btn.classList.toggle("hidden", !(entry && !entry.chat.is_group && entry.other));
}

function setupCalls() {
    const btn = el("chat-call-btn");
    if (btn) btn.addEventListener("click", startCall);
    const acc = el("call-accept"); if (acc) acc.addEventListener("click", acceptCall);
    const hang = el("call-hangup"); if (hang) hang.addEventListener("click", () => endCall(true));
    const mute = el("call-mute"); if (mute) mute.addEventListener("click", toggleMute);
}

/* --- UI --- */
function showCallUI(o) {
    paintAvatar(el("call-avatar-img"), el("call-avatar-fallback"), o.avatar, o.name);
    el("call-name").textContent = o.name || "Звонок";
    el("call-status").textContent = o.status || "";
    el("call-accept").classList.toggle("hidden", !o.incoming);
    show(el("call-overlay"));
}
function setCallStatus(t) { const s = el("call-status"); if (s) s.textContent = t; }
function hideCallUI() { hide(el("call-overlay")); el("call-accept").classList.add("hidden"); }

/* --- Рингтон на WebAudio (без внешних файлов) --- */
let _ringCtx = null, _ringTimer = null;
function startRing(kind) {
    stopRing();
    try {
        _ringCtx = new (window.AudioContext || window.webkitAudioContext)();
        const beep = () => {
            if (!_ringCtx) return;
            const o = _ringCtx.createOscillator(), g = _ringCtx.createGain();
            o.type = "sine"; o.frequency.value = 480;
            o.connect(g); g.connect(_ringCtx.destination);
            const t = _ringCtx.currentTime;
            g.gain.setValueAtTime(0.0001, t);
            g.gain.exponentialRampToValueAtTime(0.14, t + 0.05);
            g.gain.exponentialRampToValueAtTime(0.0001, t + 0.4);
            o.start(t); o.stop(t + 0.45);
        };
        beep();
        _ringTimer = setInterval(beep, kind === "in" ? 1300 : 2600);
    } catch (_) {}
}
function stopRing() {
    if (_ringTimer) { clearInterval(_ringTimer); _ringTimer = null; }
    if (_ringCtx) { try { _ringCtx.close(); } catch (_) {} _ringCtx = null; }
}

/* --- Таймер разговора --- */
let _callTimer = null;
function startCallTimer() {
    const t0 = Date.now(); stopCallTimer();
    _callTimer = setInterval(() => {
        const s = Math.floor((Date.now() - t0) / 1000);
        setCallStatus(`${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`);
    }, 500);
}
function stopCallTimer() { if (_callTimer) { clearInterval(_callTimer); _callTimer = null; } }

async function getMic() {
    return navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }, video: false
    });
}

function createPeer(peerId) {
    const pc = new RTCPeerConnection({ iceServers: callIceServers() });
    pc.onicecandidate = (e) => {
        if (!e.candidate) return;
        // Копим свои ICE-кандидаты, чтобы переотправить их собеседнику, который
        // открыл приложение по пуш-уведомлению о звонке уже после начала дозвона.
        if (state.call && Array.isArray(state.call.localCandidates)) state.call.localCandidates.push(e.candidate);
        rtcSend(peerId, "ice", { candidate: e.candidate });
    };
    pc.ontrack = (e) => {
        const audio = el("call-audio");
        if (audio && e.streams[0]) { audio.srcObject = e.streams[0]; audio.play().catch(() => {}); }
    };
    pc.onconnectionstatechange = () => {
        if (pc.connectionState === "connected" && state.call) { setCallStatus("00:00"); }
        if (pc.connectionState === "failed") { toast("Связь прервалась", true); endCall(false); }
    };
    return pc;
}

// Ограничиваем битрейт аудио (экономим мобильный трафик и CPU).
function limitAudioBitrate(pc, kbps) {
    pc.getSenders().forEach(sender => {
        if (sender.track && sender.track.kind === "audio") {
            const p = sender.getParameters();
            if (!p.encodings || !p.encodings.length) p.encodings = [{}];
            p.encodings[0].maxBitrate = (kbps || 32) * 1000;
            sender.setParameters(p).catch(() => {});
        }
    });
}

async function flushPendingIce() {
    if (!state.call || !state.call.pending) return;
    for (const c of state.call.pending) {
        try { await state.call.pc.addIceCandidate(new RTCIceCandidate(c)); } catch (_) {}
    }
    state.call.pending = [];
}

/* --- Исходящий звонок --- */
async function startCall() {
    if (state.call) return;
    const entry = getChatEntry(state.activeChatId);
    if (!entry || entry.chat.is_group || !entry.other) { toast("Звонки только в личных чатах", true); return; }
    const peer = entry.other;
    let stream;
    try { stream = await getMic(); } catch (_) { toast("Нет доступа к микрофону", true); return; }
    await ensureIceServers();
    const pc = createPeer(peer.id);
    stream.getTracks().forEach(t => pc.addTrack(t, stream));
    state.call = { pc, stream, peerId: peer.id, chatId: entry.chat.id, role: "caller", pending: [], localCandidates: [], muted: false };
    showCallUI({ name: peer.username, avatar: peer.avatar_url, status: "Звоним…", incoming: false });
    startRing("out");
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    rtcSend(peer.id, "invite", { chatId: entry.chat.id, sdp: offer });
    // Будим устройство собеседника пуш-уведомлением о входящем звонке (даже если
    // у него приложение закрыто). Красивую плашку рисует нативная оболочка.
    notifyCallPush(peer.id, entry.chat.id, "call");
    // Пока звоним — периодически переотправляем invite и свои ICE: если собеседник
    // открыл приложение по уведомлению уже после старта, он всё равно получит оффер.
    state.call.resend = setInterval(() => {
        if (!state.call || state.call.role !== "caller" || state.call.answered) return;
        rtcSend(peer.id, "invite", { chatId: entry.chat.id, sdp: state.call.pc.localDescription || offer });
        (state.call.localCandidates || []).forEach(c => rtcSend(peer.id, "ice", { candidate: c }));
    }, 2500);
    state.call.timeout = setTimeout(() => {
        if (state.call && state.call.role === "caller" && !state.call.answered) {
            rtcSend(peer.id, "cancel", {}); toast("Абонент не ответил"); endCall(false);
        }
    }, CALL_RING_TIMEOUT);
}

/* --- Приём сигналов --- */
async function handleCallSignal(msg) {
    if (!msg || !state.user || msg.from === state.user.id) return;

    if (msg.type === "invite") {
        // Повторный invite от того же абонента (мы периодически их шлём) — не «занято»,
        // а обновление оффера; если открыли по уведомлению с автоприёмом — принимаем.
        if (state.call) {
            if (state.call.role === "callee" && state.call.peerId === msg.from && !state.call.pc) {
                state.call.offer = msg.sdp;
                if (state.autoAcceptPeer === msg.from) { state.autoAcceptPeer = null; acceptCall(); }
            } else if (state.call.peerId !== msg.from) {
                rtcSend(msg.from, "busy", {});
            }
            return;
        }
        state.call = { peerId: msg.from, chatId: msg.chatId, role: "callee", offer: msg.sdp, pending: [], muted: false };
        const prof = state.profilesCache[msg.from];
        showCallUI({ name: (prof && prof.username) || msg.fromName, avatar: prof && prof.avatar_url, status: "Входящий звонок…", incoming: true });
        startRing("in");
        if (state.autoAcceptPeer === msg.from) { state.autoAcceptPeer = null; acceptCall(); }
        return;
    }

    // Собеседник открыл приложение по уведомлению и просит (пере)прислать оффер.
    if (msg.type === "ready") {
        if (state.call && state.call.role === "caller" && msg.from === state.call.peerId && !state.call.answered) {
            rtcSend(state.call.peerId, "invite", { chatId: state.call.chatId, sdp: state.call.pc.localDescription });
            (state.call.localCandidates || []).forEach(c => rtcSend(state.call.peerId, "ice", { candidate: c }));
        }
        return;
    }

    if (!state.call || msg.from !== state.call.peerId) return;

    if (msg.type === "answer") {
        state.call.answered = true;
        if (state.call.timeout) { clearTimeout(state.call.timeout); state.call.timeout = null; }
        if (state.call.resend) { clearInterval(state.call.resend); state.call.resend = null; }
        notifyCallPush(state.call.peerId, state.call.chatId, "call_cancel");
        stopRing();
        await state.call.pc.setRemoteDescription(new RTCSessionDescription(msg.sdp));
        await flushPendingIce();
        limitAudioBitrate(state.call.pc, 32);
        setCallStatus("Соединение…");
        startCallTimer();
    } else if (msg.type === "ice") {
        if (state.call.pc && state.call.pc.remoteDescription && state.call.pc.remoteDescription.type) {
            try { await state.call.pc.addIceCandidate(new RTCIceCandidate(msg.candidate)); } catch (_) {}
        } else { state.call.pending.push(msg.candidate); }
    } else if (msg.type === "reject") { toast("Звонок отклонён"); endCall(false); }
    else if (msg.type === "busy") { toast("Абонент занят"); endCall(false); }
    else if (msg.type === "cancel" || msg.type === "hangup") { endCall(false); }
}

/* --- Принять входящий --- */
async function acceptCall() {
    if (!state.call || state.call.role !== "callee") return;
    stopRing();
    let stream;
    try { stream = await getMic(); }
    catch (_) { toast("Нет доступа к микрофону", true); rtcSend(state.call.peerId, "reject", {}); endCall(false); return; }
    await ensureIceServers();
    const pc = createPeer(state.call.peerId);
    stream.getTracks().forEach(t => pc.addTrack(t, stream));
    state.call.pc = pc; state.call.stream = stream;
    await pc.setRemoteDescription(new RTCSessionDescription(state.call.offer));
    await flushPendingIce();
    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    rtcSend(state.call.peerId, "answer", { sdp: answer });
    limitAudioBitrate(pc, 32);
    el("call-accept").classList.add("hidden");
    setCallStatus("Соединение…");
    startCallTimer();
}

/* --- Микрофон вкл/выкл --- */
function toggleMute() {
    if (!state.call || !state.call.stream) return;
    state.call.muted = !state.call.muted;
    state.call.stream.getAudioTracks().forEach(t => { t.enabled = !state.call.muted; });
    const b = el("call-mute");
    b.classList.toggle("muted", state.call.muted);
    b.title = state.call.muted ? "Включить микрофон" : "Выключить микрофон";
}

/* --- Завершение --- */
function endCall(notifyPeer) {
    const call = state.call;
    if (!call) { hideCallUI(); return; }
    if (notifyPeer && call.peerId) {
        if (call.role === "callee" && !call.pc) rtcSend(call.peerId, "reject", {});
        else rtcSend(call.peerId, "hangup", {});
    }
    // Исходящий звонок, на который ещё не ответили, — гасим уведомление на устройстве собеседника.
    if (call.role === "caller" && !call.answered) notifyCallPush(call.peerId, call.chatId, "call_cancel");
    if (call.resend) { clearInterval(call.resend); call.resend = null; }
    if (call.timeout) clearTimeout(call.timeout);
    stopRing(); stopCallTimer();
    try { call.pc && call.pc.close(); } catch (_) {}
    try { call.stream && call.stream.getTracks().forEach(t => t.stop()); } catch (_) {}
    const audio = el("call-audio");
    if (audio) { try { audio.srcObject = null; } catch (_) {} }
    state.call = null;
    hideCallUI();
}

if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", main);
} else {
    main();
}
