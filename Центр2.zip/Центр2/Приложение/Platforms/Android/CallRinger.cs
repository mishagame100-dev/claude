using System;
using Android.App;
using Android.Content;
using Android.Media;
using Android.OS;

namespace CentrApp;

/// <summary>
/// Сам звонок: зацикленный рингтон + вибрация + включение экрана.
///
/// Мелодию выбирает ПОЛУЧАТЕЛЬ на сайте (profiles.ringtone). Edge-функция push-on-call
/// кладёт её id в пуш (поле "ringtone"), и мы проигрываем нужный файл из Resources/raw
/// даже когда приложение полностью закрыто.
///
/// Почему отдельно от уведомления: звук канала проигрывается ОДИН раз. Чтобы телефон
/// звонил НЕПРЕРЫВНО, мы сами крутим рингтон через MediaPlayer в цикле.
/// Останавливается при: принять / отклонить / call_cancel / таймаут.
/// </summary>
public static class CallRinger
{
    static MediaPlayer? _player;
    static Vibrator? _vibrator;
    static PowerManager.WakeLock? _wakeLock;
    static Handler? _autoStop;
    static readonly object _lock = new object();

    const long MaxRingMs = 40000;

    /// <summary>Начать звонить выбранной мелодией и зажечь экран.</summary>
    public static void Start(Context context, string? ringtoneId = null)
    {
        lock (_lock)
        {
            if (_player != null) return; // уже звоним

            WakeScreen(context);
            StartRingtone(context, ringtoneId);
            StartVibration(context);

            // Страховка: если «call_cancel» не дойдёт — сами замолчим через 40 с.
            try
            {
                _autoStop = new Handler(Looper.MainLooper!);
                _autoStop.PostDelayed(() => Stop(), MaxRingMs);
            }
            catch { /* не критично */ }
        }
    }

    /// <summary>Прекратить звонок: стоп звук, вибрация, отпустить экран.</summary>
    public static void Stop()
    {
        lock (_lock)
        {
            try { _autoStop?.RemoveCallbacksAndMessages(null); } catch { }
            _autoStop = null;

            try { if (_player != null) { _player.Stop(); _player.Release(); } } catch { }
            _player = null;

            try { _vibrator?.Cancel(); } catch { }
            _vibrator = null;

            try { if (_wakeLock != null && _wakeLock.IsHeld) _wakeLock.Release(); } catch { }
            _wakeLock = null;
        }
    }

    // id мелодии с сайта -> файл в Resources/raw.
    static int ResolveRaw(string? id)
    {
        switch (id)
        {
            case "classic": return Resource.Raw.centr_ring_classic;
            case "soft":    return Resource.Raw.centr_ring_soft;
            case "digital": return Resource.Raw.centr_ring_digital;
            case "urgent":  return Resource.Raw.centr_ring_urgent;
            default:         return Resource.Raw.centr_ring; // center / неизвестное
        }
    }

    // Зажечь экран даже если телефон спал/был заблокирован.
    static void WakeScreen(Context context)
    {
        try
        {
            if (context.GetSystemService(Context.PowerService) is PowerManager pm)
            {
#pragma warning disable CS0618
                _wakeLock = pm.NewWakeLock(
                    WakeLockFlags.ScreenBright | WakeLockFlags.AcquireCausesWakeup | WakeLockFlags.OnAfterRelease,
                    "centr:incoming-call");
#pragma warning restore CS0618
                if (_wakeLock != null)
                {
                    _wakeLock.SetReferenceCounted(false);
                    _wakeLock.Acquire(MaxRingMs);
                }
            }
        }
        catch { /* без wake lock тоже обойдёмся (есть fullScreenIntent) */ }
    }

    static void StartRingtone(Context context, string? ringtoneId)
    {
        try
        {
            var attrs = new AudioAttributes.Builder()
                .SetUsage(AudioUsageKind.NotificationRingtone)!
                .SetContentType(AudioContentType.Sonification)!
                .Build();

            MediaPlayer? mp = null;
            // 1) Выбранная пользователем мелодия.
            try { mp = MediaPlayer.Create(context, ResolveRaw(ringtoneId)); } catch { mp = null; }

            // 2) Запасной вариант — системный рингтон.
            if (mp == null)
            {
                var uri = RingtoneManager.GetActualDefaultRingtoneUri(context, RingtoneType.Ringtone)
                          ?? RingtoneManager.GetDefaultUri(RingtoneType.Ringtone);
                if (uri != null)
                {
                    mp = new MediaPlayer();
                    mp.SetAudioAttributes(attrs);
                    mp.SetDataSource(context, uri);
                    mp.Prepare();
                }
            }
            else
            {
                try { mp.SetAudioAttributes(attrs); } catch { }
            }

            if (mp != null)
            {
                mp.Looping = true;
                mp.Start();
                _player = mp;
            }
        }
        catch { /* без звука останется хотя бы вибрация + плашка */ }
    }

    static void StartVibration(Context context)
    {
        try
        {
            _vibrator = context.GetSystemService(Context.VibratorService) as Vibrator;
            if (_vibrator == null || !_vibrator.HasVibrator) { _vibrator = null; return; }

            long[] pattern = { 0, 700, 800, 700, 800 };
            if (Build.VERSION.SdkInt >= BuildVersionCodes.O)
            {
                _vibrator.Vibrate(VibrationEffect.CreateWaveform(pattern, 0));
            }
            else
            {
#pragma warning disable CS0618
                _vibrator.Vibrate(pattern, 0);
#pragma warning restore CS0618
            }
        }
        catch { _vibrator = null; }
    }
}
