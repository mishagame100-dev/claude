using Android.App;
using Android.Content;
using Android.OS;
using AndroidX.Core.App;
using Microsoft.Maui.ApplicationModel;
using AWebView = Android.Webkit.WebView;

namespace CentrApp;

/// <summary>
/// Всё, что касается пуш-уведомлений на стороне устройства:
///  • канал уведомлений;
///  • получение FCM-токена и передача его сайту (window.centrOnPushToken -> таблица device_tokens);
///  • показ уведомления при приходе сообщения.
/// </summary>
public static class PushManager
{
    public const string ChannelId = "centr_messages";
    public static string? Token { get; private set; }

    public static void EnsureChannel(Context context)
    {
        if (Build.VERSION.SdkInt < BuildVersionCodes.O)
            return;

        if (context.GetSystemService(Context.NotificationService) is not NotificationManager manager)
            return;

        if (manager.GetNotificationChannel(ChannelId) != null)
            return;

        var channel = new NotificationChannel(ChannelId, "Сообщения Центр", NotificationImportance.High)
        {
            Description = "Уведомления о новых сообщениях в Центре"
        };
        channel.EnableVibration(true);
        manager.CreateNotificationChannel(channel);
    }

    public static void FetchToken()
    {
        try
        {
            Firebase.Messaging.FirebaseMessaging.Instance
                .GetToken()
                .AddOnCompleteListener(new TokenCompleteListener());
        }
        catch (System.Exception ex)
        {
            System.Diagnostics.Debug.WriteLine("Центр FCM: " + ex.Message);
        }
    }

    public static void SetToken(string? token)
    {
        if (string.IsNullOrEmpty(token))
            return;

        Token = token;

        var view = CentrWeb.Platform;
        if (view is not null)
            MainThread.BeginInvokeOnMainThread(() => InjectTokenIfAvailable(view));
    }

    /// <summary>Отдать токен сайту: он сам сохранит его в таблицу device_tokens от имени пользователя.</summary>
    public static void InjectTokenIfAvailable(AWebView? view)
    {
        if (view is null || string.IsNullOrEmpty(Token))
            return;

        var safe = Token.Replace("\\", "\\\\").Replace("'", "\\'");
        try
        {
            view.EvaluateJavascript(
                $"window.centrOnPushToken && window.centrOnPushToken('{safe}','android');", null);
        }
        catch { /* страница ещё не готова — отдадим при следующей загрузке */ }
    }

    public static void ShowMessageNotification(Context context, string? title, string? body, string? url, string? chatId = null)
    {
        EnsureChannel(context);

        var intent = new Intent(context, typeof(MainActivity));
        intent.AddFlags(ActivityFlags.SingleTop | ActivityFlags.ClearTop);
        if (!string.IsNullOrEmpty(url))
            intent.PutExtra("centr_url", url);
        // Кладём id чата — по нажатию MainActivity откроет именно его (задача 8).
        if (!string.IsNullOrEmpty(chatId))
            intent.PutExtra("centr_chat", chatId);

        var pendingFlags = PendingIntentFlags.UpdateCurrent;
        if (Build.VERSION.SdkInt >= BuildVersionCodes.S)
            pendingFlags |= PendingIntentFlags.Immutable;

        // У каждого чата — свой requestCode, иначе UpdateCurrent «перезапишет»
        // extras и нажатие на старое уведомление открыло бы не тот чат.
        int reqCode = string.IsNullOrEmpty(chatId) ? 100 : (System.Math.Abs(chatId.GetHashCode()) % 1_000_000);
        var pending = PendingIntent.GetActivity(context, reqCode, intent, pendingFlags);

        var builder = new NotificationCompat.Builder(context, ChannelId)
            .SetContentTitle(string.IsNullOrEmpty(title) ? "Центр" : title)
            .SetContentText(string.IsNullOrEmpty(body) ? "Новое сообщение" : body)
            .SetSmallIcon(Resource.Drawable.ic_notification)
            .SetAutoCancel(true)
            .SetPriority((int)NotificationPriority.High)
            .SetDefaults((int)NotificationDefaults.All)
            .SetContentIntent(pending);

        NotificationManagerCompat.From(context).Notify(new System.Random().Next(1, 1_000_000), builder.Build());
    }
}

/// <summary>Получаем FCM-токен асинхронно и передаём в PushManager.</summary>
class TokenCompleteListener : Java.Lang.Object, Android.Gms.Tasks.IOnCompleteListener
{
    public void OnComplete(Android.Gms.Tasks.Task task)
    {
        try
        {
            if (task.IsSuccessful && task.Result is not null)
                PushManager.SetToken(task.Result.ToString());
        }
        catch { /* игнорируем */ }
    }
}
