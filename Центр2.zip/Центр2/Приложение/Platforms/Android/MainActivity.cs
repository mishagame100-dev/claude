using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.OS;
using Android.Views;

namespace CentrApp;

[Activity(
    Theme = "@style/Maui.SplashTheme",
    MainLauncher = true,
    LaunchMode = LaunchMode.SingleTop,
    WindowSoftInputMode = SoftInput.AdjustResize, // Убрали StateHidden, оставили только чистый Resize
    ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation | ConfigChanges.UiMode

        | ConfigChanges.ScreenLayout | ConfigChanges.SmallestScreenSize | ConfigChanges.Density
        | ConfigChanges.KeyboardHidden | ConfigChanges.Keyboard)]
// «Поделиться в Центр» из других приложений: Центр появляется в системном меню
// «Поделиться» для картинок и текста (задача 7).
[IntentFilter(new[] { Intent.ActionSend }, Categories = new[] { Intent.CategoryDefault }, DataMimeType = "image/*")]
[IntentFilter(new[] { Intent.ActionSend }, Categories = new[] { Intent.CategoryDefault }, DataMimeType = "text/plain")]
[IntentFilter(new[] { Intent.ActionSendMultiple }, Categories = new[] { Intent.CategoryDefault }, DataMimeType = "image/*")]
public class MainActivity : MauiAppCompatActivity
{
    protected override void OnCreate(Bundle? savedInstanceState)
    {
        base.OnCreate(savedInstanceState);

        // Инициализация Firebase. Если google-services.json ещё не добавлен — просто ничего не делаем,
        // приложение продолжит работать как обёртка сайта (но без пушей).
        try { Firebase.FirebaseApp.InitializeApp(this); } catch { /* Firebase не настроен */ }

        PushManager.EnsureChannel(this);
        CallNotifications.EnsureChannel(this); // канал для звонков
        RequestStartupPermissions();
        PushManager.FetchToken();

        // Приложение запустили нажатием на уведомление или через «Поделиться».
        HandleIntent(Intent);
    }

    protected override void OnResume()
    {
        base.OnResume();
        AppState.IsForeground = true;
    }

    protected override void OnPause()
    {
        base.OnPause();
        AppState.IsForeground = false;
    }

    protected override void OnNewIntent(Intent? intent)
    {
        base.OnNewIntent(intent);
        Intent = intent; // на случай, если приложение открыли по нажатию на уведомление
        HandleIntent(intent);
    }

    // Разбираем входящий Intent: принять звонок, открыть нужный чат (уведомление)
    // либо принять «Поделиться» (текст/картинка) и передать сайту.
    void HandleIntent(Intent? intent)
    {
        if (intent is null) return;

        try
        {
            // 0) Принятие звонка из уведомления (кнопка «Принять» или нажатие на плашку).
            if (intent.GetStringExtra("centr_call_action") == "accept")
            {
                WakeAndShowOverLock();                 // показать поверх блокировки и зажечь экран
                var peer = intent.GetStringExtra("centr_call_peer");
                var chat = intent.GetStringExtra("centr_call_chat");
                var callId = intent.GetStringExtra("centr_call_id");
                CallRinger.Stop();                     // глушим рингтон
                CallNotifications.Cancel(this);        // гасим плашку
                CentrWeb.AcceptCall(peer, chat, callId); // сайт примет звонок
                return;
            }

            var action = intent.Action;

            // 1) «Поделиться в Центр».
            if (action == Intent.ActionSend || action == Intent.ActionSendMultiple)
            {
                var type = intent.Type ?? "";
                if (type.StartsWith("text/"))
                {
                    var text = intent.GetStringExtra(Intent.ExtraText);
                    if (!string.IsNullOrEmpty(text)) CentrWeb.ShareText(text);
                }
                else if (type.StartsWith("image/"))
                {
                    Android.Net.Uri? uri = null;
                    if (action == Intent.ActionSendMultiple)
                    {
                        var list = intent.GetParcelableArrayListExtra(Intent.ExtraStream);
                        if (list is not null && list.Count > 0) uri = list[0] as Android.Net.Uri;
                    }
                    else
                    {
                        uri = intent.GetParcelableExtra(Intent.ExtraStream) as Android.Net.Uri;
                    }
                    if (uri is not null) ShareImageFromUri(uri);
                }
                return;
            }

            // 2) Нажатие на уведомление: открываем конкретный чат.
            //    'centr_chat' кладём мы сами; 'chat_id' приходит из data-нагрузки FCM.
            var chatId = intent.GetStringExtra("centr_chat");
            if (string.IsNullOrEmpty(chatId)) chatId = intent.GetStringExtra("chat_id");
            if (!string.IsNullOrEmpty(chatId)) CentrWeb.OpenChat(chatId);
        }
        catch { /* некорректный intent — просто игнорируем */ }
    }

    // Показать окно поверх экрана блокировки и зажечь экран (при принятии звонка).
    void WakeAndShowOverLock()
    {
        try
        {
            if (Build.VERSION.SdkInt >= BuildVersionCodes.OMr1)
            {
                SetShowWhenLocked(true);
                SetTurnScreenOn(true);
            }
            else
            {
#pragma warning disable CS0618
                Window?.AddFlags(WindowManagerFlags.ShowWhenLocked | WindowManagerFlags.TurnScreenOn
                    | WindowManagerFlags.KeepScreenOn | WindowManagerFlags.DismissKeyguard);
#pragma warning restore CS0618
            }
        }
        catch { /* не критично */ }
    }

    void ShareImageFromUri(Android.Net.Uri uri)
    {
        try
        {
            var mime = ContentResolver?.GetType(uri) ?? "image/jpeg";
            using var stream = ContentResolver?.OpenInputStream(uri);
            if (stream is null) return;
            using var ms = new System.IO.MemoryStream();
            stream.CopyTo(ms);
            var b64 = System.Convert.ToBase64String(ms.ToArray());
            CentrWeb.ShareImage($"data:{mime};base64,{b64}", mime);
        }
        catch { /* не удалось прочитать картинку — пропускаем */ }
    }

    void RequestStartupPermissions()
    {
        var needed = new System.Collections.Generic.List<string>
        {
            Android.Manifest.Permission.RecordAudio, // голосовые сообщения (getUserMedia)
            Android.Manifest.Permission.Camera        // съёмка фото/видео из чата
        };
        if (Build.VERSION.SdkInt >= BuildVersionCodes.Tiramisu)
            needed.Add(Android.Manifest.Permission.PostNotifications); // уведомления на Android 13+

        var toRequest = new System.Collections.Generic.List<string>();
        foreach (var permission in needed)
        {
            if (CheckSelfPermission(permission) != Permission.Granted)
                toRequest.Add(permission);
        }

        if (toRequest.Count > 0)
            RequestPermissions(toRequest.ToArray(), 1001);
    }

    // Кнопка «Назад» листает историю внутри сайта, а не закрывает приложение.
    public override void OnBackPressed()
    {
        var view = CentrWeb.Platform;
        if (view is not null && view.CanGoBack())
            view.GoBack();
        else
            base.OnBackPressed();
    }

    // Результат системного выбора файла (input type=file на сайте) возвращаем в WebView.
    protected override void OnActivityResult(int requestCode, Result resultCode, Intent? data)
    {
        base.OnActivityResult(requestCode, resultCode, data);
        if (requestCode == FileChooserBridge.RequestCode)
            FileChooserBridge.Deliver(resultCode, data);
    }

    // Ответ пользователя на запрос системного разрешения. Если это запрос,
    // инициированный веб-страницей (микрофон/камера для голосовых), — доводим
    // до конца выдачу доступа странице в WebView.
    public override void OnRequestPermissionsResult(int requestCode, string[] permissions, Permission[] grantResults)
    {
        base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == WebPermissionBridge.RequestCode)
            WebPermissionBridge.OnResult(permissions, grantResults);
    }
}
