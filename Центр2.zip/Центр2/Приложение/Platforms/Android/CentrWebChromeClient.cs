using Android.Webkit;
using AWebView = Android.Webkit.WebView;

namespace CentrApp;

/// <summary>
/// Отвечает за «продвинутые» возможности WebView, которые нужны сайту:
///  • выдаёт разрешение на микрофон/камеру для голосовых сообщений (WebRTC getUserMedia);
///  • открывает системный выбор файла для input type=file (отправка фото/видео из чата);
///  • ссылки target=_blank открывает во внешнем браузере.
/// </summary>
public class CentrWebChromeClient : WebChromeClient
{
    public override void OnPermissionRequest(PermissionRequest? request)
    {
        if (request is null)
        {
            base.OnPermissionRequest(request);
            return;
        }

        // Отдаём выдачу доступа «мосту»: он при необходимости сперва спросит у
        // пользователя системное разрешение (RECORD_AUDIO/CAMERA), а затем пустит
        // страницу к микрофону/камере. Без этого микрофон в приложении молчит.
        WebPermissionBridge.Handle(request);
    }

    public override bool OnShowFileChooser(AWebView? webView, IValueCallback? filePathCallback, FileChooserParams? fileChooserParams)
    {
        return FileChooserBridge.Start(filePathCallback, fileChooserParams);
    }

    public override bool OnCreateWindow(AWebView? view, bool isDialog, bool isUserGesture, Android.OS.Message? resultMsg)
    {
        try
        {
            var result = view?.GetHitTestResult();
            var url = result?.Extra;
            if (!string.IsNullOrEmpty(url))
            {
                var intent = new Android.Content.Intent(Android.Content.Intent.ActionView, Android.Net.Uri.Parse(url));
                intent.AddFlags(Android.Content.ActivityFlags.NewTask);
                Android.App.Application.Context.StartActivity(intent);
            }
        }
        catch { /* игнорируем */ }
        return false;
    }
}
