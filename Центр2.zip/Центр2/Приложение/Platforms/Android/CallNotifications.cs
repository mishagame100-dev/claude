using Android.App;
using Android.Content;
using Android.OS;
using AndroidX.Core.App;

namespace CentrApp;

/// <summary>
/// Канал и построение «красивого» уведомления о входящем звонке (в стиле Telegram):
///  • всплывает баннером, а на заблокированном экране — во весь экран (fullScreenIntent);
///  • две кнопки: «Принять» (открывает Центр и принимает) и «Отклонить»;
///  • висит (ongoing), пока звонок не примут / не отклонят / не отменит звонящий.
///
/// Звук и вибрацию ведёт CallRinger (зацикленный рингтон), поэтому сам канал СДЕЛАН ТИХИМ —
/// иначе звук бы шёл дважды. Канал переименован в v2, потому что Android не меняет
/// настройки (звук/важность) у уже созданного канала.
/// </summary>
public static class CallNotifications
{
    public const string ChannelId = "centr_calls_v2";
    const string OldChannelId = "centr_calls";
    public const int NotifId = 424242;

    public static void EnsureChannel(Context context)
    {
        if (Build.VERSION.SdkInt < BuildVersionCodes.O)
            return;

        if (context.GetSystemService(Context.NotificationService) is not NotificationManager manager)
            return;

        // Убираем старый канал со старым звуком (чтобы не было двойного звона).
        try { manager.DeleteNotificationChannel(OldChannelId); } catch { /* его могло не быть */ }

        if (manager.GetNotificationChannel(ChannelId) != null)
            return;

        var channel = new NotificationChannel(ChannelId, "Звонки", NotificationImportance.High)
        {
            Description = "Входящие звонки в Центре",
            LockscreenVisibility = NotificationVisibility.Public,
        };
        // Звук и вибрация — на CallRinger, поэтому канал тихий.
        channel.EnableVibration(false);
        channel.SetSound(null, null);
        try { channel.SetBypassDnd(true); } catch { /* не критично */ }
        channel.SetShowBadge(false);

        manager.CreateNotificationChannel(channel);
    }

    /// <summary>Показать плашку входящего звонка.</summary>
    public static void ShowIncoming(Context context, string? callerName, string? peerId, string? chatId, string? callId)
    {
        EnsureChannel(context);

        // Нажатие на плашку или кнопку «Принять» — открыть приложение и принять звонок.
        var acceptIntent = new Intent(context, typeof(MainActivity));
        acceptIntent.SetAction("centr.call.ACCEPT");
        acceptIntent.AddFlags(ActivityFlags.NewTask | ActivityFlags.SingleTop | ActivityFlags.ClearTop);
        acceptIntent.PutExtra("centr_call_action", "accept");
        acceptIntent.PutExtra("centr_call_peer", peerId);
        acceptIntent.PutExtra("centr_call_chat", chatId);
        acceptIntent.PutExtra("centr_call_id", callId);
        var acceptPending = ActivityPending(context, 5101, acceptIntent);
        var fullScreenPending = ActivityPending(context, 5102, acceptIntent);

        // «Отклонить» — широковещательный сигнал (без открытия окна).
        var declineIntent = new Intent(context, typeof(CallActionReceiver));
        declineIntent.SetAction(CallActionReceiver.ActionDecline);
        declineIntent.PutExtra("centr_call_peer", peerId);
        declineIntent.PutExtra("centr_call_chat", chatId);
        declineIntent.PutExtra("centr_call_id", callId);
        var declinePending = BroadcastPending(context, 5103, declineIntent);

        var builder = new NotificationCompat.Builder(context, ChannelId)
            .SetSmallIcon(Resource.Drawable.ic_notification)
            .SetContentTitle("Входящий звонок")
            .SetContentText(string.IsNullOrEmpty(callerName) ? "Центр" : callerName)
            .SetCategory(NotificationCompat.CategoryCall)
            .SetPriority(NotificationCompat.PriorityMax)
            .SetVisibility(NotificationCompat.VisibilityPublic)
            .SetOngoing(true)
            .SetAutoCancel(false)
            .SetContentIntent(acceptPending)
            .SetFullScreenIntent(fullScreenPending, true)
            .AddAction(0, "Отклонить", declinePending)
            .AddAction(0, "Принять", acceptPending);

        NotificationManagerCompat.From(context).Notify(NotifId, builder.Build());
    }

    /// <summary>Снять плашку звонка (приняли / отклонили / звонящий отменил).</summary>
    public static void Cancel(Context context)
    {
        try { NotificationManagerCompat.From(context).Cancel(NotifId); } catch { /* уже снято */ }
    }

    static PendingIntent ActivityPending(Context context, int req, Intent intent)
    {
        var flags = PendingIntentFlags.UpdateCurrent;
        if (Build.VERSION.SdkInt >= BuildVersionCodes.S) flags |= PendingIntentFlags.Immutable;
        return PendingIntent.GetActivity(context, req, intent, flags)!;
    }

    static PendingIntent BroadcastPending(Context context, int req, Intent intent)
    {
        var flags = PendingIntentFlags.UpdateCurrent;
        if (Build.VERSION.SdkInt >= BuildVersionCodes.S) flags |= PendingIntentFlags.Immutable;
        return PendingIntent.GetBroadcast(context, req, intent, flags)!;
    }
}
