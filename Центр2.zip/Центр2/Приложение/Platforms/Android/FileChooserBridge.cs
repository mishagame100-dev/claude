using Android.App;
using Android.Content;
using Android.Provider;
using Android.Webkit;
using AndroidX.Core.Content;
using Microsoft.Maui.ApplicationModel;
using FileProvider = AndroidX.Core.Content.FileProvider; 

namespace CentrApp;

/// <summary>
/// Связывает WebView и активити при выборе файла: WebView просит открыть «проводник»,
/// мы запускаем системное окно, а результат возвращаем обратно в страницу.
///
/// Дополнительно: если страница просит именно СЪЁМКУ фото (input capture=…, кнопка
/// «Камера» на сайте) — открываем камеру устройства и возвращаем снимок (задача 2).
/// Если камеры/FileProvider почему-то нет — тихо откатываемся к обычному выбору файла.
/// </summary>
public static class FileChooserBridge
{
    public const int RequestCode = 51426;
    static IValueCallback? _callback;
    static Android.Net.Uri? _cameraUri;

    public static bool Start(IValueCallback? callback, WebChromeClient.FileChooserParams? prms)
    {
        var activity = Platform.CurrentActivity;
        if (activity is null || prms is null)
        {
            callback?.OnReceiveValue(null);
            return false;
        }

        // Отменяем предыдущий незавершённый выбор, если он был.
        _callback?.OnReceiveValue(null);
        _callback = callback;
        _cameraUri = null;

        // Страница явно просит снять фото камерой — открываем камеру.
        if (WantsCameraPhoto(prms) && TryStartCamera(activity))
            return true;

        try
        {
            var intent = prms.CreateIntent();
            activity.StartActivityForResult(intent, RequestCode);
            return true;
        }
        catch
        {
            _callback = null;
            callback?.OnReceiveValue(null);
            return false;
        }
    }

    static bool WantsCameraPhoto(WebChromeClient.FileChooserParams prms)
    {
        try
        {
            if (!prms.IsCaptureEnabled) return false;
            var types = prms.GetAcceptTypes();
            if (types is null || types.Length == 0) return true; // capture без типа — считаем, что фото
            foreach (var t in types)
                if (!string.IsNullOrEmpty(t) && t.Contains("image")) return true;
            return false;
        }
        catch { return false; }
    }

    static bool TryStartCamera(Activity activity)
    {
        try
        {
            var dir = new Java.IO.File(activity.CacheDir, "camera");
            dir.Mkdirs();
            var file = new Java.IO.File(dir, $"cam_{System.DateTime.Now.Ticks}.jpg");
            var authority = activity.PackageName + ".fileprovider";
            _cameraUri = FileProvider.GetUriForFile(activity, authority, file);

            var intent = new Intent(MediaStore.ActionImageCapture);
            intent.PutExtra(MediaStore.ExtraOutput, _cameraUri);
            intent.AddFlags(ActivityFlags.GrantReadUriPermission | ActivityFlags.GrantWriteUriPermission);

            if (intent.ResolveActivity(activity.PackageManager!) is null)
            {
                _cameraUri = null;
                return false;
            }
            activity.StartActivityForResult(intent, RequestCode);
            return true;
        }
        catch
        {
            _cameraUri = null;
            return false;
        }
    }

    public static void Deliver(Result resultCode, Intent? data)
    {
        Android.Net.Uri[]? uris = null;

        var cu = _cameraUri;
        if (cu is not null)
        {
            // Снимок с камеры лежит по нашему URI; при отмене — ничего не возвращаем.
            if (resultCode == Result.Ok) uris = new[] { cu };
        }
        else
        {
            uris = WebChromeClient.FileChooserParams.ParseResult((int)resultCode, data);
        }

        _callback?.OnReceiveValue(uris);
        _callback = null;
        _cameraUri = null;
    }
}
