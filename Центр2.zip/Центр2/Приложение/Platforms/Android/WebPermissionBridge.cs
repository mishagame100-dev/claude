using Android;
using Android.Content.PM;
using Android.Webkit;
using AndroidX.Core.App;
using AndroidX.Core.Content;
using Microsoft.Maui.ApplicationModel;

namespace CentrApp;

/// <summary>
/// Выдаёт веб-странице внутри WebView доступ к микрофону/камере (WebRTC getUserMedia,
/// который использует запись голосовых сообщений на сайте).
///
/// Почему это отдельный «мост», а не одна строка request.Grant(...):
/// WebView может разрешить странице пользоваться микрофоном ТОЛЬКО если само
/// приложение уже имеет системное разрешение Android RECORD_AUDIO. Если его нет
/// (пользователь не выдал при первом запуске или отклонил), простой Grant не
/// помогает — микрофон «молчит». Поэтому здесь мы:
///   1) смотрим, каких системных разрешений не хватает;
///   2) если чего-то нет — просим его у пользователя ПРЯМО в момент нажатия на
///      микрофон, а страницу пускаем к устройству только после согласия;
///   3) если разрешение уже есть — сразу отдаём доступ странице.
/// Благодаря этому микрофон «самовосстанавливается»: даже если разрешение когда-то
/// отклонили, повторное нажатие на кнопку записи снова предложит его выдать.
/// </summary>
public static class WebPermissionBridge
{
    public const int RequestCode = 52001;

    static PermissionRequest? _pending;
    static string[]? _pendingResources;

    /// <summary>Вызывается из CentrWebChromeClient.OnPermissionRequest.</summary>
    public static void Handle(PermissionRequest request)
    {
        var resources = request.GetResources() ?? System.Array.Empty<string>();

        // Сопоставляем запрошенные веб-ресурсы с системными разрешениями Android.
        var osPermissions = new System.Collections.Generic.List<string>();
        foreach (var res in resources)
        {
            if (res == PermissionRequest.ResourceAudioCapture)
                osPermissions.Add(Manifest.Permission.RecordAudio);
            else if (res == PermissionRequest.ResourceVideoCapture)
                osPermissions.Add(Manifest.Permission.Camera);
        }

        var activity = Platform.CurrentActivity;

        // Нет активити — не рискуем, просто пытаемся выдать доступ.
        if (activity is null)
        {
            SafeGrant(request, resources);
            return;
        }

        // Каких системных разрешений ещё не хватает.
        var missing = new System.Collections.Generic.List<string>();
        foreach (var perm in osPermissions)
        {
            if (ContextCompat.CheckSelfPermission(activity, perm) != Permission.Granted)
                missing.Add(perm);
        }

        if (missing.Count == 0)
        {
            // Всё уже разрешено на уровне ОС — сразу отдаём доступ странице.
            activity.RunOnUiThread(() => SafeGrant(request, resources));
            return;
        }

        // Нужно спросить у пользователя системное разрешение. Запоминаем запрос
        // страницы и достраиваем его в OnResult после ответа пользователя.
        _pending = request;
        _pendingResources = resources;
        activity.RunOnUiThread(() =>
            ActivityCompat.RequestPermissions(activity, missing.ToArray(), RequestCode));
    }

    /// <summary>Вызывается из MainActivity.OnRequestPermissionsResult.</summary>
    public static void OnResult(string[] permissions, Permission[] grantResults)
    {
        var request = _pending;
        var resources = _pendingResources;
        _pending = null;
        _pendingResources = null;

        if (request is null)
            return;

        bool allGranted = grantResults.Length > 0;
        foreach (var result in grantResults)
        {
            if (result != Permission.Granted) { allGranted = false; break; }
        }

        var activity = Platform.CurrentActivity;
        void Complete()
        {
            if (allGranted && resources is not null) SafeGrant(request, resources);
            else { try { request.Deny(); } catch { /* запрос уже неактуален */ } }
        }

        if (activity is not null) activity.RunOnUiThread(Complete);
        else Complete();
    }

    static void SafeGrant(PermissionRequest request, string[] resources)
    {
        try { request.Grant(resources); }
        catch { try { request.Deny(); } catch { /* запрос уже неактуален */ } }
    }
}
