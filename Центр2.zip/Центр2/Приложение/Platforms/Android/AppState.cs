namespace CentrApp;

/// <summary>
/// Небольшое общее состояние приложения, к которому обращаются из разных мест:
///  • IsForeground — приложение сейчас на экране (обновляется в MainActivity.OnResume/OnPause);
///  • ActiveChatId — какой чат сейчас открыт в WebView (сайт сообщает это через
///    служебную схему centrnative://activechat/&lt;id&gt;).
///
/// Используется, чтобы НЕ показывать пуш-уведомление о сообщении из чата, который
/// прямо сейчас открыт у пользователя (задача 9).
/// </summary>
public static class AppState
{
    public static volatile bool IsForeground;
    public static volatile string? ActiveChatId;
}
