using Android.App;
using Android.Content;

namespace CentrApp;

/// <summary>
/// Обрабатывает кнопку «Отклонить» из уведомления о звонке.
/// Глушит рингтон, снимает плашку; если приложение открыто — говорит сайту отклонить звонок
/// (звонящему уйдёт reject через уже работающий сигналинг).
/// </summary>
[BroadcastReceiver(Exported = false)]
public class CallActionReceiver : BroadcastReceiver
{
    public const string ActionDecline = "centr.call.DECLINE";

    public override void OnReceive(Context? context, Intent? intent)
    {
        if (context == null) return;

        CallRinger.Stop();            // замолчать
        CallNotifications.Cancel(context);

        if (AppState.IsForeground)
        {
            var peer = intent?.GetStringExtra("centr_call_peer");
            var chat = intent?.GetStringExtra("centr_call_chat");
            var callId = intent?.GetStringExtra("centr_call_id");
            CentrWeb.DeclineCall(peer, chat, callId);
        }
    }
}
