using Microsoft.Maui.ApplicationModel;
using AWebView = Android.Webkit.WebView;

namespace CentrApp;

/// <summary>
/// «Мостик» к нативному WebView: хранит ссылку на него (для кнопки «Назад» и
/// пуш-токена) и умеет:
///  • открыть конкретный чат по нажатию на уведомление (window.centrOpenChat);
///  • передать сайту «Поделиться в Центр» (window.centrShareText / centrShareImage);
///  • принять/отклонить звонок из уведомления (window.centrAcceptCall / centrDeclineCall);
///  • пометить страницу как открытую внутри приложения (window.__CENTR_NATIVE__).
///
/// Если страница ещё не загрузилась, действие откладывается и выполняется в
/// CentrWebViewClient.OnPageFinished.
/// </summary>
public static class CentrWeb
{
    public static AWebView? Platform { get; set; }

    // Отложенные действия (если WebView ещё не готов, когда пришло уведомление/шэринг).
    static string? _pendingOpenChatId;
    static string? _pendingShareJs;
    static string? _pendingCallJs;

    /// <summary>Открыть чат по id. Если страница не готова — отложить до загрузки.</summary>
    public static void OpenChat(string? chatId)
    {
        if (string.IsNullOrEmpty(chatId)) return;
        var view = Platform;
        if (view is not null)
            RunJs(view, $"window.centrOpenChat && window.centrOpenChat('{JsEscape(chatId)}');");
        else
            _pendingOpenChatId = chatId;
    }

    /// <summary>Передать сайту текст, которым поделились из другого приложения.</summary>
    public static void ShareText(string? text)
    {
        if (string.IsNullOrEmpty(text)) return;
        var js = $"window.centrShareText && window.centrShareText('{JsEscape(text)}');";
        var view = Platform;
        if (view is not null) RunJs(view, js);
        else _pendingShareJs = js;
    }

    /// <summary>Передать сайту картинку (data-URL), которой поделились из другого приложения.</summary>
    public static void ShareImage(string? dataUrl, string? mime)
    {
        if (string.IsNullOrEmpty(dataUrl)) return;
        var js = $"window.centrShareImage && window.centrShareImage('{JsEscape(dataUrl)}','{JsEscape(mime ?? "image/jpeg")}');";
        var view = Platform;
        if (view is not null) RunJs(view, js);
        else _pendingShareJs = js;
    }

    /// <summary>Принять звонок (нажата «Принять» в уведомлении). peerId — id звонящего.</summary>
    public static void AcceptCall(string? peerId, string? chatId, string? callId)
    {
        if (string.IsNullOrEmpty(peerId)) return;
        var js = $"window.centrAcceptCall && window.centrAcceptCall('{JsEscape(peerId)}','{JsEscape(chatId ?? "")}','{JsEscape(callId ?? "")}');";
        var view = Platform;
        if (view is not null) RunJs(view, js);
        else _pendingCallJs = js;
    }

    /// <summary>Отклонить звонок (нажата «Отклонить» в уведомлении).</summary>
    public static void DeclineCall(string? peerId, string? chatId, string? callId)
    {
        if (string.IsNullOrEmpty(peerId)) return;
        var js = $"window.centrDeclineCall && window.centrDeclineCall('{JsEscape(peerId)}','{JsEscape(chatId ?? "")}','{JsEscape(callId ?? "")}');";
        var view = Platform;
        if (view is not null) RunJs(view, js);
        else _pendingCallJs = js;
    }

    /// <summary>Вызывается из CentrWebViewClient.OnPageFinished, когда страница загрузилась.</summary>
    public static void OnPageFinished(AWebView? view)
    {
        if (view is null) return;
        // Помечаем, что мы внутри приложения — сайт по этому флагу шлёт нам сигналы.
        RunJs(view, "window.__CENTR_NATIVE__=true;");

        if (!string.IsNullOrEmpty(_pendingOpenChatId))
        {
            var id = _pendingOpenChatId; _pendingOpenChatId = null;
            RunJs(view, $"window.centrOpenChat && window.centrOpenChat('{JsEscape(id!)}');");
        }
        if (!string.IsNullOrEmpty(_pendingShareJs))
        {
            var js = _pendingShareJs; _pendingShareJs = null;
            RunJs(view, js!);
        }
        if (!string.IsNullOrEmpty(_pendingCallJs))
        {
            var js = _pendingCallJs; _pendingCallJs = null;
            RunJs(view, js!);
        }
    }

    static void RunJs(AWebView view, string js)
    {
        MainThread.BeginInvokeOnMainThread(() =>
        {
            try { view.EvaluateJavascript(js, null); } catch { /* страница ещё не готова */ }
        });
    }

    static string JsEscape(string s) =>
        s.Replace("\\", "\\\\").Replace("'", "\\'").Replace("\r", "\\r").Replace("\n", "\\n");
}
