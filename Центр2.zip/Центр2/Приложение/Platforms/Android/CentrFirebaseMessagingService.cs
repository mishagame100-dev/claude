using Android.App;
using Firebase.Messaging;

namespace CentrApp;

/// <summary>
/// Служба, которую вызывает Firebase, когда:
///  • обновился токен устройства (OnNewToken) — отдаём его сайту;
///  • пришло сообщение (OnMessageReceived) — показываем уведомление.
///
/// Обработка пушей о ЗВОНКАХ (data type = "call" / "call_cancel").
/// В пуше приходит также "ringtone" — id мелодии, выбранной получателем на сайте.
/// </summary>
[Service(Exported = false)]
[IntentFilter(new[] { "com.google.firebase.MESSAGING_EVENT" })]
public class CentrFirebaseMessagingService : FirebaseMessagingService
{
    public override void OnNewToken(string token)
    {
        base.OnNewToken(token);
        PushManager.SetToken(token);
    }

    public override void OnMessageReceived(RemoteMessage message)
    {
        base.OnMessageReceived(message);

        // --- ЗВОНКИ: приходят как data-only пуш (без notification), поэтому этот код
        //     срабатывает даже когда приложение свёрнуто или полностью закрыто. ---
        var callData = message.Data;
        if (callData != null && callData.TryGetValue("type", out var pushType)
            && (pushType == "call" || pushType == "call_cancel"))
        {
            HandleCallPush(pushType, callData);
            return;
        }

        // --- Обычные сообщения (как было раньше) ---
        string? title = message.GetNotification()?.Title;
        string? body = message.GetNotification()?.Body;
        string? url = null;
        string? chatId = null;

        var data = message.Data;
        if (data is not null)
        {
            if (string.IsNullOrEmpty(title) && data.TryGetValue("title", out var t)) title = t;
            if (string.IsNullOrEmpty(body) && data.TryGetValue("body", out var b)) body = b;
            if (data.TryGetValue("url", out var u)) url = u;
            if (data.TryGetValue("chat_id", out var c)) chatId = c;
        }

        if (AppState.IsForeground && !string.IsNullOrEmpty(chatId) && chatId == AppState.ActiveChatId)
            return;

        PushManager.ShowMessageNotification(this, title, body, url, chatId);
    }

    // Показать/снять плашку звонка (+ запустить/остановить рингтон).
    void HandleCallPush(string type, System.Collections.Generic.IDictionary<string, string> data)
    {
        if (type == "call_cancel")
        {
            CallRinger.Stop();
            CallNotifications.Cancel(this);
            return;
        }

        // Если приложение открыто — входящий звонок уже показывает сам сайт.
        if (AppState.IsForeground)
            return;

        data.TryGetValue("caller_name", out var name);
        data.TryGetValue("caller_id", out var caller);
        data.TryGetValue("chat_id", out var chat);
        data.TryGetValue("call_id", out var callId);
        data.TryGetValue("ringtone", out var ringtone);

        CallNotifications.ShowIncoming(this, name, caller, chat, callId);
        CallRinger.Start(this, ringtone);   // зазвонить выбранной мелодией и зажечь экран
    }
}
