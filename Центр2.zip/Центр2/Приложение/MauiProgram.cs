using Microsoft.Extensions.Logging;
using Microsoft.Maui.Handlers;
using Microsoft.Maui.Storage;

namespace CentrApp;

/// <summary>
/// Точка сборки MAUI-приложения. Здесь же настраиваем нативный WebView под каждую платформу,
/// чтобы страница сайта выглядела как приложение (без рамок браузера), корректно работали
/// микрофон/камера/выбор файлов и офлайн-страница.
/// </summary>
public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder.UseMauiApp<App>();

#if ANDROID
        // Тонкая настройка нативного Android WebView.
        WebViewHandler.Mapper.AppendToMapping("CentrAndroidWebView", (handler, view) =>
        {
            if (handler.PlatformView is not Android.Webkit.WebView native)
                return;

            var settings = native.Settings;
            settings.JavaScriptEnabled = true;                       // сайт полностью на JS
            settings.DomStorageEnabled = true;                       // localStorage -> сессия Supabase
            settings.DatabaseEnabled = true;
            settings.MediaPlaybackRequiresUserGesture = false;       // голосовые/видео проигрываются
            settings.AllowFileAccess = true;
            settings.AllowContentAccess = true;
            settings.JavaScriptCanOpenWindowsAutomatically = true;
            settings.SetSupportMultipleWindows(true);                // ссылки target=_blank

            native.SetWebViewClient(new CentrWebViewClient());       // офлайн-страница + внешние ссылки + мост токена
            native.SetWebChromeClient(new CentrWebChromeClient());   // микрофон/камера + выбор файлов

            // Запоминаем нативный WebView, чтобы кнопка «Назад» и мост пуш-токена имели к нему доступ.
            CentrWeb.Platform = native;

            // Если пуш-токен уже получен — сразу отдадим его сайту.
            PushManager.InjectTokenIfAvailable(native);
        });
#endif

#if WINDOWS
        // На Windows перехватываем неудачную навигацию (нет интернета) и показываем свою офлайн-страницу.
        WebViewHandler.Mapper.AppendToMapping("CentrWindowsWebView", (handler, view) =>
        {
            if (handler.PlatformView is not Microsoft.UI.Xaml.Controls.WebView2 wv2)
                return;

            void Hook()
            {
                if (wv2.CoreWebView2 is null) return;
                wv2.CoreWebView2.NavigationCompleted += async (_, args) =>
                {
                    if (args.IsSuccess) return;
                    try
                    {
                        using var stream = await FileSystem.OpenAppPackageFileAsync("offline.html");
                        using var reader = new System.IO.StreamReader(stream);
                        var html = await reader.ReadToEndAsync();
                        wv2.CoreWebView2.NavigateToString(html);
                    }
                    catch { /* офлайн-страница не критична */ }
                };
            }

            if (wv2.CoreWebView2 is not null) Hook();
            else wv2.CoreWebView2Initialized += (_, _) => Hook();
        });
#endif

#if DEBUG
        builder.Logging.AddDebug();
#endif
        return builder.Build();
    }
}
