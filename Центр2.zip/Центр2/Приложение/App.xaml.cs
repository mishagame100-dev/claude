using Microsoft.Maui.Controls.PlatformConfiguration.AndroidSpecific;

namespace CentrApp;

public partial class App : Microsoft.Maui.Controls.Application
{
    public App()
    {
        InitializeComponent();

        // РЕШЕНИЕ: Указан полный путь к классу, чтобы убрать двусмысленность
        Microsoft.Maui.Controls.Application.Current?
            .On<Microsoft.Maui.Controls.PlatformConfiguration.Android>()
            .UseWindowSoftInputModeAdjust(WindowSoftInputModeAdjust.Resize);

        // Одно окно на весь экран с сайтом внутри — никаких рамок браузера.
        MainPage = new MainPage();
    }
}
