-- ============================================================================
--  ЦЕНТР 2.0 — ПОЛНАЯ СХЕМА БАЗЫ ДАННЫХ (Supabase / PostgreSQL)
--  ----------------------------------------------------------------------------
--  КАК ПРИМЕНИТЬ (2 минуты):
--    1. Создайте НОВЫЙ проект на supabase.com (для centr.gt.tc).
--    2. Откройте в нём:  SQL Editor  →  New query.
--    3. Скопируйте ВЕСЬ этот файл, вставьте и нажмите  Run.
--    4. Дождитесь «Success. No rows returned» — всё готово.
--
--  Файл безопасно запускать повторно (все объекты создаются через IF NOT EXISTS
--  и CREATE OR REPLACE). На пустом проекте он создаёт базу с нуля.
--
--  ГЛАВНЫЕ ОТЛИЧИЯ ОТ ВЕРСИИ 1 (и почему багов больше не будет):
--    • Прочтение хранится ОДНОЙ строкой-курсором (chat_participants.last_read_at),
--      а не флагом в каждом сообщении. Раньше открытие чата с 3000 непрочитанных
--      запускало UPDATE 3000 строк → тайм-аут запроса + 3000 realtime-событий
--      всем клиентам → интерфейс «вставал» и сообщения перестава­ли отправляться.
--      Это и был баг «в один момент бац и я больше не могу писать».
--    • Удаление сообщения = физическое удаление строки (DELETE). Следов нет.
--    • «В сети» считается по свежести last_seen, а не по нестабильному presence.
--    • Есть блокировка пользователей, очистка истории, удаление чата, архив,
--      закрепление чатов, отключение уведомлений, приватность, антифлуд.
--    • Реалтайм ходит в СЕКРЕТНЫЕ топики (profiles.rt_key / chats.rt_key), поэтому
--      каждый клиент получает только свои события, а не поток всей базы.
--    • Добавлены индексы — запросы остаются быстрыми на сотнях тысяч сообщений.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 0. РАСШИРЕНИЯ И ОБЩИЕ НАСТРОЙКИ
-- ---------------------------------------------------------------------------
create extension if not exists "pgcrypto";      -- gen_random_uuid()
create extension if not exists "pg_trgm";       -- быстрый поиск по подстроке

-- Даём запросам чуть больше времени, чем 8 секунд по умолчанию: тяжёлые
-- выборки истории на медленном мобильном интернете больше не рвутся.
do $$
begin
  execute 'alter role authenticated set statement_timeout = ''20s''';
  execute 'alter role anon          set statement_timeout = ''15s''';
exception when others then null;
end $$;


-- ---------------------------------------------------------------------------
-- 1. ТАБЛИЦЫ
-- ---------------------------------------------------------------------------

-- 1.1 Профили пользователей ------------------------------------------------
create table if not exists public.profiles (
    id              uuid primary key references auth.users(id) on delete cascade,
    username        text not null default 'Пользователь',
    handle          text unique,
    avatar_url      text,
    status_text     text default 'Привет! Я в Центре.',
    last_seen       timestamptz default now(),
    created_at      timestamptz default now(),
    ringtone        text default 'center',

    -- Секретный ключ личного realtime-топика. Знает только сам пользователь,
    -- поэтому подписаться на чужие события невозможно.
    rt_key          uuid not null default gen_random_uuid(),

    -- Приватность
    privacy_last_seen text not null default 'everyone',  -- everyone | friends | nobody
    privacy_messages  text not null default 'everyone',  -- everyone | friends
    -- Интерфейс (синхронизируется между устройствами)
    ui_theme        text not null default 'dark',        -- dark | light | midnight
    ui_accent       text not null default 'green',
    ui_wallpaper    text default null,
    ui_font_size    int  not null default 15
);

-- 1.2 Чаты ------------------------------------------------------------------
create table if not exists public.chats (
    id              uuid primary key default gen_random_uuid(),
    is_group        boolean not null default false,
    name            text,
    avatar_url      text,
    created_by      uuid references auth.users(id) on delete set null,
    created_at      timestamptz default now(),
    -- Время последнего сообщения — по нему сортируется список чатов
    -- (без него приходилось отдельно запрашивать последнее сообщение
    --  для КАЖДОГО чата: 20 чатов = 41 запрос при каждом входе).
    last_message_at timestamptz default now(),
    -- Секретный ключ realtime-топика чата (знают только участники)
    rt_key          uuid not null default gen_random_uuid()
);

-- 1.3 Участники чатов + личные настройки чата ------------------------------
create table if not exists public.chat_participants (
    chat_id             uuid not null references public.chats(id) on delete cascade,
    user_id             uuid not null references auth.users(id) on delete cascade,
    joined_at           timestamptz default now(),
    role                text not null default 'member',   -- admin | member

    -- КУРСОР ПРОЧТЕНИЯ. Всё «прочитано / не прочитано» и все галочки
    -- считаются по нему. Обновление = 1 строка вместо тысяч.
    last_read_at        timestamptz not null default '1970-01-01',
    last_delivered_at   timestamptz not null default '1970-01-01',

    -- «Очистить историю у меня»: сообщения старше этой даты не показываются
    -- лично мне, но у собеседника остаются.
    cleared_at          timestamptz,

    is_pinned           boolean not null default false,
    is_muted            boolean not null default false,
    is_archived         boolean not null default false,
    draft               text,                              -- черновик сообщения

    primary key (chat_id, user_id)
);

-- 1.4 Сообщения -------------------------------------------------------------
--     Обратите внимание: НЕТ полей is_read / is_delivered / is_deleted.
--     Прочтение — курсором, удаление — физическое.
create table if not exists public.messages (
    id                  uuid primary key default gen_random_uuid(),
    chat_id             uuid not null references public.chats(id) on delete cascade,
    sender_id           uuid not null references auth.users(id) on delete cascade,
    text                text,
    media_url           text,
    media_type          text,        -- image | video | voice | audio | file
    media_meta          jsonb,       -- {size, duration, w, h, name}
    reply_to_message_id uuid references public.messages(id) on delete set null,
    forwarded_from      uuid references auth.users(id) on delete set null,
    edited_at           timestamptz,
    is_pinned           boolean not null default false,
    pinned_at           timestamptz,
    pinned_by           uuid references auth.users(id) on delete set null,
    created_at          timestamptz not null default now(),
    -- Системные сообщения («Иван вступил в группу») отображаются по центру
    system_kind         text
);

-- 1.5 «Удалить только у меня» ----------------------------------------------
create table if not exists public.message_hides (
    message_id  uuid not null references public.messages(id) on delete cascade,
    user_id     uuid not null references auth.users(id) on delete cascade,
    primary key (message_id, user_id)
);

-- 1.6 Реакции ---------------------------------------------------------------
create table if not exists public.message_reactions (
    id          uuid primary key default gen_random_uuid(),
    message_id  uuid not null references public.messages(id) on delete cascade,
    user_id     uuid not null references auth.users(id) on delete cascade,
    emoji       text not null,
    created_at  timestamptz default now(),
    unique (message_id, user_id)
);

-- 1.7 Дружба ----------------------------------------------------------------
create table if not exists public.friendships (
    id            uuid primary key default gen_random_uuid(),
    requester_id  uuid not null references auth.users(id) on delete cascade,
    addressee_id  uuid not null references auth.users(id) on delete cascade,
    status        text not null default 'pending',    -- pending | accepted
    created_at    timestamptz default now(),
    updated_at    timestamptz default now(),
    unique (requester_id, addressee_id)
);

-- 1.8 Блокировки (НОВОЕ) ----------------------------------------------------
create table if not exists public.blocks (
    blocker_id  uuid not null references auth.users(id) on delete cascade,
    blocked_id  uuid not null references auth.users(id) on delete cascade,
    created_at  timestamptz default now(),
    primary key (blocker_id, blocked_id)
);

-- 1.9 Жалобы (НОВОЕ) — видны только администраторам в админке -------------
create table if not exists public.reports (
    id          uuid primary key default gen_random_uuid(),
    reporter_id uuid references auth.users(id) on delete set null,
    target_user uuid references auth.users(id) on delete set null,
    message_id  uuid references public.messages(id) on delete set null,
    chat_id     uuid references public.chats(id) on delete set null,
    reason      text,
    note        text,
    handled     boolean not null default false,
    created_at  timestamptz default now()
);

-- 1.10 Пуш-токены устройств -------------------------------------------------
create table if not exists public.device_tokens (
    token       text primary key,
    user_id     uuid not null references auth.users(id) on delete cascade,
    platform    text default 'android',
    created_at  timestamptz default now(),
    updated_at  timestamptz default now()
);

-- 1.11 Общие настройки приложения ------------------------------------------
create table if not exists public.app_settings (
    id              int primary key default 1,
    asset_version   bigint not null default 1,   -- «сбросить кеш у всех»
    motd            text,                        -- объявление в шапке (или NULL)
    media_ttl_days  int not null default 0,      -- 0 = не удалять медиа автоматически
    signup_open     boolean not null default true,
    updated_at      timestamptz default now(),
    constraint app_settings_single check (id = 1)
);
insert into public.app_settings (id) values (1) on conflict (id) do nothing;

-- 1.12 Администраторы ------------------------------------------------------
create table if not exists public.admins (
    user_id uuid primary key references auth.users(id) on delete cascade
);


-- ---------------------------------------------------------------------------
-- 2. ИНДЕКСЫ  (без них большие чаты начинают тормозить)
-- ---------------------------------------------------------------------------
create index if not exists idx_messages_chat_time     on public.messages (chat_id, created_at desc);
create index if not exists idx_messages_sender_time   on public.messages (sender_id, created_at desc);
create index if not exists idx_messages_reply         on public.messages (reply_to_message_id);
create index if not exists idx_messages_pinned        on public.messages (chat_id) where is_pinned;
create index if not exists idx_messages_media         on public.messages (chat_id, created_at desc) where media_url is not null;
create index if not exists idx_messages_text_trgm     on public.messages using gin ("text" gin_trgm_ops);

create index if not exists idx_participants_user      on public.chat_participants (user_id);
create index if not exists idx_participants_chat      on public.chat_participants (chat_id);
create index if not exists idx_chats_last_msg         on public.chats (last_message_at desc);
create index if not exists idx_reactions_message      on public.message_reactions (message_id);
create index if not exists idx_friendships_req        on public.friendships (requester_id);
create index if not exists idx_friendships_addr       on public.friendships (addressee_id);
create index if not exists idx_hides_user             on public.message_hides (user_id);
create index if not exists idx_tokens_user            on public.device_tokens (user_id);
create index if not exists idx_profiles_handle_trgm   on public.profiles using gin (handle gin_trgm_ops);
create index if not exists idx_profiles_username_trgm on public.profiles using gin (username gin_trgm_ops);


-- ---------------------------------------------------------------------------
-- 3. БАЗОВЫЕ ХЕЛПЕРЫ
-- ---------------------------------------------------------------------------

-- Участник ли пользователь в чате. SECURITY DEFINER, чтобы использовать
-- внутри RLS-политик без бесконечной рекурсии.
create or replace function public.is_chat_member(_chat uuid, _user uuid)
returns boolean language sql stable security definer set search_path = public as $$
    select exists (select 1 from chat_participants where chat_id = _chat and user_id = _user);
$$;

create or replace function public.is_admin(_user uuid default auth.uid())
returns boolean language sql stable security definer set search_path = public as $$
    select exists (select 1 from admins where user_id = _user);
$$;

create or replace function public.are_friends(_a uuid, _b uuid)
returns boolean language sql stable security definer set search_path = public as $$
    select exists (
        select 1 from friendships
        where status = 'accepted'
          and ((requester_id = _a and addressee_id = _b) or (requester_id = _b and addressee_id = _a))
    );
$$;

create or replace function public.is_blocked_between(_a uuid, _b uuid)
returns boolean language sql stable security definer set search_path = public as $$
    select exists (
        select 1 from blocks
        where (blocker_id = _a and blocked_id = _b) or (blocker_id = _b and blocked_id = _a)
    );
$$;

-- Отправка realtime-события. Обёрнута в исключение: если Realtime по какой-то
-- причине недоступен, сообщение всё равно сохранится (клиент подхватит его
-- резервным опросом). Надёжность важнее мгновенности.
create or replace function public.rt_emit(_topic text, _event text, _payload jsonb)
returns void language plpgsql security definer set search_path = public, realtime as $$
begin
    perform realtime.send(_payload, _event, _topic, false);
exception when others then
    null;
end $$;


-- ---------------------------------------------------------------------------
-- 4. РЕГИСТРАЦИЯ: автоматическое создание профиля
-- ---------------------------------------------------------------------------
create or replace function public.make_unique_handle(_base text)
returns text language plpgsql security definer set search_path = public as $$
declare
    base text;
    candidate text;
    i int := 0;
begin
    base := lower(regexp_replace(coalesce(_base, ''), '[^a-zA-Z0-9_]', '', 'g'));
    if length(base) < 3 then base := 'user' || substr(replace(gen_random_uuid()::text,'-',''), 1, 6); end if;
    base := substr(base, 1, 20);
    candidate := base;
    while exists (select 1 from profiles where handle = candidate) loop
        i := i + 1;
        candidate := substr(base, 1, 20) || i::text;
        if i > 9999 then
            candidate := 'user' || substr(replace(gen_random_uuid()::text,'-',''), 1, 8);
            exit;
        end if;
    end loop;
    return candidate;
end $$;

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
declare
    uname text;
begin
    uname := coalesce(nullif(trim(new.raw_user_meta_data->>'username'), ''),
                      split_part(coalesce(new.email,'user'), '@', 1));
    insert into public.profiles (id, username, handle)
    values (new.id, left(uname, 24), public.make_unique_handle(uname))
    on conflict (id) do nothing;
    return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
    after insert on auth.users
    for each row execute function public.handle_new_user();


-- ---------------------------------------------------------------------------
-- 5. ТРИГГЕРЫ СООБЩЕНИЙ: защита + realtime
-- ---------------------------------------------------------------------------

-- 5.1 ПЕРЕД вставкой: антифлуд, блокировки, приватность.
create or replace function public.messages_before_insert()
returns trigger language plpgsql security definer set search_path = public as $$
declare
    recent int;
    grp boolean;
    peer uuid;
    peer_privacy text;
begin
    if new.sender_id <> auth.uid() and not public.is_admin(auth.uid()) then
        raise exception 'CENTR_FORBIDDEN: чужой отправитель';
    end if;

    -- Антифлуд: не больше 25 сообщений за 10 секунд с одного аккаунта.
    select count(*) into recent
      from messages
     where sender_id = new.sender_id
       and created_at > now() - interval '10 seconds';
    if recent >= 25 then
        raise exception 'CENTR_RATE_LIMIT: слишком много сообщений, подождите пару секунд';
    end if;

    select is_group into grp from chats where id = new.chat_id;

    if not coalesce(grp, false) then
        select user_id into peer
          from chat_participants
         where chat_id = new.chat_id and user_id <> new.sender_id
         limit 1;

        if peer is not null then
            if public.is_blocked_between(new.sender_id, peer) then
                raise exception 'CENTR_BLOCKED: переписка недоступна';
            end if;
            select privacy_messages into peer_privacy from profiles where id = peer;
            if peer_privacy = 'friends' and not public.are_friends(new.sender_id, peer) then
                raise exception 'CENTR_ONLY_FRIENDS: пользователь принимает сообщения только от друзей';
            end if;
        end if;
    end if;

    return new;
end $$;

drop trigger if exists trg_messages_before_insert on public.messages;
create trigger trg_messages_before_insert
    before insert on public.messages
    for each row execute function public.messages_before_insert();

-- 5.2 ПОСЛЕ вставки: обновить чат и разослать realtime адресно.
create or replace function public.messages_after_insert()
returns trigger language plpgsql security definer set search_path = public as $$
declare
    chat_key uuid;
    payload jsonb;
    p record;
    sender_name text;
begin
    update chats set last_message_at = new.created_at where id = new.chat_id
      returning rt_key into chat_key;

    select username into sender_name from profiles where id = new.sender_id;

    payload := jsonb_build_object(
        'id', new.id,
        'chat_id', new.chat_id,
        'sender_id', new.sender_id,
        'sender_name', sender_name,
        'text', new.text,
        'media_url', new.media_url,
        'media_type', new.media_type,
        'media_meta', new.media_meta,
        'reply_to_message_id', new.reply_to_message_id,
        'forwarded_from', new.forwarded_from,
        'system_kind', new.system_kind,
        'is_pinned', new.is_pinned,
        'created_at', new.created_at
    );

    -- В канал чата — для тех, у кого он открыт прямо сейчас.
    perform public.rt_emit('c:' || chat_key::text, 'msg_new', payload);

    -- В личный канал каждого участника — чтобы обновился список чатов
    -- и счётчик непрочитанных (включая автора: у него может быть 2 устройства).
    for p in select user_id from chat_participants where chat_id = new.chat_id loop
        perform public.rt_emit(
            'u:' || (select rt_key from profiles where id = p.user_id)::text,
            'inbox', payload
        );
    end loop;

    return new;
end $$;

drop trigger if exists trg_messages_after_insert on public.messages;
create trigger trg_messages_after_insert
    after insert on public.messages
    for each row execute function public.messages_after_insert();

-- 5.3 ПОСЛЕ изменения / удаления — сообщаем участникам чата.
create or replace function public.messages_after_change()
returns trigger language plpgsql security definer set search_path = public as $$
declare
    chat_key uuid;
    row_data record;
begin
    row_data := coalesce(new, old);
    select rt_key into chat_key from chats where id = row_data.chat_id;
    if chat_key is null then return null; end if;

    if tg_op = 'DELETE' then
        perform public.rt_emit('c:' || chat_key::text, 'msg_del',
            jsonb_build_object('id', old.id, 'chat_id', old.chat_id));
    else
        perform public.rt_emit('c:' || chat_key::text, 'msg_upd',
            jsonb_build_object(
                'id', new.id, 'chat_id', new.chat_id, 'text', new.text,
                'edited_at', new.edited_at, 'is_pinned', new.is_pinned,
                'pinned_at', new.pinned_at, 'media_url', new.media_url,
                'media_type', new.media_type
            ));
    end if;
    return null;
end $$;

drop trigger if exists trg_messages_after_update on public.messages;
create trigger trg_messages_after_update
    after update on public.messages
    for each row execute function public.messages_after_change();

drop trigger if exists trg_messages_after_delete on public.messages;
create trigger trg_messages_after_delete
    after delete on public.messages
    for each row execute function public.messages_after_change();

-- 5.4 Реакции — точечное обновление у участников чата.
create or replace function public.reactions_after_change()
returns trigger language plpgsql security definer set search_path = public as $$
declare
    row_data record;
    chat_key uuid;
    mid uuid;
begin
    row_data := coalesce(new, old);
    mid := row_data.message_id;
    select c.rt_key into chat_key from messages m join chats c on c.id = m.chat_id where m.id = mid;
    if chat_key is null then return null; end if;
    perform public.rt_emit('c:' || chat_key::text, 'react', jsonb_build_object('message_id', mid));
    return null;
end $$;

drop trigger if exists trg_reactions_change on public.message_reactions;
create trigger trg_reactions_change
    after insert or update or delete on public.message_reactions
    for each row execute function public.reactions_after_change();

-- 5.5 Изменение курсора прочтения → мгновенные галочки у собеседника.
create or replace function public.participants_after_update()
returns trigger language plpgsql security definer set search_path = public as $$
declare
    chat_key uuid;
begin
    if new.last_read_at is distinct from old.last_read_at
       or new.last_delivered_at is distinct from old.last_delivered_at then
        select rt_key into chat_key from chats where id = new.chat_id;
        perform public.rt_emit('c:' || chat_key::text, 'read',
            jsonb_build_object('chat_id', new.chat_id, 'user_id', new.user_id,
                               'read_at', new.last_read_at,
                               'delivered_at', new.last_delivered_at));
    end if;
    return null;
end $$;

drop trigger if exists trg_participants_after_update on public.chat_participants;
create trigger trg_participants_after_update
    after update on public.chat_participants
    for each row execute function public.participants_after_update();

-- 5.6 Заявки в друзья / блокировки → личный канал адресата.
create or replace function public.friendships_after_change()
returns trigger language plpgsql security definer set search_path = public as $$
declare
    row_data record;
    a uuid; b uuid;
begin
    row_data := coalesce(new, old);
    a := row_data.requester_id; b := row_data.addressee_id;
    perform public.rt_emit('u:' || (select rt_key from profiles where id = a)::text, 'friends', '{}'::jsonb);
    perform public.rt_emit('u:' || (select rt_key from profiles where id = b)::text, 'friends', '{}'::jsonb);
    return null;
end $$;

drop trigger if exists trg_friendships_change on public.friendships;
create trigger trg_friendships_change
    after insert or update or delete on public.friendships
    for each row execute function public.friendships_after_change();


-- ---------------------------------------------------------------------------
-- 6. RLS — ПРАВА ДОСТУПА
-- ---------------------------------------------------------------------------
alter table public.profiles           enable row level security;
alter table public.chats              enable row level security;
alter table public.chat_participants  enable row level security;
alter table public.messages           enable row level security;
alter table public.message_hides      enable row level security;
alter table public.message_reactions  enable row level security;
alter table public.friendships        enable row level security;
alter table public.blocks             enable row level security;
alter table public.reports            enable row level security;
alter table public.device_tokens      enable row level security;
alter table public.app_settings       enable row level security;
alter table public.admins             enable row level security;

-- Снимаем прежние политики, чтобы файл можно было запускать повторно.
do $$
declare r record;
begin
    for r in
        select schemaname, tablename, policyname from pg_policies
        where schemaname = 'public'
          and tablename in ('profiles','chats','chat_participants','messages','message_hides',
                            'message_reactions','friendships','blocks','reports',
                            'device_tokens','app_settings','admins')
    loop
        execute format('drop policy if exists %I on %I.%I', r.policyname, r.schemaname, r.tablename);
    end loop;
end $$;

-- 6.1 PROFILES: профиль видят все авторизованные (это нужно для поиска по @ID),
--      НО секретный ключ realtime-топика (rt_key) не должен утекать никому,
--      иначе можно было бы подписаться на чужие сообщения. Поэтому доступ
--      к колонкам выдаётся поимённо, а свой полный профиль читается через
--      представление my_profile.
create policy profiles_select on public.profiles
    for select to authenticated using (true);
create policy profiles_update_self on public.profiles
    for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy profiles_insert_self on public.profiles
    for insert to authenticated with check (id = auth.uid());

-- Представление «мой профиль»: работает с правами владельца, поэтому отдаёт
-- rt_key — но только для своей строки.
drop view if exists public.my_profile;
create view public.my_profile as
    select * from public.profiles where id = auth.uid();

-- Отбираем общий доступ к таблице и выдаём только безопасные колонки.
revoke select, update, insert on public.profiles from authenticated, anon;
grant select (id, username, handle, avatar_url, status_text, last_seen, created_at,
              ringtone, privacy_last_seen, privacy_messages,
              ui_theme, ui_accent, ui_wallpaper, ui_font_size)
    on public.profiles to authenticated;
grant update (username, handle, avatar_url, status_text, last_seen, ringtone,
              privacy_last_seen, privacy_messages,
              ui_theme, ui_accent, ui_wallpaper, ui_font_size)
    on public.profiles to authenticated;
grant insert (id, username, handle) on public.profiles to authenticated;
grant select on public.my_profile to authenticated;

-- Публичный «безопасный» взгляд на профиль: last_seen скрывается по настройкам
-- приватности и при блокировке.
create or replace function public.visible_last_seen(_target uuid)
returns timestamptz language plpgsql stable security definer set search_path = public as $$
declare
    pr text; ls timestamptz;
begin
    select privacy_last_seen, last_seen into pr, ls from profiles where id = _target;
    if _target = auth.uid() then return ls; end if;
    if public.is_blocked_between(auth.uid(), _target) then return null; end if;
    if pr = 'nobody' then return null; end if;
    if pr = 'friends' and not public.are_friends(auth.uid(), _target) then return null; end if;
    return ls;
end $$;

-- 6.2 CHATS: видит участник.
create policy chats_select on public.chats
    for select to authenticated using (public.is_chat_member(id, auth.uid()));
create policy chats_insert on public.chats
    for insert to authenticated with check (created_by = auth.uid());
create policy chats_update on public.chats
    for update to authenticated
    using (public.is_chat_member(id, auth.uid()))
    with check (public.is_chat_member(id, auth.uid()));

-- 6.3 CHAT_PARTICIPANTS: участник видит состав своих чатов, меняет только свою строку.
create policy participants_select on public.chat_participants
    for select to authenticated using (public.is_chat_member(chat_id, auth.uid()));
create policy participants_update_self on public.chat_participants
    for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy participants_delete_self on public.chat_participants
    for delete to authenticated using (user_id = auth.uid());

-- 6.4 MESSAGES: читает участник, пишет только от своего имени.
--      Изменение и удаление — только через функции ниже (edit_message,
--      delete_messages), поэтому UPDATE/DELETE-политик для клиента нет.
create policy messages_select on public.messages
    for select to authenticated using (public.is_chat_member(chat_id, auth.uid()));
create policy messages_insert on public.messages
    for insert to authenticated
    with check (sender_id = auth.uid() and public.is_chat_member(chat_id, auth.uid()));

-- 6.5 Остальное
create policy hides_all on public.message_hides
    for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy reactions_select on public.message_reactions
    for select to authenticated using (
        exists (select 1 from messages m where m.id = message_id and public.is_chat_member(m.chat_id, auth.uid()))
    );
create policy reactions_write on public.message_reactions
    for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy friendships_select on public.friendships
    for select to authenticated using (requester_id = auth.uid() or addressee_id = auth.uid());

create policy blocks_select on public.blocks
    for select to authenticated using (blocker_id = auth.uid() or blocked_id = auth.uid());

create policy reports_insert on public.reports
    for insert to authenticated with check (reporter_id = auth.uid());
create policy reports_select_admin on public.reports
    for select to authenticated using (public.is_admin(auth.uid()));

create policy tokens_all on public.device_tokens
    for all to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

create policy settings_select on public.app_settings
    for select to authenticated using (true);
create policy settings_select_anon on public.app_settings
    for select to anon using (true);
create policy settings_update_admin on public.app_settings
    for update to authenticated using (public.is_admin(auth.uid()));

create policy admins_select on public.admins
    for select to authenticated using (user_id = auth.uid() or public.is_admin(auth.uid()));


-- ---------------------------------------------------------------------------
-- 7. ЧАТЫ: создание, вступление, выход
-- ---------------------------------------------------------------------------

-- Личный чат 1-на-1: находит существующий или создаёт новый.
create or replace function public.get_or_create_direct_chat(other_user uuid)
returns uuid language plpgsql security definer set search_path = public as $$
declare
    me uuid := auth.uid();
    found uuid;
    new_id uuid;
begin
    if me is null then raise exception 'CENTR_AUTH: нужен вход'; end if;
    if other_user = me then
        -- «Сохранённые сообщения» — чат с самим собой.
        select c.id into found
          from chats c
          join chat_participants p on p.chat_id = c.id
         where c.is_group = false
         group by c.id
        having count(*) = 1 and min(p.user_id) = me
         limit 1;
        if found is not null then return found; end if;
        insert into chats (is_group, created_by) values (false, me) returning id into new_id;
        insert into chat_participants (chat_id, user_id, role) values (new_id, me, 'admin');
        return new_id;
    end if;

    if public.is_blocked_between(me, other_user) then
        raise exception 'CENTR_BLOCKED: пользователь недоступен';
    end if;

    select c.id into found
      from chats c
      join chat_participants p1 on p1.chat_id = c.id and p1.user_id = me
      join chat_participants p2 on p2.chat_id = c.id and p2.user_id = other_user
     where c.is_group = false
     limit 1;
    if found is not null then return found; end if;

    insert into chats (is_group, created_by) values (false, me) returning id into new_id;
    insert into chat_participants (chat_id, user_id) values (new_id, me), (new_id, other_user);
    return new_id;
end $$;

create or replace function public.create_group_chat(group_name text, members uuid[])
returns uuid language plpgsql security definer set search_path = public as $$
declare
    me uuid := auth.uid();
    new_id uuid;
    m uuid;
begin
    if me is null then raise exception 'CENTR_AUTH: нужен вход'; end if;
    insert into chats (is_group, name, created_by)
    values (true, coalesce(nullif(trim(group_name), ''), 'Новая группа'), me)
    returning id into new_id;

    insert into chat_participants (chat_id, user_id, role) values (new_id, me, 'admin');
    foreach m in array coalesce(members, '{}'::uuid[]) loop
        if m <> me and not public.is_blocked_between(me, m) then
            insert into chat_participants (chat_id, user_id) values (new_id, m)
            on conflict do nothing;
        end if;
    end loop;
    return new_id;
end $$;

create or replace function public.add_group_member(_chat_id uuid, _user_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); uname text;
begin
    if not public.is_chat_member(_chat_id, me) then raise exception 'CENTR_FORBIDDEN'; end if;
    if not exists (select 1 from chats where id = _chat_id and is_group) then
        raise exception 'CENTR_NOT_GROUP: это не группа';
    end if;
    insert into chat_participants (chat_id, user_id) values (_chat_id, _user_id) on conflict do nothing;
    select username into uname from profiles where id = _user_id;
    insert into messages (chat_id, sender_id, system_kind, text)
    values (_chat_id, me, 'join', coalesce(uname,'Участник') || ' в группе');
end $$;

create or replace function public.group_preview(_chat_id uuid)
returns table (id uuid, name text, avatar_url text, member_count bigint)
language sql security definer set search_path = public as $$
    select c.id, c.name, c.avatar_url, (select count(*) from chat_participants p where p.chat_id = c.id)
      from chats c where c.id = _chat_id and c.is_group;
$$;

create or replace function public.join_group_by_id(_chat_id uuid)
returns uuid language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); uname text;
begin
    if me is null then raise exception 'CENTR_AUTH: нужен вход'; end if;
    if not exists (select 1 from chats where id = _chat_id and is_group) then
        raise exception 'CENTR_NOT_FOUND: группа не найдена';
    end if;
    if public.is_chat_member(_chat_id, me) then return _chat_id; end if;
    insert into chat_participants (chat_id, user_id) values (_chat_id, me);
    select username into uname from profiles where id = me;
    insert into messages (chat_id, sender_id, system_kind, text)
    values (_chat_id, me, 'join', coalesce(uname,'Участник') || ' вступил(а) в группу');
    return _chat_id;
end $$;

create or replace function public.leave_chat(_chat_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); uname text; left_count int;
begin
    if not public.is_chat_member(_chat_id, me) then return; end if;
    select username into uname from profiles where id = me;
    if exists (select 1 from chats where id = _chat_id and is_group) then
        insert into messages (chat_id, sender_id, system_kind, text)
        values (_chat_id, me, 'leave', coalesce(uname,'Участник') || ' покинул(а) группу');
    end if;
    delete from chat_participants where chat_id = _chat_id and user_id = me;
    select count(*) into left_count from chat_participants where chat_id = _chat_id;
    if left_count = 0 then delete from chats where id = _chat_id; end if;
end $$;

-- Выгнать участника (только администратор группы).
create or replace function public.kick_member(_chat_id uuid, _user_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); uname text;
begin
    if not exists (select 1 from chat_participants
                    where chat_id = _chat_id and user_id = me and role = 'admin') then
        raise exception 'CENTR_FORBIDDEN: только администратор группы';
    end if;
    delete from chat_participants where chat_id = _chat_id and user_id = _user_id;
    select username into uname from profiles where id = _user_id;
    insert into messages (chat_id, sender_id, system_kind, text)
    values (_chat_id, me, 'kick', coalesce(uname,'Участник') || ' удалён(а) из группы');
end $$;


-- ---------------------------------------------------------------------------
-- 8. ГЛАВНОЕ: СПИСОК ЧАТОВ ОДНИМ ЗАПРОСОМ
--     Раньше клиент делал 2 + 2×N запросов (для 20 чатов — 42 запроса при
--     каждом входе). Теперь — ровно один.
-- ---------------------------------------------------------------------------
create or replace function public.chat_overview()
returns table (
    chat_id uuid, is_group boolean, name text, avatar_url text, rt_key uuid,
    created_at timestamptz, last_message_at timestamptz,
    member_count bigint,
    other_id uuid, other_username text, other_handle text, other_avatar text,
    other_last_seen timestamptz,
    last_msg_id uuid, last_msg_text text, last_msg_media text,
    last_msg_sender uuid, last_msg_sender_name text, last_msg_at timestamptz,
    last_msg_system text,
    unread bigint,
    peer_read_at timestamptz, peer_delivered_at timestamptz,
    my_read_at timestamptz,
    is_pinned boolean, is_muted boolean, is_archived boolean, draft text,
    blocked_by_me boolean, blocked_me boolean,
    my_role text
)
language sql security definer set search_path = public stable as $$
    with mine as (
        select p.chat_id, p.last_read_at, p.cleared_at, p.is_pinned, p.is_muted,
               p.is_archived, p.draft, p.role as my_role
          from chat_participants p
         where p.user_id = auth.uid()
    ),
    peer as (
        select p.chat_id,
               p.user_id            as other_id,
               p.last_read_at       as peer_read_at,
               p.last_delivered_at  as peer_delivered_at
          from chat_participants p
          join chats c on c.id = p.chat_id
         where p.user_id <> auth.uid()
           and c.is_group = false
           and p.chat_id in (select chat_id from mine)
    ),
    last_msg as (
        select distinct on (m.chat_id)
               m.chat_id, m.id, m.text, m.media_type, m.sender_id, m.created_at, m.system_kind
          from messages m
          join mine mi on mi.chat_id = m.chat_id
         where (mi.cleared_at is null or m.created_at > mi.cleared_at)
           and not exists (select 1 from message_hides h where h.message_id = m.id and h.user_id = auth.uid())
         order by m.chat_id, m.created_at desc
    ),
    unread_counts as (
        select m.chat_id, count(*) as cnt
          from messages m
          join mine mi on mi.chat_id = m.chat_id
         where m.created_at > mi.last_read_at
           and (mi.cleared_at is null or m.created_at > mi.cleared_at)
           and m.sender_id <> auth.uid()
           and m.system_kind is null
         group by m.chat_id
    )
    select c.id, c.is_group, c.name, c.avatar_url, c.rt_key,
           c.created_at, c.last_message_at,
           (select count(*) from chat_participants cp where cp.chat_id = c.id),
           pe.other_id, op.username, op.handle, op.avatar_url,
           public.visible_last_seen(pe.other_id),
           lm.id, lm.text, lm.media_type, lm.sender_id, sp.username, lm.created_at, lm.system_kind,
           coalesce(uc.cnt, 0),
           pe.peer_read_at, pe.peer_delivered_at,
           mi.last_read_at,
           mi.is_pinned, mi.is_muted, mi.is_archived, mi.draft,
           coalesce((select true from blocks b where b.blocker_id = auth.uid() and b.blocked_id = pe.other_id), false),
           coalesce((select true from blocks b where b.blocker_id = pe.other_id and b.blocked_id = auth.uid()), false),
           mi.my_role
      from mine mi
      join chats c            on c.id = mi.chat_id
      left join peer pe       on pe.chat_id = c.id
      left join profiles op   on op.id = pe.other_id
      left join last_msg lm   on lm.chat_id = c.id
      left join profiles sp   on sp.id = lm.sender_id
      left join unread_counts uc on uc.chat_id = c.id
     order by mi.is_pinned desc, coalesce(lm.created_at, c.last_message_at, c.created_at) desc;
$$;

-- Страница сообщений (постраничная загрузка вместо «все 500 сразу»).
create or replace function public.messages_page(
    _chat uuid, _before timestamptz default null, _limit int default 40
)
returns setof public.messages
language sql security definer set search_path = public stable as $$
    select m.*
      from messages m
     where m.chat_id = _chat
       and public.is_chat_member(_chat, auth.uid())
       and (_before is null or m.created_at < _before)
       and (
            (select cleared_at from chat_participants
              where chat_id = _chat and user_id = auth.uid()) is null
            or m.created_at > (select cleared_at from chat_participants
                                where chat_id = _chat and user_id = auth.uid())
           )
       and not exists (select 1 from message_hides h where h.message_id = m.id and h.user_id = auth.uid())
     order by m.created_at desc
     limit least(greatest(coalesce(_limit, 40), 1), 200);
$$;

-- Сообщения ПОСЛЕ указанного времени — резервная догрузка, если realtime молчал
-- (свернули приложение, потеряли сеть, метро и т.п.).
create or replace function public.messages_since(_chat uuid, _after timestamptz)
returns setof public.messages
language sql security definer set search_path = public stable as $$
    select m.* from messages m
     where m.chat_id = _chat
       and public.is_chat_member(_chat, auth.uid())
       and m.created_at > _after
       and not exists (select 1 from message_hides h where h.message_id = m.id and h.user_id = auth.uid())
     order by m.created_at asc
     limit 200;
$$;

-- Закреплённые сообщения чата (не тянем всю историю ради них).
create or replace function public.pinned_messages(_chat uuid)
returns setof public.messages
language sql security definer set search_path = public stable as $$
    select m.* from messages m
     where m.chat_id = _chat and m.is_pinned
       and public.is_chat_member(_chat, auth.uid())
     order by m.pinned_at desc nulls last limit 20;
$$;

-- Медиа-галерея чата.
create or replace function public.chat_media(_chat uuid, _limit int default 60, _offset int default 0)
returns setof public.messages
language sql security definer set search_path = public stable as $$
    select m.* from messages m
     where m.chat_id = _chat and m.media_url is not null
       and public.is_chat_member(_chat, auth.uid())
     order by m.created_at desc
     limit least(coalesce(_limit,60), 200) offset coalesce(_offset,0);
$$;


-- ---------------------------------------------------------------------------
-- 9. ПРОЧТЕНИЕ, ДОСТАВКА, ПРИСУТСТВИЕ
-- ---------------------------------------------------------------------------

-- Отметить чат прочитанным: ОДНА строка вместо тысяч UPDATE.
create or replace function public.mark_chat_read(_chat uuid)
returns void language sql security definer set search_path = public as $$
    update chat_participants
       set last_read_at = greatest(last_read_at, now()),
           last_delivered_at = greatest(last_delivered_at, now())
     where chat_id = _chat and user_id = auth.uid();
$$;

create or replace function public.mark_delivered(_chat uuid)
returns void language sql security definer set search_path = public as $$
    update chat_participants
       set last_delivered_at = greatest(last_delivered_at, now())
     where chat_id = _chat and user_id = auth.uid();
$$;

-- «Я в сети»: обновляем last_seen. Вызывается раз в 45 секунд, только когда
-- приложение реально на экране.
create or replace function public.touch_presence()
returns timestamptz language sql security definer set search_path = public as $$
    update profiles set last_seen = now() where id = auth.uid() returning last_seen;
$$;

-- Кто из списка сейчас в сети (last_seen свежее 75 секунд) — с учётом приватности.
create or replace function public.presence_of(_ids uuid[])
returns table (user_id uuid, online boolean, last_seen timestamptz)
language sql security definer set search_path = public stable as $$
    select p.id,
           coalesce(public.visible_last_seen(p.id) > now() - interval '75 seconds', false),
           public.visible_last_seen(p.id)
      from profiles p
     where p.id = any(coalesce(_ids, '{}'::uuid[]));
$$;

-- Настройки чата: закрепить / отключить звук / архив / черновик.
create or replace function public.set_chat_flags(
    _chat uuid, _pinned boolean default null, _muted boolean default null,
    _archived boolean default null, _draft text default null
)
returns void language sql security definer set search_path = public as $$
    update chat_participants
       set is_pinned   = coalesce(_pinned, is_pinned),
           is_muted    = coalesce(_muted, is_muted),
           is_archived = coalesce(_archived, is_archived),
           draft       = case when _draft is null then draft
                              when _draft = ''    then null
                              else left(_draft, 4000) end
     where chat_id = _chat and user_id = auth.uid();
$$;


-- ---------------------------------------------------------------------------
-- 10. РЕДАКТИРОВАНИЕ И УДАЛЕНИЕ (БЕЗ СЛЕДОВ)
-- ---------------------------------------------------------------------------
create or replace function public.edit_message(_id uuid, _text text)
returns void language plpgsql security definer set search_path = public as $$
begin
    if not exists (select 1 from messages where id = _id and sender_id = auth.uid()) then
        raise exception 'CENTR_FORBIDDEN: можно менять только свои сообщения';
    end if;
    if coalesce(trim(_text), '') = '' then
        raise exception 'CENTR_EMPTY: текст не может быть пустым';
    end if;
    update messages set text = left(_text, 8000), edited_at = now() where id = _id;
end $$;

create or replace function public.pin_message(_id uuid, _pin boolean)
returns void language plpgsql security definer set search_path = public as $$
declare c uuid;
begin
    select chat_id into c from messages where id = _id;
    if c is null or not public.is_chat_member(c, auth.uid()) then
        raise exception 'CENTR_FORBIDDEN';
    end if;
    update messages
       set is_pinned = _pin,
           pinned_at = case when _pin then now() else null end,
           pinned_by = case when _pin then auth.uid() else null end
     where id = _id;
end $$;

-- УДАЛИТЬ У ВСЕХ. Строки удаляются физически — никакой пометки
-- «сообщение удалено» не остаётся (как и просил друг).
-- Возвращает список путей к файлам, чтобы клиент подчистил и хранилище.
create or replace function public.delete_messages(_ids uuid[])
returns table (media_url text)
language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid();
begin
    return query
    with allowed as (
        select m.id, m.media_url
          from messages m
         where m.id = any(coalesce(_ids, '{}'::uuid[]))
           and (
                m.sender_id = me
                or public.is_admin(me)
                -- администратор группы может убрать чужое сообщение из своей группы
                or exists (select 1 from chat_participants p
                            where p.chat_id = m.chat_id and p.user_id = me and p.role = 'admin'
                              and exists (select 1 from chats c where c.id = m.chat_id and c.is_group))
               )
    ),
    gone as (
        delete from messages where id in (select id from allowed) returning media_url
    )
    select g.media_url from gone g where g.media_url is not null;
end $$;

-- УДАЛИТЬ ТОЛЬКО У СЕБЯ (у собеседника сообщение останется).
create or replace function public.hide_messages(_ids uuid[])
returns void language sql security definer set search_path = public as $$
    insert into message_hides (message_id, user_id)
    select id, auth.uid() from messages
     where id = any(coalesce(_ids, '{}'::uuid[]))
       and public.is_chat_member(chat_id, auth.uid())
    on conflict do nothing;
$$;

-- ОЧИСТИТЬ ИСТОРИЮ У СЕБЯ: чат остаётся, история скрывается только у меня.
create or replace function public.clear_history(_chat uuid)
returns void language sql security definer set search_path = public as $$
    update chat_participants
       set cleared_at = now(), last_read_at = now(), draft = null
     where chat_id = _chat and user_id = auth.uid();
$$;

-- УДАЛИТЬ ВСЮ ПЕРЕПИСКУ У ВСЕХ. Именно этого не хватало: раньше приходилось
-- лезть в админку. В личном чате удаляет всё безвозвратно у обоих;
-- в группе доступно только администратору группы.
create or replace function public.delete_history_for_all(_chat uuid)
returns table (media_url text)
language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); grp boolean;
begin
    if not public.is_chat_member(_chat, me) then raise exception 'CENTR_FORBIDDEN'; end if;
    select is_group into grp from chats where id = _chat;
    if coalesce(grp,false) and not exists (
        select 1 from chat_participants where chat_id = _chat and user_id = me and role = 'admin')
    then
        raise exception 'CENTR_FORBIDDEN: только администратор группы';
    end if;

    return query
    with gone as (delete from messages where chat_id = _chat returning media_url)
    select g.media_url from gone g where g.media_url is not null;
end $$;

-- УДАЛИТЬ ЧАТ ЦЕЛИКОМ (у себя). Для личного чата — убирает и историю у обоих,
-- потому что «половина» переписки смысла не имеет.
create or replace function public.delete_chat(_chat uuid, _for_all boolean default false)
returns table (media_url text)
language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); grp boolean; others int;
begin
    if not public.is_chat_member(_chat, me) then raise exception 'CENTR_FORBIDDEN'; end if;
    select is_group into grp from chats where id = _chat;

    if coalesce(grp, false) then
        -- Из группы просто выходим (историю группы не рушим).
        perform public.leave_chat(_chat);
        return;
    end if;

    if _for_all then
        return query
        with gone as (delete from messages where chat_id = _chat returning media_url)
        select g.media_url from gone g where g.media_url is not null;
        delete from chats where id = _chat;   -- каскадом удалит участников
        return;
    end if;

    -- Удаляем «у себя»: выходим из чата. Если никого не осталось — чистим целиком.
    delete from chat_participants where chat_id = _chat and user_id = me;
    select count(*) into others from chat_participants where chat_id = _chat;
    if others = 0 then
        return query
        with gone as (delete from messages where chat_id = _chat returning media_url)
        select g.media_url from gone g where g.media_url is not null;
        delete from chats where id = _chat;
    end if;
end $$;


-- ---------------------------------------------------------------------------
-- 11. ДРУЗЬЯ
-- ---------------------------------------------------------------------------
create or replace function public.send_friend_request(addressee uuid)
returns text language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); existing record;
begin
    if me is null then raise exception 'CENTR_AUTH: нужен вход'; end if;
    if addressee = me then raise exception 'CENTR_SELF: нельзя добавить себя'; end if;
    if public.is_blocked_between(me, addressee) then
        raise exception 'CENTR_BLOCKED: пользователь недоступен';
    end if;

    select * into existing from friendships
     where (requester_id = me and addressee_id = addressee)
        or (requester_id = addressee and addressee_id = me)
     limit 1;

    if existing.id is not null then
        if existing.status = 'accepted' then return 'accepted'; end if;
        -- Встречная заявка — сразу дружба.
        if existing.requester_id = addressee then
            update friendships set status = 'accepted', updated_at = now() where id = existing.id;
            return 'accepted';
        end if;
        return 'pending';
    end if;

    insert into friendships (requester_id, addressee_id, status) values (me, addressee, 'pending');
    return 'pending';
end $$;

create or replace function public.respond_friend_request(requester uuid, accept boolean)
returns void language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid();
begin
    if accept then
        update friendships set status = 'accepted', updated_at = now()
         where requester_id = requester and addressee_id = me and status = 'pending';
    else
        delete from friendships where requester_id = requester and addressee_id = me;
    end if;
end $$;

create or replace function public.remove_friend(other uuid)
returns void language sql security definer set search_path = public as $$
    delete from friendships
     where (requester_id = auth.uid() and addressee_id = other)
        or (requester_id = other and addressee_id = auth.uid());
$$;

-- Список друзей и заявок одним запросом.
create or replace function public.friends_overview()
returns table (
    user_id uuid, username text, handle text, avatar_url text, status_text text,
    last_seen timestamptz, kind text
)
language sql security definer set search_path = public stable as $$
    select p.id, p.username, p.handle, p.avatar_url, p.status_text,
           public.visible_last_seen(p.id),
           case when f.status = 'accepted' then 'friend'
                when f.addressee_id = auth.uid() then 'incoming'
                else 'outgoing' end
      from friendships f
      join profiles p on p.id = case when f.requester_id = auth.uid()
                                     then f.addressee_id else f.requester_id end
     where (f.requester_id = auth.uid() or f.addressee_id = auth.uid())
       and not public.is_blocked_between(auth.uid(), p.id)
     order by 7, 2;
$$;


-- ---------------------------------------------------------------------------
-- 12. БЛОКИРОВКА (НОВОЕ)
-- ---------------------------------------------------------------------------
create or replace function public.block_user(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid();
begin
    if _id = me then raise exception 'CENTR_SELF'; end if;
    insert into blocks (blocker_id, blocked_id) values (me, _id) on conflict do nothing;
    -- Блокировка автоматически убирает дружбу и заявки.
    delete from friendships
     where (requester_id = me and addressee_id = _id) or (requester_id = _id and addressee_id = me);
    perform public.rt_emit('u:' || (select rt_key from profiles where id = _id)::text, 'blocks', '{}'::jsonb);
end $$;

create or replace function public.unblock_user(_id uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
    delete from blocks where blocker_id = auth.uid() and blocked_id = _id;
    perform public.rt_emit('u:' || (select rt_key from profiles where id = _id)::text, 'blocks', '{}'::jsonb);
end $$;

create or replace function public.blocked_list()
returns table (user_id uuid, username text, handle text, avatar_url text, created_at timestamptz)
language sql security definer set search_path = public stable as $$
    select p.id, p.username, p.handle, p.avatar_url, b.created_at
      from blocks b join profiles p on p.id = b.blocked_id
     where b.blocker_id = auth.uid()
     order by b.created_at desc;
$$;

create or replace function public.report_user(
    _target uuid, _message uuid default null, _chat uuid default null,
    _reason text default 'other', _note text default null
)
returns void language sql security definer set search_path = public as $$
    insert into reports (reporter_id, target_user, message_id, chat_id, reason, note)
    values (auth.uid(), _target, _message, _chat, left(coalesce(_reason,'other'), 40), left(_note, 1000));
$$;

-- Удаление собственного аккаунта: стираем все данные и обезличиваем профиль.
-- Саму запись входа (auth.users) может убрать администратор в админке —
-- без этого нельзя было бы освободить адрес почты для повторной регистрации.
create or replace function public.delete_my_account()
returns void language plpgsql security definer set search_path = public as $$
declare me uuid := auth.uid(); c record;
begin
    if me is null then raise exception 'CENTR_AUTH'; end if;

    delete from messages where sender_id = me;
    delete from message_reactions where user_id = me;
    delete from message_hides where user_id = me;
    delete from friendships where requester_id = me or addressee_id = me;
    delete from blocks where blocker_id = me or blocked_id = me;
    delete from device_tokens where user_id = me;

    -- Выходим из всех чатов; опустевшие удаляем целиком.
    for c in select chat_id from chat_participants where user_id = me loop
        delete from chat_participants where chat_id = c.chat_id and user_id = me;
        if not exists (select 1 from chat_participants where chat_id = c.chat_id) then
            delete from chats where id = c.chat_id;
        end if;
    end loop;

    update profiles
       set username = 'Удалённый аккаунт', handle = null, avatar_url = null,
           status_text = null, privacy_last_seen = 'nobody', privacy_messages = 'friends',
           rt_key = gen_random_uuid()
     where id = me;
end $$;


-- ---------------------------------------------------------------------------
-- 13. ПОИСК
-- ---------------------------------------------------------------------------
create or replace function public.search_people(_q text, _limit int default 20)
returns table (id uuid, username text, handle text, avatar_url text, status_text text)
language sql security definer set search_path = public stable as $$
    select p.id, p.username, p.handle, p.avatar_url, p.status_text
      from profiles p
     where p.id <> auth.uid()
       and not public.is_blocked_between(auth.uid(), p.id)
       and (p.handle ilike '%' || _q || '%' or p.username ilike '%' || _q || '%')
     order by (p.handle = lower(_q)) desc, length(coalesce(p.handle,'')), p.username
     limit least(coalesce(_limit, 20), 50);
$$;

-- Поиск по всем своим сообщениям (глобальный) или внутри одного чата.
create or replace function public.search_messages(
    _q text, _chat uuid default null, _limit int default 40
)
returns table (
    id uuid, chat_id uuid, sender_id uuid, text text, media_type text,
    created_at timestamptz, chat_name text, sender_name text, is_group boolean
)
language sql security definer set search_path = public stable as $$
    select m.id, m.chat_id, m.sender_id, m.text, m.media_type, m.created_at,
           coalesce(c.name, op.username) as chat_name,
           sp.username, c.is_group
      from messages m
      join chats c on c.id = m.chat_id
      join chat_participants mine on mine.chat_id = m.chat_id and mine.user_id = auth.uid()
      left join profiles sp on sp.id = m.sender_id
      left join lateral (
            select p.username from chat_participants cp
              join profiles p on p.id = cp.user_id
             where cp.chat_id = c.id and cp.user_id <> auth.uid() limit 1
      ) op on true
     where m.text ilike '%' || _q || '%'
       and (_chat is null or m.chat_id = _chat)
       and (mine.cleared_at is null or m.created_at > mine.cleared_at)
       and not exists (select 1 from message_hides h where h.message_id = m.id and h.user_id = auth.uid())
     order by m.created_at desc
     limit least(coalesce(_limit, 40), 100);
$$;


-- ---------------------------------------------------------------------------
-- 14. ОБСЛУЖИВАНИЕ (для админки)
-- ---------------------------------------------------------------------------

-- Сброс кеша у всех клиентов.
create or replace function public.bump_asset_version()
returns bigint language plpgsql security definer set search_path = public as $$
declare v bigint;
begin
    if not public.is_admin(auth.uid()) then raise exception 'CENTR_FORBIDDEN'; end if;
    update app_settings set asset_version = asset_version + 1, updated_at = now()
     where id = 1 returning asset_version into v;
    perform public.rt_emit('broadcast:app', 'asset_version', jsonb_build_object('v', v));
    return v;
end $$;

-- Статистика для панели «Обзор».
create or replace function public.admin_stats()
returns jsonb language plpgsql security definer set search_path = public as $$
declare res jsonb;
begin
    if not public.is_admin(auth.uid()) then raise exception 'CENTR_FORBIDDEN'; end if;
    select jsonb_build_object(
        'users',        (select count(*) from profiles),
        'online',       (select count(*) from profiles where last_seen > now() - interval '5 minutes'),
        'active_today', (select count(distinct sender_id) from messages where created_at > now() - interval '1 day'),
        'messages',     (select count(*) from messages),
        'messages_today',(select count(*) from messages where created_at > now() - interval '1 day'),
        'chats',        (select count(*) from chats),
        'groups',       (select count(*) from chats where is_group),
        'media',        (select count(*) from messages where media_url is not null),
        'reactions',    (select count(*) from message_reactions),
        'friendships',  (select count(*) from friendships where status = 'accepted'),
        'blocks',       (select count(*) from blocks),
        'reports_open', (select count(*) from reports where not handled),
        'db_size',      (select pg_database_size(current_database()))
    ) into res;
    return res;
end $$;

-- Удаление старых медиа (экономия места). Возвращает ссылки, которые
-- админка затем удаляет из хранилища.
create or replace function public.purge_old_media(_days int)
returns table (media_url text)
language plpgsql security definer set search_path = public as $$
begin
    if not public.is_admin(auth.uid()) then raise exception 'CENTR_FORBIDDEN'; end if;
    return query
    with gone as (
        update messages set media_url = null, media_type = null, media_meta = null
         where media_url is not null and created_at < now() - (_days || ' days')::interval
        returning media_url
    )
    select g.media_url from gone g;
end $$;

-- Первого администратора удобно назначить так:
--   insert into public.admins (user_id)
--   select id from auth.users where email = 'ваша@почта' on conflict do nothing;


-- ---------------------------------------------------------------------------
-- 15. ХРАНИЛИЩЕ ФАЙЛОВ (Storage)
-- ---------------------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('avatars', 'avatars', true, 5242880, array['image/jpeg','image/png','image/webp','image/gif'])
on conflict (id) do update set public = true, file_size_limit = 5242880;

insert into storage.buckets (id, name, public, file_size_limit)
values ('media', 'media', true, 26214400)   -- 25 МБ на файл
on conflict (id) do update set public = true, file_size_limit = 26214400;

do $$
declare r record;
begin
    for r in select policyname from pg_policies
              where schemaname = 'storage' and tablename = 'objects'
                and policyname like 'centr_%'
    loop
        execute format('drop policy if exists %I on storage.objects', r.policyname);
    end loop;
end $$;

create policy centr_read_public on storage.objects
    for select using (bucket_id in ('avatars','media'));
create policy centr_upload on storage.objects
    for insert to authenticated with check (bucket_id in ('avatars','media'));
create policy centr_update_own on storage.objects
    for update to authenticated using (bucket_id in ('avatars','media') and owner = auth.uid());
create policy centr_delete_own on storage.objects
    for delete to authenticated using (bucket_id in ('avatars','media') and owner = auth.uid());


-- ---------------------------------------------------------------------------
-- 16. ПРАВА НА ВЫЗОВ ФУНКЦИЙ
-- ---------------------------------------------------------------------------
grant usage on schema public to anon, authenticated;
grant execute on all functions in schema public to authenticated;
grant execute on function public.rt_emit(text, text, jsonb) to authenticated;

-- Realtime-публикация нужна только для app_settings (всё остальное ходит
-- через broadcast, поэтому лишний поток изменений базы клиентам не летит).
do $$
begin
    execute 'alter publication supabase_realtime add table public.app_settings';
exception when others then null;
end $$;


-- ============================================================================
--  ГОТОВО.
--  Дальше: Authentication → Providers → Email — включить (при желании выключить
--  подтверждение почты), и вписать URL сайта в Authentication → URL Configuration.
--  Подробности — в файле ИНСТРУКЦИЯ.md, раздел 2.
-- ============================================================================
