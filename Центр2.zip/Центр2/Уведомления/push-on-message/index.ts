// ============================================================================
//  ЦЕНТР 2.0 — ПУШ-УВЕДОМЛЕНИЯ О НОВЫХ СООБЩЕНИЯХ
//  ---------------------------------------------------------------------------
//  Это «Edge Function» — небольшая программа, которая живёт в Supabase и
//  срабатывает каждый раз, когда в таблицу messages добавляется строка.
//  Она находит участников чата, берёт токены их телефонов и просит Firebase
//  показать уведомление. Нужна только для приложения на Android;
//  сайт в браузере обходится без неё.
//
//  КАК ПОДКЛЮЧИТЬ — подробно в ИНСТРУКЦИЯ.md, раздел 6.
//  Кратко:
//    1. Установить Supabase CLI и выполнить:
//         supabase functions deploy push-on-message --no-verify-jwt
//    2. Добавить секрет с ключом Firebase:
//         supabase secrets set FIREBASE_SERVICE_ACCOUNT="$(cat service-account.json)"
//    3. В Supabase: Database → Webhooks → Create a new hook
//         таблица messages, событие INSERT, тип HTTP Request,
//         адрес — ссылка на эту функцию.
// ============================================================================

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY  = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const FIREBASE_SA  = Deno.env.get("FIREBASE_SERVICE_ACCOUNT") || "";

const admin = createClient(SUPABASE_URL, SERVICE_KEY, { auth: { persistSession: false } });

/* ---------------------------------------------------------------------------
 *  Получение токена доступа Firebase (OAuth2 через service account).
 *  Токен живёт час, поэтому кешируем его в памяти.
 * ------------------------------------------------------------------------- */
let cachedToken: { value: string; exp: number } | null = null;

function pemToBinary(pem: string): Uint8Array {
    const body = pem.replace(/-----BEGIN PRIVATE KEY-----/, "")
                    .replace(/-----END PRIVATE KEY-----/, "")
                    .replace(/\s/g, "");
    const raw = atob(body);
    const bytes = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
    return bytes;
}

function b64url(data: Uint8Array | string): string {
    const bytes = typeof data === "string" ? new TextEncoder().encode(data) : data;
    let bin = "";
    bytes.forEach(b => bin += String.fromCharCode(b));
    return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

async function getFirebaseToken(): Promise<{ token: string; projectId: string } | null> {
    if (!FIREBASE_SA) return null;
    let sa: any;
    try { sa = JSON.parse(FIREBASE_SA); } catch { return null; }
    if (!sa.client_email || !sa.private_key || !sa.project_id) return null;

    const now = Math.floor(Date.now() / 1000);
    if (cachedToken && cachedToken.exp > now + 60) {
        return { token: cachedToken.value, projectId: sa.project_id };
    }

    const header = { alg: "RS256", typ: "JWT" };
    const claims = {
        iss: sa.client_email,
        scope: "https://www.googleapis.com/auth/firebase.messaging",
        aud: "https://oauth2.googleapis.com/token",
        iat: now,
        exp: now + 3600,
    };
    const unsigned = `${b64url(JSON.stringify(header))}.${b64url(JSON.stringify(claims))}`;

    const key = await crypto.subtle.importKey(
        "pkcs8", pemToBinary(sa.private_key),
        { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"]
    );
    const sig = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(unsigned));
    const jwt = `${unsigned}.${b64url(new Uint8Array(sig))}`;

    const res = await fetch("https://oauth2.googleapis.com/token", {
        method: "POST",
        headers: { "content-type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
            grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
            assertion: jwt,
        }),
    });
    if (!res.ok) { console.error("OAuth error", await res.text()); return null; }
    const json = await res.json();
    cachedToken = { value: json.access_token, exp: now + 3500 };
    return { token: json.access_token, projectId: sa.project_id };
}

/* ---------------------------------------------------------------------------
 *  Отправка одного уведомления. Токены, которые Firebase считает мёртвыми,
 *  сразу удаляем из базы — иначе таблица device_tokens растёт мусором.
 * ------------------------------------------------------------------------- */
async function sendPush(token: string, auth: { token: string; projectId: string }, payload: Record<string, string>, title: string, body: string) {
    const res = await fetch(`https://fcm.googleapis.com/v1/projects/${auth.projectId}/messages:send`, {
        method: "POST",
        headers: { authorization: `Bearer ${auth.token}`, "content-type": "application/json" },
        body: JSON.stringify({
            message: {
                token,
                // Только data — уведомление рисует само приложение,
                // поэтому им можно управлять (например, не показывать
                // сообщение из уже открытого чата).
                data: payload,
                android: { priority: "high" },
            },
        }),
    });
    if (!res.ok) {
        const text = await res.text();
        if (text.includes("UNREGISTERED") || text.includes("INVALID_ARGUMENT") || text.includes("NOT_FOUND")) {
            await admin.from("device_tokens").delete().eq("token", token);
        } else {
            console.error("FCM error", res.status, text.slice(0, 300));
        }
    }
}

function previewOf(record: any): string {
    if (record.system_kind) return record.text || "";
    if (record.media_type === "image") return "📷 Фото";
    if (record.media_type === "voice") return "🎤 Голосовое сообщение";
    if (record.media_type === "audio") return "🎵 Аудио";
    if (record.media_type === "video") return "🎬 Видео";
    if (record.media_url) return "📎 Вложение";
    const t = String(record.text || "");
    return t.length > 140 ? t.slice(0, 140) + "…" : t;
}

Deno.serve(async (req) => {
    if (req.method === "OPTIONS") {
        return new Response("ok", { headers: { "access-control-allow-origin": "*", "access-control-allow-headers": "*" } });
    }
    try {
        const body = await req.json().catch(() => ({}));
        // Формат Database Webhook: { type: "INSERT", record: {...} }
        const record = body.record || body.message || body;
        if (!record || !record.chat_id || !record.sender_id) {
            return new Response(JSON.stringify({ skipped: "нет данных сообщения" }), { status: 200 });
        }
        // Системные сообщения («вступил в группу») пушить не нужно.
        if (record.system_kind) return new Response(JSON.stringify({ skipped: "системное" }), { status: 200 });

        const auth = await getFirebaseToken();
        if (!auth) {
            return new Response(JSON.stringify({ skipped: "Firebase не настроен" }), { status: 200 });
        }

        // Кому отправлять: участники чата, кроме автора и кроме тех,
        // кто отключил уведомления этого чата.
        const { data: parts } = await admin
            .from("chat_participants")
            .select("user_id,is_muted")
            .eq("chat_id", record.chat_id)
            .neq("user_id", record.sender_id);

        const targets = (parts || []).filter(p => !p.is_muted).map(p => p.user_id);
        if (!targets.length) return new Response(JSON.stringify({ sent: 0 }), { status: 200 });

        // Заблокировавшим отправителя не пишем.
        const { data: blocks } = await admin
            .from("blocks").select("blocker_id")
            .eq("blocked_id", record.sender_id).in("blocker_id", targets);
        const blocked = new Set((blocks || []).map(b => b.blocker_id));
        const finalTargets = targets.filter(t => !blocked.has(t));
        if (!finalTargets.length) return new Response(JSON.stringify({ sent: 0 }), { status: 200 });

        const [{ data: sender }, { data: chat }, { data: tokens }] = await Promise.all([
            admin.from("profiles").select("username").eq("id", record.sender_id).maybeSingle(),
            admin.from("chats").select("is_group,name").eq("id", record.chat_id).maybeSingle(),
            admin.from("device_tokens").select("token,user_id").in("user_id", finalTargets),
        ]);

        const senderName = sender?.username || "Сообщение";
        const title = chat?.is_group ? (chat.name || "Группа") : senderName;
        const preview = previewOf(record);
        const text = chat?.is_group ? `${senderName}: ${preview}` : preview;

        const payload: Record<string, string> = {
            type: "message",
            kind: "message",
            chat_id: String(record.chat_id),
            message_id: String(record.id || ""),
            sender_id: String(record.sender_id),
            title,
            body: text,
        };

        await Promise.all((tokens || []).map(t => sendPush(t.token, auth, payload, title, text)));
        return new Response(JSON.stringify({ sent: (tokens || []).length }), {
            headers: { "content-type": "application/json" },
        });
    } catch (e) {
        console.error(e);
        return new Response(JSON.stringify({ error: String(e) }), { status: 200 });
    }
});
