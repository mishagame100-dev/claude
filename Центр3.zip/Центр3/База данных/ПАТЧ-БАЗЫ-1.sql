-- ============================================================================
--  ЦЕНТР 3.0 — ПАТЧ БАЗЫ № 1
--  ---------------------------------------------------------------------------
--  Что исправляет:
--    1. Ошибку «function min(uuid) does not exist» при открытии
--       «Сохранённых сообщений» (чата с самим собой).
--    2. Залипание статуса «в сети» после выхода из аккаунта и
--       закрытия приложения — добавляет функцию go_offline().
--
--  КАК ПРИМЕНИТЬ: Supabase → SQL Editor → New query → вставить весь
--  этот файл → Run. Патч можно запускать повторно, данные он не
--  трогает: меняются только две функции.
-- ============================================================================

begin;

-- ---------------------------------------------------------------------------
--  1. ЛИЧНЫЙ ЧАТ 1-НА-1 И «СОХРАНЁННЫЕ СООБЩЕНИЯ»
--
--  Было:  having count(*) = 1 and min(p.user_id) = me
--  В Postgres нет агрегата min() для типа uuid — отсюда ошибка
--  «function min(uuid) does not exist». Смысл условия был «единственный
--  участник чата — это я», поэтому проверяем его честно:
--  bool_and(p.user_id = me) — все участники равны мне.
-- ---------------------------------------------------------------------------
create or replace function public.get_or_create_direct_chat(other_user uuid)
returns uuid language plpgsql security definer set search_path = public as $$
declare
    me uuid := auth.uid();
    found uuid;
    new_id uuid;
begin
    if me is null then raise exception 'CENTR_AUTH: нужен вход'; end if;
    if other_user = me then
        -- «Сохранённые сообщения» — чат с самим собой.
        select c.id into found
          from chats c
          join chat_participants p on p.chat_id = c.id
         where c.is_group = false
         group by c.id
        having count(*) = 1 and bool_and(p.user_id = me)
         limit 1;
        if found is not null then return found; end if;
        insert into chats (is_group, created_by) values (false, me) returning id into new_id;
        insert into chat_participants (chat_id, user_id, role) values (new_id, me, 'admin');
        return new_id;
    end if;

    if public.is_blocked_between(me, other_user) then
        raise exception 'CENTR_BLOCKED: пользователь недоступен';
    end if;

    select c.id into found
      from chats c
      join chat_participants p1 on p1.chat_id = c.id and p1.user_id = me
      join chat_participants p2 on p2.chat_id = c.id and p2.user_id = other_user
     where c.is_group = false
     limit 1;
    if found is not null then return found; end if;

    insert into chats (is_group, created_by) values (false, me) returning id into new_id;
    insert into chat_participants (chat_id, user_id) values (new_id, me), (new_id, other_user);
    return new_id;
end $$;

-- ---------------------------------------------------------------------------
--  2. ЯВНЫЙ УХОД В ОФФЛАЙН
--
--  Присутствие считается по last_seen: «в сети» = свежее 75 секунд.
--  При выходе или закрытии клиент просто переставал отмечаться,
--  поэтому собеседники ещё минуту видели «в сети». Теперь клиент
--  зовёт эту функцию и last_seen сразу уезжает за окно «в сети»
--  (но остаётся свежим — чтобы показать «был(а) недавно»).
--
--  security definer нужен по той же причине, что и у heartbeat():
--  права на колонку last_seen пользователю не выданы напрямую.
-- ---------------------------------------------------------------------------
create or replace function public.go_offline()
returns void language sql security definer set search_path = public as $$
    update public.profiles
       set last_seen = now() - interval '2 minutes'
     where id = auth.uid();
$$;

-- Звать её может только вошедший пользователь и только за себя.
revoke all on function public.go_offline() from public;
revoke all on function public.go_offline() from anon;
grant execute on function public.go_offline() to authenticated;

commit;

-- ============================================================================
--  ПРОВЕРКА (необязательно). Должны вернуться две строки:
--    select proname from pg_proc
--     where pronamespace = 'public'::regnamespace
--       and proname in ('get_or_create_direct_chat', 'go_offline');
-- ============================================================================
