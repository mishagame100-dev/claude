-- =====================================================================
--  ЦЕНТР — уведомления, когда приложение ЗАКРЫТО
--  Файл заменяет ручное создание Database Webhook в панели.
-- =====================================================================
--
--  КАК ЭТО РАБОТАЕТ
--  Закрытое приложение не может слушать сервер — его просто нет
--  в памяти. Единственный способ — Web Push: сервер стучится в
--  Google/Apple, а те будят телефон. Цепочка такая:
--
--      новое сообщение в таблице messages
--            ↓  (этот файл — триггер)
--      функция push-on-message в Supabase
--            ↓
--      Google FCM / Apple
--            ↓
--      уведомление на экране при закрытом приложении
--
--  Среднее звено (push-on-message) должно быть развёрнуто ДО запуска
--  этого файла: Supabase → Edge Functions → в списке есть push-on-message.
--  Если список пуст — сначала разверните функцию, потом вернитесь сюда.
--
--  ПЕРЕД ЗАПУСКОМ замените в строке 41 значение secret на то же
--  самое, что стоит в секрете CENTR_HOOK_SECRET у функции.
--
--  Где запускать: Supabase → SQL Editor → New query → вставить всё → Run.
-- =====================================================================

-- Расширение, которое позволяет базе ходить в сеть. В Supabase оно
-- обычно уже включено — строка просто ничего не сделает.
create extension if not exists pg_net;

create or replace function public.notify_new_message()
returns trigger
language plpgsql
security definer
set search_path = public, net, extensions
as $$
declare
    fn_url text := 'https://qalkvpooefezyrgkxpuc.supabase.co/functions/v1/push-on-message';
    secret text := 'ВСТАВЬТЕ_СЮДА_CENTR_HOOK_SECRET';
begin
    -- Служебные сообщения («Иван вступил в группу») не будят никого.
    if new.system_kind is not null then
        return new;
    end if;

    -- Запрос уходит фоном: отправка сообщения не ждёт ответа и не
    -- замедляется, даже если сервис пушей тормозит.
    perform net.http_post(
        url     := fn_url,
        headers := jsonb_build_object(
            'content-type',        'application/json',
            'x-centr-hook-secret', secret
        ),
        body    := jsonb_build_object(
            'type',   'INSERT',
            'table',  'messages',
            'schema', 'public',
            'record', to_jsonb(new)
        ),
        timeout_milliseconds := 5000
    );

    return new;
end;
$$;

-- Вызывать её вручную никто из клиента не должен — только триггер.
revoke all on function public.notify_new_message() from public, anon, authenticated;

drop trigger if exists trg_notify_new_message on public.messages;
create trigger trg_notify_new_message
    after insert on public.messages
    for each row execute function public.notify_new_message();

-- =====================================================================
--  ПРОВЕРКА (запускать отдельно, после того как отправите
--  себе тестовое сообщение с другого аккаунта)
--
--  Смотрим, что ответила функция. status_code 200 — всё хорошо,
--  403 — не совпал секрет, 404 — функция не развёрнута:
--
--      select id, status_code, content, created
--      from net._http_response
--      order by id desc
--      limit 10;
--
--  Если таблица пустая — триггер не срабатывает; проверьте:
--
--      select tgname, tgenabled from pg_trigger
--      where tgrelid = 'public.messages'::regclass and not tgisinternal;
--
--  Отключить всё обратно, если понадобится:
--
--      drop trigger if exists trg_notify_new_message on public.messages;
-- =====================================================================
