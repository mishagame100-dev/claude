-- ============================================================================
--  ЦЕНТР 3.0 — ПЕРЕНОС ДАННЫХ ИЗ СТАРОГО ПРОЕКТА В НОВЫЙ
--  ---------------------------------------------------------------------------
--  ЧТО ДЕЛАЕТ: копирует из старого проекта (okp-center.gt.tc) в новый
--  (centr.gt.tc) всех людей вместе с ПАРОЛЯМИ, все чаты, всю переписку,
--  реакции, друзей, токены телефонов и администраторов.
--
--  Старый проект при этом НЕ МЕНЯЕТСЯ — только читается. Старый мессенджер
--  продолжит работать как раньше.
--
--  ---------------------------------------------------------------------------
--  ПОРЯДОК ДЕЙСТВИЙ (делать ровно так)
--
--  1. Сначала выполните в НОВОМ проекте файл 01-СХЕМА.sql. Без него
--     переносить некуда.
--
--  2. Возьмите строку подключения СТАРОГО проекта:
--       старый проект на supabase.com → Connect (кнопка вверху)
--       → вкладка «Session pooler» → скопировать строку.
--     Выглядит так:
--       postgresql://postgres.abcdefgh:ПАРОЛЬ@aws-0-eu-central-1.pooler.supabase.com:5432/postgres
--     Пароль базы — тот, который задавали при создании проекта. Не помните:
--       Project Settings → Database → Reset database password.
--
--  3. Впишите её части в функцию _old_conn чуть ниже (пять значений).
--
--  4. Выполните ВЕСЬ этот файл в НОВОМ проекте: SQL Editor → New query → Run.
--     В конце появится таблица «СКОЛЬКО ПЕРЕНЕСЛОСЬ» — сверьте числа.
--
--  5. Выполните последнюю строку файла (удаление функции _old_conn),
--     чтобы пароль от старой базы не остался лежать в новой.
--
--  Файл можно запускать повторно: всё вставляется через ON CONFLICT DO NOTHING,
--  дубликатов не будет.
--
--  ---------------------------------------------------------------------------
--  ЧТО ВАЖНО ЗНАТЬ ЗАРАНЕЕ
--
--  • ПАРОЛИ переносятся. Люди войдут в новый Центр той же почтой и тем же
--    паролем. Ничего сбрасывать не нужно.
--
--  • ФАЙЛЫ (фото, аватары, голосовые) физически остаются в хранилище СТАРОГО
--    проекта, а в новую базу переезжают ссылки на них. Пока старый проект
--    жив — всё открывается. Поэтому старый проект удалять нельзя, и он не
--    должен «уснуть»: бесплатный тариф Supabase усыпляет проект после
--    7 дней полного простоя, а у спящего проекта файлы недоступны.
--    Заходите в старый Центр хотя бы раз в неделю, либо примите, что старые
--    картинки со временем перестанут открываться (текст переписки останется).
--
--  • «УДАЛЁННЫЕ» сообщения не переносятся. В старой версии удаление было
--    мягким: строка оставалась с флажком is_deleted и надписью «сообщение
--    удалено». Раз просили, чтобы следов не оставалось, — такие строки
--    просто не копируются.
--
--  • ПРОЧИТАНО/НЕ ПРОЧИТАНО сохраняется: старые флажки is_read
--    пересчитываются в новый курсор прочтения.
--
--  • Если dblink у вас не заработает (напишет «could not establish
--    connection»), смотрите в ИНСТРУКЦИЯ.md раздел «Перенос через файлы» —
--    там путь без dblink, через выгрузку CSV.
-- ============================================================================

create extension if not exists dblink;

-- ---------------------------------------------------------------------------
--  ЕДИНСТВЕННОЕ МЕСТО, КОТОРОЕ НУЖНО ЗАПОЛНИТЬ
--  Разберите скопированную строку подключения на части и впишите их.
--  Пример строки:
--    postgresql://postgres.abcdefgh:МойПароль@aws-0-eu-central-1.pooler.supabase.com:5432/postgres
--                 └──── user ────┘ └ password ┘ └────────────── host ─────────────┘ └port┘ └dbname┘
-- ---------------------------------------------------------------------------
create or replace function public._old_conn() returns text language sql immutable as $$
  select concat_ws(' ',
    'host=aws-0-eu-central-1.pooler.supabase.com',   -- ← host из строки
    'port=5432',                                      -- ← port
    'dbname=postgres',                                -- ← dbname
    'user=postgres.ВАШ_СТАРЫЙ_REF',                   -- ← user (с точкой и кодом проекта)
    'password=ВАШ_ПАРОЛЬ_БАЗЫ',                       -- ← password
    'sslmode=require',
    'connect_timeout=15'
  );
$$;


-- ---------------------------------------------------------------------------
--  0. ПРОВЕРКА СВЯЗИ. Если здесь ошибка — дальше идти нет смысла.
-- ---------------------------------------------------------------------------
do $$
declare n bigint;
begin
    select cnt into n from dblink(public._old_conn(),
        'select count(*) from public.profiles') as t(cnt bigint);
    raise notice 'Связь со старой базой есть. Профилей там: %', n;
exception when others then
    raise exception E'НЕ УДАЛОСЬ ПОДКЛЮЧИТЬСЯ К СТАРОЙ БАЗЕ.\n%\n\nПроверьте host/user/password в функции _old_conn выше. Строку берите на вкладке «Session pooler».', sqlerrm;
end $$;


-- ---------------------------------------------------------------------------
--  1. ГОТОВИМ НОВУЮ БАЗУ К МАССОВОЙ ЗАЛИВКЕ
--
--  Триггеры нужно снять на время переноса, иначе:
--   • антифлуд решит, что идёт атака (25 сообщений за 10 секунд), и всё упадёт;
--   • на каждое сообщение полетит realtime-событие — это десятки тысяч
--     напрасных событий и мгновенно сожжённая бесплатная квота;
--   • триггер регистрации попытается создать пустые профили поверх настоящих.
-- ---------------------------------------------------------------------------
alter table public.messages          disable trigger trg_messages_before_insert;
alter table public.messages          disable trigger trg_messages_after_insert;
alter table public.messages          disable trigger trg_messages_after_update;
alter table public.messages          disable trigger trg_messages_after_delete;
alter table public.message_reactions disable trigger trg_reactions_change;
alter table public.chat_participants disable trigger trg_participants_after_update;
alter table public.friendships       disable trigger trg_friendships_change;
alter table auth.users               disable trigger on_auth_user_created;


-- ---------------------------------------------------------------------------
--  2. ЛЮДИ (вместе с паролями)
--
--  Копируем только те столбцы, которые есть в обеих версиях Supabase —
--  так перенос не сломается, даже если версии немного разные.
--  encrypted_password и есть «пароль»: он хранится хешем, поэтому
--  переносится как обычное значение, и вход работает как раньше.
-- ---------------------------------------------------------------------------
insert into auth.users (
    instance_id, id, aud, role, email, encrypted_password, email_confirmed_at,
    raw_app_meta_data, raw_user_meta_data, created_at, updated_at, last_sign_in_at
)
select
    '00000000-0000-0000-0000-000000000000'::uuid,
    o.id, 'authenticated', 'authenticated', o.email, o.encrypted_password,
    coalesce(o.email_confirmed_at, o.created_at, now()),
    coalesce(o.raw_app_meta_data, '{"provider":"email","providers":["email"]}'::jsonb),
    coalesce(o.raw_user_meta_data, '{}'::jsonb),
    coalesce(o.created_at, now()), coalesce(o.updated_at, now()), o.last_sign_in_at
from dblink(public._old_conn(), $q$
    select id, email, encrypted_password, email_confirmed_at,
           raw_app_meta_data, raw_user_meta_data, created_at, updated_at, last_sign_in_at
      from auth.users
     where email is not null and encrypted_password is not null
$q$) as o(
    id uuid, email text, encrypted_password text, email_confirmed_at timestamptz,
    raw_app_meta_data jsonb, raw_user_meta_data jsonb,
    created_at timestamptz, updated_at timestamptz, last_sign_in_at timestamptz
)
on conflict (id) do nothing;

-- Запись «способ входа». Современный Supabase заводит её при регистрации и
-- опирается на неё при входе по почте. Без этой строки часть аккаунтов может
-- не пустить внутрь, поэтому создаём её сами для всех перенесённых.
insert into auth.identities (provider_id, user_id, identity_data, provider, created_at, updated_at)
select u.id::text, u.id,
       jsonb_build_object('sub', u.id::text, 'email', u.email,
                          'email_verified', true, 'phone_verified', false),
       'email', coalesce(u.created_at, now()), now()
  from auth.users u
 where not exists (
        select 1 from auth.identities i
         where i.user_id = u.id and i.provider = 'email')
on conflict do nothing;


-- ---------------------------------------------------------------------------
--  3. ПРОФИЛИ
--
--  Строки профилей уже могли появиться (их создаёт триггер регистрации),
--  поэтому не вставляем, а дописываем настоящие значения поверх.
--  @ID переносим как есть — люди привыкли к своим адресам. Если такой @ID
--  в новой базе почему-то уже занят, оставляем сгенерированный.
-- ---------------------------------------------------------------------------
create temp table _old_profiles as
select * from dblink(public._old_conn(), $q$
    select id, username, handle, avatar_url, status_text, last_seen, created_at, ringtone
      from public.profiles
$q$) as o(
    id uuid, username text, handle text, avatar_url text, status_text text,
    last_seen timestamptz, created_at timestamptz, ringtone text
);

-- Профиль обязан существовать до правки (триггер мы отключили).
insert into public.profiles (id, username, handle)
select p.id, coalesce(nullif(trim(p.username), ''), 'Пользователь'),
       public.make_unique_handle(coalesce(p.handle, p.username))
  from _old_profiles p
 where exists (select 1 from auth.users u where u.id = p.id)
on conflict (id) do nothing;

update public.profiles np set
    username    = coalesce(nullif(trim(op.username), ''), np.username),
    avatar_url  = coalesce(op.avatar_url, np.avatar_url),
    status_text = coalesce(op.status_text, np.status_text),
    last_seen   = coalesce(op.last_seen, np.last_seen),
    created_at  = coalesce(op.created_at, np.created_at),
    ringtone    = coalesce(op.ringtone, np.ringtone)
from _old_profiles op
where op.id = np.id;

-- @ID отдельным шагом: только если он свободен.
update public.profiles np set handle = op.handle
from _old_profiles op
where op.id = np.id
  and op.handle is not null
  and op.handle <> np.handle
  and not exists (select 1 from public.profiles x where x.handle = op.handle);


-- ---------------------------------------------------------------------------
--  4. ЧАТЫ
-- ---------------------------------------------------------------------------
insert into public.chats (id, is_group, name, avatar_url, created_by, created_at, last_message_at)
select o.id, coalesce(o.is_group, false), o.name, o.avatar_url,
       case when exists (select 1 from auth.users u where u.id = o.created_by)
            then o.created_by end,
       coalesce(o.created_at, now()), coalesce(o.created_at, now())
from dblink(public._old_conn(), $q$
    select id, is_group, name, avatar_url, created_by, created_at from public.chats
$q$) as o(id uuid, is_group boolean, name text, avatar_url text,
          created_by uuid, created_at timestamptz)
on conflict (id) do nothing;


-- ---------------------------------------------------------------------------
--  5. УЧАСТНИКИ
--
--  Создателю группы даём права администратора группы — в старой версии
--  ролей не было вообще, а без администратора группой некому управлять.
-- ---------------------------------------------------------------------------
insert into public.chat_participants (chat_id, user_id, joined_at, role)
select o.chat_id, o.user_id, coalesce(o.joined_at, now()),
       case when c.created_by = o.user_id then 'admin' else 'member' end
from dblink(public._old_conn(), $q$
    select chat_id, user_id, joined_at from public.chat_participants
$q$) as o(chat_id uuid, user_id uuid, joined_at timestamptz)
join public.chats c on c.id = o.chat_id
where exists (select 1 from auth.users u where u.id = o.user_id)
on conflict (chat_id, user_id) do nothing;

-- В группе без администратора назначаем самого раннего участника,
-- иначе группу нельзя будет ни переименовать, ни почистить.
update public.chat_participants p set role = 'admin'
where p.role <> 'admin'
  and exists (select 1 from public.chats c where c.id = p.chat_id and c.is_group)
  and not exists (select 1 from public.chat_participants q
                   where q.chat_id = p.chat_id and q.role = 'admin')
  and p.joined_at = (select min(q.joined_at) from public.chat_participants q where q.chat_id = p.chat_id);


-- ---------------------------------------------------------------------------
--  6. СООБЩЕНИЯ  (самая большая часть)
--
--  Забираем всё, кроме мягко удалённых. Ответы (reply_to_message_id)
--  подставляем ВТОРЫМ проходом: ответ мог ссылаться на удалённое сообщение,
--  которое мы не переносим, и прямая вставка упёрлась бы в связь по ключу.
-- ---------------------------------------------------------------------------
create temp table _old_messages as
select * from dblink(public._old_conn(), $q$
    select id, chat_id, sender_id, text, media_url, media_type, created_at,
           reply_to_message_id, is_pinned, pinned_at, pinned_by, forwarded_from, edited_at,
           coalesce(is_read, false) as is_read
      from public.messages
     where coalesce(is_deleted, false) = false
$q$) as o(
    id uuid, chat_id uuid, sender_id uuid, text text, media_url text, media_type text,
    created_at timestamptz, reply_to_message_id uuid, is_pinned boolean,
    pinned_at timestamptz, pinned_by uuid, forwarded_from uuid, edited_at timestamptz,
    is_read boolean
);
create index on _old_messages (id);
create index on _old_messages (chat_id, created_at);

insert into public.messages (
    id, chat_id, sender_id, text, media_url, media_type,
    created_at, is_pinned, pinned_at, pinned_by, forwarded_from, edited_at,
    reply_to_message_id, media_meta, system_kind
)
select o.id, o.chat_id, o.sender_id, o.text, o.media_url, o.media_type,
       coalesce(o.created_at, now()), coalesce(o.is_pinned, false), o.pinned_at,
       case when exists (select 1 from auth.users u where u.id = o.pinned_by) then o.pinned_by end,
       case when exists (select 1 from auth.users u where u.id = o.forwarded_from) then o.forwarded_from end,
       o.edited_at,
       null, null, null
from _old_messages o
join public.chats c on c.id = o.chat_id
where exists (select 1 from auth.users u where u.id = o.sender_id)
on conflict (id) do nothing;

-- Второй проход: связываем ответы, у которых уцелел адресат.
update public.messages nm set reply_to_message_id = o.reply_to_message_id
from _old_messages o
where o.id = nm.id
  and o.reply_to_message_id is not null
  and exists (select 1 from public.messages t where t.id = o.reply_to_message_id);


-- ---------------------------------------------------------------------------
--  7. ПРОЧИТАНО / НЕ ПРОЧИТАНО
--
--  В старой версии это был флажок в каждом сообщении, в новой — одна дата
--  на чат. Берём время самого свежего ПРОЧИТАННОГО чужого сообщения:
--  всё, что позже, останется непрочитанным — как человек и оставил.
-- ---------------------------------------------------------------------------
update public.chat_participants p
   set last_read_at      = greatest(p.last_read_at, r.read_upto),
       last_delivered_at = greatest(p.last_delivered_at, r.read_upto)
from (
    select om.chat_id, cp.user_id, max(om.created_at) as read_upto
      from _old_messages om
      join public.chat_participants cp on cp.chat_id = om.chat_id
     where om.is_read = true
       and om.sender_id <> cp.user_id
     group by om.chat_id, cp.user_id
) r
where r.chat_id = p.chat_id and r.user_id = p.user_id;


-- ---------------------------------------------------------------------------
--  8. РЕАКЦИИ, ДРУЗЬЯ, ТОКЕНЫ ТЕЛЕФОНОВ, АДМИНИСТРАТОРЫ
-- ---------------------------------------------------------------------------
insert into public.message_reactions (id, message_id, user_id, emoji, created_at)
select o.id, o.message_id, o.user_id, o.emoji, coalesce(o.created_at, now())
from dblink(public._old_conn(), $q$
    select id, message_id, user_id, emoji, created_at from public.message_reactions
$q$) as o(id uuid, message_id uuid, user_id uuid, emoji text, created_at timestamptz)
where exists (select 1 from public.messages m where m.id = o.message_id)
  and exists (select 1 from auth.users u where u.id = o.user_id)
on conflict do nothing;

insert into public.friendships (id, requester_id, addressee_id, status, created_at, updated_at)
select o.id, o.requester_id, o.addressee_id,
       case when o.status = 'accepted' then 'accepted' else 'pending' end,
       coalesce(o.created_at, now()), coalesce(o.updated_at, now())
from dblink(public._old_conn(), $q$
    select id, requester_id, addressee_id, status, created_at, updated_at from public.friendships
$q$) as o(id uuid, requester_id uuid, addressee_id uuid, status text,
          created_at timestamptz, updated_at timestamptz)
where exists (select 1 from auth.users a where a.id = o.requester_id)
  and exists (select 1 from auth.users b where b.id = o.addressee_id)
on conflict (requester_id, addressee_id) do nothing;

insert into public.device_tokens (token, user_id, platform, created_at, updated_at)
select o.token, o.user_id, coalesce(o.platform, 'android'),
       coalesce(o.created_at, now()), coalesce(o.updated_at, now())
from dblink(public._old_conn(), $q$
    select token, user_id, platform, created_at, updated_at from public.device_tokens
$q$) as o(token text, user_id uuid, platform text, created_at timestamptz, updated_at timestamptz)
where exists (select 1 from auth.users u where u.id = o.user_id)
on conflict (token) do nothing;

insert into public.admins (user_id)
select o.user_id
from dblink(public._old_conn(), $q$ select user_id from public.admins $q$) as o(user_id uuid)
where exists (select 1 from auth.users u where u.id = o.user_id)
on conflict do nothing;


-- ---------------------------------------------------------------------------
--  9. ДОВОДКА
-- ---------------------------------------------------------------------------
-- Время последнего сообщения — по нему сортируется список чатов.
update public.chats c
   set last_message_at = coalesce(m.mx, c.created_at, now())
from (select chat_id, max(created_at) as mx from public.messages group by chat_id) m
where m.chat_id = c.id;

-- Чаты без единого участника (мусор из старой базы) убираем.
delete from public.chats c
 where not exists (select 1 from public.chat_participants p where p.chat_id = c.id);


-- ---------------------------------------------------------------------------
-- 10. ВКЛЮЧАЕМ ТРИГГЕРЫ ОБРАТНО. Без этого мессенджер работать не будет!
-- ---------------------------------------------------------------------------
alter table public.messages          enable trigger trg_messages_before_insert;
alter table public.messages          enable trigger trg_messages_after_insert;
alter table public.messages          enable trigger trg_messages_after_update;
alter table public.messages          enable trigger trg_messages_after_delete;
alter table public.message_reactions enable trigger trg_reactions_change;
alter table public.chat_participants enable trigger trg_participants_after_update;
alter table public.friendships       enable trigger trg_friendships_change;
alter table auth.users               enable trigger on_auth_user_created;

analyze;


-- ---------------------------------------------------------------------------
-- 11. ОТЧЁТ. Сверьте эти числа со старым проектом.
-- ---------------------------------------------------------------------------
select 'СКОЛЬКО ПЕРЕНЕСЛОСЬ' as "—", '' as "количество"
union all select 'Люди (вход по почте и паролю)', (select count(*)::text from auth.users)
union all select 'Профили',            (select count(*)::text from public.profiles)
union all select 'Чаты',               (select count(*)::text from public.chats)
union all select '  из них группы',    (select count(*)::text from public.chats where is_group)
union all select 'Участия в чатах',    (select count(*)::text from public.chat_participants)
union all select 'Сообщения',          (select count(*)::text from public.messages)
union all select '  с файлами',        (select count(*)::text from public.messages where media_url is not null)
union all select '  с ответами',       (select count(*)::text from public.messages where reply_to_message_id is not null)
union all select 'Реакции',            (select count(*)::text from public.message_reactions)
union all select 'Дружбы и заявки',    (select count(*)::text from public.friendships)
union all select 'Токены телефонов',   (select count(*)::text from public.device_tokens)
union all select 'Администраторы',     (select count(*)::text from public.admins)
union all select 'Непрочитанных всего',(select coalesce(sum(x)::text,'0') from (
        select count(*) as x from public.messages m
          join public.chat_participants p on p.chat_id = m.chat_id
         where m.created_at > p.last_read_at and m.sender_id <> p.user_id) z)
union all select 'Размер новой базы',  (select pg_size_pretty(pg_database_size(current_database())));

drop table if exists _old_profiles;
drop table if exists _old_messages;


-- ============================================================================
--  ПОСЛЕДНИЙ ШАГ — ОБЯЗАТЕЛЬНО.
--  Уберите функцию с паролем от старой базы. Выделите строку ниже и нажмите Run.
--
--      drop function if exists public._old_conn();
--
--  После переноса проверьте: войдите в новый Центр своей старой почтой
--  и старым паролем — должны увидеть все свои чаты.
-- ============================================================================
