/* ==========================================================================
 *  ЦЕНТР 3.0 — SERVICE WORKER
 *  --------------------------------------------------------------------------
 *  Что это и зачем. Service worker — небольшая программа, которая живёт
 *  в браузере рядом с сайтом и перехватывает обращения к файлам.
 *  В версии 2.0 его не было, из-за чего:
 *
 *    1. Chrome не предлагал «Установить приложение» — только ярлык. Настоящая
 *       установка (иконка, полный экран, запуск без адресной строки) требует
 *       именно service worker.
 *    2. Каждый заход заново скачивал страницу, стили и скрипт с хостинга.
 *       У бесплатного InfinityFree есть суточный лимит обращений, и сайт
 *       ложился на «слишком много запросов» именно из-за этого.
 *    3. Без сети сайт не открывался вообще — белый экран.
 *
 *  Теперь оболочка приложения лежит в памяти устройства. Второй и все
 *  следующие запуски происходят мгновенно и вообще без обращения к хостингу,
 *  а без интернета показывается сохранённая переписка.
 *
 *  ВАЖНО: сами сообщения здесь НЕ кешируются. Они идут напрямую к Supabase
 *  и никогда не отдаются из кеша — иначе можно было бы увидеть устаревшую
 *  переписку. За их сохранение на устройстве отвечает IndexedDB в app.js.
 * ========================================================================== */

// Версию менять при каждом обновлении файлов сайта. Кнопка «Очистить кеш
// у всех» в админке делает это за вас, меняя ?v= в адресах.
const CACHE = "centr-shell-v6";

// Оболочка приложения — то, без чего не показать ни одного экрана.
const SHELL = [
    "./",
    "./index.html",
    "./style.css",
    "./app.js",
    "./config.js",
    "./manifest.json",
    "./icon-192.png",
    "./icon-512.png",
];

// Звуки звонка кешируем отдельно и лениво: они нужны не всем и весят больше.
const LAZY = [
    "./sounds/center.mp3", "./sounds/classic.mp3",
    "./sounds/soft.mp3", "./sounds/digital.mp3", "./sounds/urgent.mp3",
];

// Хостинг с JS-проверкой (InfinityFree) иногда отвечает не файлом, а HTML
// страницей проверки — и делает это с кодом 200, так что простой проверки
// response.ok не достаточно. Если такой ответ попадёт в кеш, манифест или
// скрипт останутся битыми даже после того, как сервер начнёт отдавать их
// правильно. Поэтому перед сохранением сверяем тип ответа с расширением.
function isSaneResponse(url, response) {
    if (!response || !response.ok) return false;
    const type = (response.headers.get("content-type") || "").toLowerCase();
    if (!type) return true;
    if (/\.json$/i.test(url.pathname)) return type.includes("json");
    if (/\.css$/i.test(url.pathname)) return type.includes("css");
    if (/\.js$/i.test(url.pathname)) return /javascript|ecmascript/.test(type);
    return true;
}

// Скачать и положить в кеш — только если пришёл именно файл.
// credentials: "same-origin" — чтобы cookie хостинга уходили с запросом
// и проверка не срабатывала.
async function putIfSane(cache, resource) {
    try {
        const req = typeof resource === "string"
            ? new Request(resource, { credentials: "same-origin" })
            : resource;
        const res = await fetch(req);
        if (!isSaneResponse(new URL(req.url), res)) return false;
        await cache.put(req, res.clone());
        return true;
    } catch (_) {
        return false;
    }
}

self.addEventListener("install", (event) => {
    event.waitUntil((async () => {
        const cache = await caches.open(CACHE);
        // addAll падает целиком, если хотя бы один файл не скачался,
        // поэтому кладём по одному и не мешаем установке из-за мелочи.
        await Promise.all(SHELL.map(u => putIfSane(cache, u)));
        self.skipWaiting();
    })());
});

self.addEventListener("activate", (event) => {
    event.waitUntil((async () => {
        const cache = await caches.open(CACHE);
        // Убираем кеши прежних версий.
        const names = await caches.keys();
        await Promise.all(names.filter(n => n !== CACHE).map(n => caches.delete(n)));
        // Звуки докешируем здесь же: они нужны не всем и весят больше,
        // поэтому не задерживаем ими установку.
        for (const u of LAZY) { await putIfSane(cache, u); }
        await self.clients.claim();
    })());
});

// Сообщение от страницы: «сбрось всё» (админка нажала «Очистить кеш у всех»).
self.addEventListener("message", (event) => {
    if (event.data === "centr-clear-cache") {
        event.waitUntil((async () => {
            const names = await caches.keys();
            await Promise.all(names.map(n => caches.delete(n)));
        })());
    }
});

/* ---------------------------- ПУШ-УВЕДОМЛЕНИЯ ---------------------------- *
 *  Когда сайт/приложение закрыто, сообщение приносит пуш-служба
 *  браузера, а показать уведомление обязан именно service worker —
 *  страницы в этот момент не существует. Именно поэтому раньше
 *  уведомлений не было вовсе: этих двух обработчиков в файле не было.
 *  Нагрузку присылает функция push-on-message: { title, body, chat_id, … }.
 * ------------------------------------------------------------------------- */
/* Спрашиваем у открытого окна, какой чат сейчас на экране. Ответ
 * ждём не дольше 400 мс: не ответило — считаем, что окна нет,
 * и уведомление показываем. Лучше лишняя шторка, чем пропущенное
 * сообщение. */
function askWindow(client, timeout = 400) {
    return new Promise((resolve) => {
        const ch = new MessageChannel();
        const t = setTimeout(() => resolve(null), timeout);
        ch.port1.onmessage = (e) => { clearTimeout(t); resolve(e.data || null); };
        try { client.postMessage({ type: "centr-who" }, [ch.port2]); }
        catch (_) { clearTimeout(t); resolve(null); }
    });
}

async function chatIsOnScreen(chatId) {
    if (!chatId) return false;
    const all = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
    const visible = all.filter(c => c.visibilityState === "visible");
    if (!visible.length) return false;      // приложение закрыто или свёрнуто
    const answers = await Promise.all(visible.map(c => askWindow(c)));
    return answers.some(a => a && a.visible && a.chat_id === chatId);
}

self.addEventListener("push", (event) => {
    let data = {};
    try { data = event.data ? event.data.json() : {}; }
    catch (_) { data = { body: event.data ? event.data.text() : "" }; }

    const title  = data.title || "Центр";
    const chatId = data.chat_id || "";
    event.waitUntil((async () => {
        // Открыт тот же чат и окно на экране — человек уже читает
        // сообщение, шторка только мешает. Показывать её мы не обязаны:
        // браузер требует видимого уведомления лишь тогда, когда ни
        // одного открытого окна нет.
        if (await chatIsOnScreen(chatId)) return;
        await self.registration.showNotification(title, {
            body:  data.body || "Новое сообщение",
            icon:  "icon-192.png",
            badge: "icon-192.png",
            // Один tag на чат: десять сообщений не превратятся в десять шторок.
            tag: chatId ? "centr-" + chatId : "centr",
            renotify: true,
            data: { chat_id: chatId }
        });
    })());
});

// Клик по уведомлению: если окно уже открыто — переводим фокус на него
// и просим открыть нужный чат; если нет — запускаем приложение.
self.addEventListener("notificationclick", (event) => {
    event.notification.close();
    const chatId = (event.notification.data && event.notification.data.chat_id) || "";
    event.waitUntil((async () => {
        const all = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
        for (const client of all) {
            if (!client.url.startsWith(self.registration.scope)) continue;
            try { await client.focus(); } catch (_) {}
            if (chatId) client.postMessage({ type: "centr-open-chat", chat_id: chatId });
            return;
        }
        await self.clients.openWindow(chatId ? "./?c=" + encodeURIComponent(chatId) : "./");
    })());
});

function isShellRequest(url) {
    if (url.origin !== self.location.origin) return false;
    const path = url.pathname.replace(/\/+$/, "/");
    if (path === self.registration.scope.replace(self.location.origin, "")) return true;
    return /\.(html|css|js|json|png|svg|mp3|woff2?)$/i.test(url.pathname);
}

self.addEventListener("fetch", (event) => {
    const req = event.request;
    if (req.method !== "GET") return;

    let url;
    try { url = new URL(req.url); } catch (_) { return; }

    // Всё, что уходит к Supabase (сообщения, файлы, вход) — только по сети.
    // Отдать это из кеша значило бы показать вчерашнюю переписку.
    if (url.origin !== self.location.origin) return;
    if (!isShellRequest(url)) return;

    // Страницу берём из сети, но с подстраховкой кешем: так обновления
    // подхватываются сразу, а без интернета сайт всё равно открывается.
    const isPage = req.mode === "navigate" || /\.html$/i.test(url.pathname) ||
                   url.pathname.endsWith("/");

    if (isPage) {
        event.respondWith((async () => {
            try {
                const fresh = await fetch(req);
                const cache = await caches.open(CACHE);
                if (fresh && fresh.ok) cache.put("./index.html", fresh.clone()).catch(() => {});
                return fresh;
            } catch (_) {
                const cache = await caches.open(CACHE);
                return (await cache.match("./index.html")) ||
                       (await cache.match("./")) ||
                       new Response(
                           "<meta charset=utf-8><body style='background:#111b21;color:#e9edef;font:16px system-ui;display:grid;place-items:center;height:100vh;margin:0;text-align:center'>" +
                           "<div><div style='font-size:52px'>📡</div><h2>Центр недоступен</h2>" +
                           "<p style='opacity:.7'>Нет интернета. Откройте страницу снова,<br>когда связь появится.</p></div>",
                           { headers: { "content-type": "text/html; charset=utf-8" } });
            }
        })());
        return;
    }

    // Остальную оболочку — сначала из кеша (мгновенно), обновление в фоне.
    event.respondWith((async () => {
        const cache = await caches.open(CACHE);
        const hit = await cache.match(req, { ignoreSearch: true });
        if (hit) {
            // Обновляем втихую, чтобы в следующий раз была свежая версия.
            fetch(req).then(r => { if (isSaneResponse(url, r)) cache.put(req, r.clone()); }).catch(() => {});
            return hit;
        }
        try {
            const fresh = await fetch(req);
            if (isSaneResponse(url, fresh)) cache.put(req, fresh.clone()).catch(() => {});
            return fresh;
        } catch (e) {
            return new Response("", { status: 504, statusText: "Нет соединения" });
        }
    })());
});
