/* ==========================================================================
 *  ЦЕНТР 3.0 — ДВИЖОК ПРИЛОЖЕНИЯ   (чистый JS + Supabase JS v2)
 *  --------------------------------------------------------------------------
 *  ЧТО ИЗМЕНИЛОСЬ В ЭТОЙ ВЕРСИИ
 *
 *  Скорость (главное):
 *   1. Запуск — ОДИН запрос boot() вместо пяти подряд. Раньше при входе шло
 *      профиль -> чаты -> друзья -> блокировки -> настройки, каждый ждал
 *      предыдущего: на мобильном интернете секунда с лишним пустого экрана.
 *   2. Чат открывается МГНОВЕННО: последние сообщения хранятся на устройстве
 *      (IndexedDB) и рисуются до ответа сервера. Спиннер виден только при
 *      самом первом заходе в чат.
 *   3. Присутствие — один вызов heartbeat() вместо двух таймеров.
 *   4. После удаления или правки сообщения больше не перезагружается весь
 *      список чатов (самый тяжёлый запрос ради одной строки).
 *   5. Появился sw.js: повторный запуск не обращается к хостингу вообще,
 *      работает офлайн, и стала возможна настоящая установка приложения.
 *
 *  Багфиксы этой версии:
 *   6. Ползунок размера шрифта писал в базу на каждое движение.
 *   7. Фото из «Прикрепить» уходили без размеров — дёргалась вёрстка.
 *   8. «Отметить непрочитанным» брало время устройства: на телефоне
 *      с неточными часами курсор улетал в будущее, и чат больше никогда
 *      не показывал непрочитанные. Теперь дату ставит сервер.
 *   9. «В сети» считалось по часам устройства — добавлена поправка.
 *  10. В группах пропадало имя автора в списке чатов после нового сообщения.
 *  11. При выходе сохранённая переписка оставалась на устройстве.
 *
 *  Из версии 2.0 (тоже здесь):
 *   - прочтение курсором, а не флажком в каждом сообщении;
 *   - очередь отправки с повторами и сохранением на диск;
 *   - удаление физическое, без надписи «сообщение удалено»;
 *   - адресный realtime в секретные топики, а не поток всей базы;
 *   - блокировки, архив, закрепление, приватность, антифлуд, темы.
 *
 *  Разделы файла:
 *    0.  Клиент, состояние, константы
 *    1.  Утилиты
 *    1b. Местное хранилище (IndexedDB) — мгновенное открытие
 *    2.  Сеть: обёртка RPC с повторами + индикатор соединения
 *    3.  Звук, вибрация, уведомления, счётчик в заголовке
 *    4.  Оформление: тема, акцент, обои, размер шрифта
 *    5.  Авторизация и восстановление пароля
 *    6.  Профиль, онбординг, настройки, кроппер аватара
 *    7.  Загрузка файлов (сжатие + TUS)
 *    8.  Список чатов
 *    8b. Запуск: один запрос вместо пяти
 *    9.  Активный чат: постраничная лента
 *   10.  Композер и очередь отправки
 *   11.  Фото-редактор и голосовые
 *   12.  Действия над сообщениями
 *   13.  Прочтение и галочки
 *   14.  Присутствие
 *   15.  Друзья и блокировки
 *   16.  Профили, информация о чате
 *   17.  Поиск
 *   18.  Модалки, диплинки
 *   19.  Realtime
 *   20.  Мост для приложения (MAUI)
 *   21.  Звонки (WebRTC)
 *   22.  Запуск
 * ========================================================================== */

/* ------------------------------------------------------------------ *
 *  0. КЛИЕНТ, СОСТОЯНИЕ, КОНСТАНТЫ
 * ------------------------------------------------------------------ */
const CFG = window.CENTR_CONFIG || {};
if (!CFG.SUPABASE_URL || CFG.SUPABASE_URL.includes("ВСТАВЬТЕ")) {
    alert("⚠️ Центр ещё не настроен.\n\nОткройте config.js и вставьте адрес проекта Supabase и ключ anon public.");
}

const sb = window.supabase.createClient(CFG.SUPABASE_URL, CFG.SUPABASE_ANON_KEY, {
    auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true },
    realtime: { params: { eventsPerSecond: 15 } },
    global: { headers: { "x-client-info": "centr-web/3.0" } }
});

const INITIAL_HASH = window.location.hash || "";

const PAGE_SIZE       = 40;      // сообщений за одну подгрузку
const ONLINE_WINDOW   = 75000;   // «в сети», если last_seen свежее 75 с
const PRESENCE_BEAT   = 45000;   // как часто отмечаемся в сети
const POLL_INTERVAL   = 25000;   // резервный опрос, если realtime молчит
const BG_DISCONNECT   = 45000;   // через сколько в фоне отключать realtime
const MAX_TEXT_LEN    = 8000;
const CONN_BAR_DELAY  = 4000;    // сколько терпим обрыв realtime, прежде чем показать баннер

// У таблицы profiles закрыта одна колонка — rt_key (секретный ключ личного
// realtime-топика). Права выданы на остальные колонки по списку, поэтому
// просить у profiles ответ целиком нельзя: пустой .select() в supabase-js
// превращается в select=*, Postgres требует прав на ВСЕ колонки и отвечает
// «permission denied for table profiles» (403), откатывая заодно сам update.
// Свой профиль читаем только через представление my_profile (loadMyProfile),
// чужие — перечисляя колонки явно.

const REACTION_EMOJIS = ["👍", "❤️", "😂", "😮", "😢", "🙏", "🔥", "🎉"];

const EMOJI_CATEGORIES = [
    { icon: "🕘", name: "Частые", emojis: [] },
    { icon: "😀", name: "Смайлы", emojis: ["😀","😁","😂","🤣","😃","😄","😅","😆","😉","😊","😋","😎","😍","😘","🥰","😗","😙","😚","🙂","🙃","🫠","🤗","🤩","🤔","🫡","🤨","😐","😑","😶","🫥","😏","😒","🙄","😬","🤥","😌","😔","😪","🤤","😴","😷","🤒","🤕","🤢","🤮","🤧","🥵","🥶","🥴","😵","🤯","🤠","🥳","🥸","😇","🤓","🧐","😕","🫤","😟","🙁","☹️","😮","😯","😲","😳","🥺","🥹","😦","😧","😨","😰","😥","😢","😭","😱","😖","😣","😞","😓","😩","😫","🥱","😤","😡","😠","🤬","😈","👿","💀","☠️","💩","🤡","👹","👺","👻","👽","🤖","😺","😸","😹","😻","😼","😽","🙀","😿","😾"] },
    { icon: "👍", name: "Жесты", emojis: ["👍","👎","👌","🤌","🤏","✌️","🤞","🫰","🤟","🤘","🤙","👈","👉","👆","👇","☝️","🫵","👋","🤚","🖐️","✋","🖖","🫱","🫲","🫳","🫴","👏","🙌","👐","🤲","🤝","🙏","✍️","💅","🤳","💪","🦵","🦶","👂","🦻","👃","🧠","🫀","🫁","🦷","👀","👁️","👅","👄","🫦"] },
    { icon: "❤️", name: "Сердца", emojis: ["❤️","🧡","💛","💚","💙","💜","🖤","🤍","🤎","💔","❣️","💕","💞","💓","💗","💖","💘","💝","💟","♥️","💌","💋","😍","🥰","😘","💑","💏","🫶"] },
    { icon: "🐶", name: "Животные", emojis: ["🐶","🐱","🐭","🐹","🐰","🦊","🐻","🐼","🐨","🐯","🦁","🐮","🐷","🐽","🐸","🐵","🙈","🙉","🙊","🐒","🐔","🐧","🐦","🐤","🐣","🦆","🦅","🦉","🦇","🐺","🐗","🐴","🦄","🐝","🪲","🐛","🦋","🐌","🐞","🐜","🦗","🕷️","🦂","🐢","🐍","🦎","🦖","🐙","🦑","🦀","🐠","��","🐬","🐳","🐋","🦈","🐊","🐅","🐆","🦓","🦍","🐘","🦛","🐪","🐫","🦒","🐃","🐂","🐄","🐎","🐖","🐏","🐑","🐐","🦌","🐕","🐩","🐈","🐓","🦃","🕊️","🐇","🐿️","🦔"] },
    { icon: "🍔", name: "Еда", emojis: ["���","���","🍐","🍊","🍋","🍌","🍉","🍇","🍓","🫐","🍈","🍒","🍑","🥭","🍍","🥥","🥝","🍅","🍆","🥑","🥦","🥬","🥒","🌶️","🫑","🌽","🥕","🧄","🧅","🥔","🍠","🥐","🥯","🍞","🥖","🧀","🥚","🍳","🧈","🥞","🧇","🥓","🍗","🍖","🌭","🍔","🍟","🍕","🥪","🌮","🌯","🥙","🧆","🥗","🍝","🍜","🍲","🍛","🍣","🍱","🥟","🍤","🍙","🍚","🍘","🍥","🥠","🍢","🍡","🍧","🍨","🍦","🥧","🧁","🍰","🎂","🍮","🍭","🍬","🍫","🍿","🍩","🍪","🌰","🥜","☕","🍵","🧃","🥤","🧋","🍺","🍻","🥂","🍷","🥃","🍸","🍹","🍾"] },
    { icon: "⚽", name: "Активность", emojis: ["⚽","🏀","🏈","⚾","🥎","🎾","🏐","🏉","🥏","🎱","🪀","🏓","🏸","🏒","🏑","🥍","🏏","🥅","⛳","🪁","🏹","🎣","🤿","🥊","🥋","🎽","🛹","🛼","🛷","⛸️","🥌","🎿","⛷️","🏂","🏋️","🤼","🤸","⛹️","🤺","🤾","🏌️","🏇","🧘","🏄","🏊","🤽","🚣","🧗","🚴","🚵","��","🥇","🥈","🥉","🏅","🎖️","🎗️","🎫","🎟️","🎪","🎭","🎨","🎬","🎤","🎧","🎼","🎹","🥁","🎷","🎺","🎸","🪕","🎻","🎲","♟️","🎯","🎳","🎮","🎰"] },
    { icon: "✈️", name: "Места", emojis: ["🚗","🚕","🚙","🚌","🚎","🏎️","🚓","🚑","🚒","🚐","🛻","🚚","🚛","🚜","🛵","🏍️","🛺","🚲","🛴","🚨","🚔","🚍","🚘","🚖","✈️","🛫","🛬","🛩️","🚁","🚀","🛸","⛵","🚤","🛥️","🛳️","⛴️","🚢","⚓","🚏","⛽","🚦","🚥","🗺️","🗿","🗽","🗼","🏰","🏯","🏟️","🎡","🎢","🎠","⛲","⛱️","🏖️","🏝️","🏔️","⛰️","🌋","🗻","🏕️","⛺","🏠","🏡","🏘️","🏙️","🌃","🌉","🌁","🌅","🌄","🌇","🌆","🌊","🏫","🏢","🏬","🏥","🏦"] },
    { icon: "💡", name: "Предметы", emojis: ["⌚","📱","💻","⌨️","🖥️","🖨️","🖱️","💽","💾","💿","📀","📷","📸","📹","🎥","📞","☎️","📟","📠","📺","📻","🧭","⏰","⏱️","⏲️","🕰️","💡","🔦","🕯️","🔋","🔌","🧰","🔧","🔨","🛠️","⚙️","🧲","💣","🧨","🔪","🗡️","🛡️","💊","💉","🩹","🌡️","🔬","🔭","📡","🧴","🧷","🧹","🧺","🧻","🚽","🚿","🛁","🧼","🪒","🔑","🗝️","🚪","🛋️","🛏️","🖼️","🛍️","🎁","🎈","🎀","🎉","🎊","✉️","📩","📨","📧","📦","📚","📖","📝","✏️","🖊️","🖌️","🖍️","📌","📎","🔗","💰","💵","💳","💎","🎓","📐","📏","🧮","📊","📈"] },
    { icon: "🔣", name: "Символы", emojis: ["✅","❌","❎","➕","➖","➗","✖️","♾️","‼️","⁉️","❓","❔","❗","❕","〰️","💱","💲","♻️","⚜️","🔱","📛","🔰","⭕","✔️","☑️","🔘","⚪","⚫","🔴","🟠","🟡","🟢","🔵","🟣","🟤","🔺","🔻","🔸","🔹","🔶","🔷","🔳","🔲","▪️","▫️","◾","◽","◼️","◻️","🟥","🟧","🟨","🟩","🟦","🟪","🟫","⬛","⬜","💯","💢","💥","💫","💦","💨","🕳️","💬","💭","🗯️","♠️","♥️","♦️","♣️","🃏","⭐","🌟","✨","⚡","🔥","🌈","☀️","⛅","☁️","🌙","⏳","⌛"] },
];

const state = {
    user: null,
    profile: null,            // мой профиль (включая rt_key)
    chats: [],                // модель списка чатов (из chat_overview)
    activeChatId: null,
    messages: [],             // сообщения активного чата, по возрастанию времени
    hasMoreOlder: true,       // есть ли что подгружать вверх
    loadingOlder: false,
    profilesCache: {},
    members: {},               // chatId -> участники (для «кто прочитал» и упоминаний)
    reactionsByMsg: {},
    replyTo: null,
    editing: null,
    selection: new Set(),     // выделенные сообщения (multi-select)
    selectMode: false,
    typing: {},               // chatId -> {userId, name, until}
    typingTimers: {},
    searchTerm: "",
    channels: {},
    recorder: null,
    sidebarTab: "chats",
    showArchived: false,
    friends: [], incoming: [], outgoing: [], blocked: [],
    viewProfile: null,
    viewProfileId: null,
    pendingDeepLink: null,
    sharePayload: null,
    pendingShare: null,
    pinned: [],
    pinnedIndex: 0,
    unseenCount: 0,
    soundEnabled: true,
    call: null,
    online: false,            // есть ли связь с сервером
    lastEventAt: 0,           // когда последний раз приходило realtime-событие
    chatsLoaded: false,
    firstUnreadAt: null,      // для полосы «Новые сообщения»
    settings: {},             // app_settings
    clockSkew: 0,             // на сколько врут часы устройства (мс)
    isAdmin: false,
    preloaded: null,          // сообщения, пришедшие вместе с boot()
    recoveryMode: false,
    pendingCallIntent: null,
    autoAcceptPeer: null,
};

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

// Свой номер для каждого исходящего сообщения. По нему сервер узнаёт повтор
// и не создаёт вторую копию. crypto.randomUUID есть не во всех старых
// WebView, поэтому предусмотрена замена.
function newUuid() {
    try { if (crypto && crypto.randomUUID) return crypto.randomUUID(); } catch (_) {}
    const b = new Uint8Array(16);
    try { crypto.getRandomValues(b); }
    catch (_) { for (let i = 0; i < 16; i++) b[i] = Math.floor(Math.random() * 256); }
    b[6] = (b[6] & 0x0f) | 0x40;
    b[8] = (b[8] & 0x3f) | 0x80;
    const h = [...b].map(x => x.toString(16).padStart(2, "0")).join("");
    return `${h.slice(0,8)}-${h.slice(8,12)}-${h.slice(12,16)}-${h.slice(16,20)}-${h.slice(20)}`;
}

/* ------------------------------------------------------------------ *
 *  1. УТИЛИТЫ
 * ------------------------------------------------------------------ */
const $  = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));
const el = (id) => document.getElementById(id);

function show(node) { node && node.classList.remove("hidden"); }
function hide(node) { node && node.classList.add("hidden"); }

function esc(str = "") {
    return String(str)
        .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;").replace(/'/g, "&#39;");
}

// Ссылки делаем кликабельными, упоминания @имя — тоже.
function linkify(text = "") {
    let out = esc(text).replace(/(https?:\/\/[^\s<]+)/g,
        '<a href="$1" target="_blank" rel="noopener noreferrer">$1</a>');
    // Упоминание пре��ращаем в кнопку открытия профиля. Ищем только вне ссылок:
    // после esc() внутри href остаётся текст без пробелов, поэтому требуем
    // границу слова перед @.
    out = out.replace(/(^|[\s(>])@([a-z0-9_]{3,24})\b/gi,
        (all, pre, handle) => `${pre}<span class="mention" data-mention="${esc(handle.toLowerCase())}">@${esc(handle)}</span>`);
    return out;
}

// Упомянули ли меня в этом тексте.
function mentionsMe(text) {
    const h = state.profile && state.profile.handle;
    if (!h || !text) return false;
    return new RegExp("(^|[\\s(])@" + h.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "\\b", "i").test(text);
}

// Сообщение только из эмодзи (до 3 штук) показываем крупно, как в Telegram.
function isJumboEmoji(text) {
    if (!text) return false;
    const t = text.trim();
    if (t.length > 12) return false;
    const noEmoji = t.replace(/[\p{Extended_Pictographic}\u200d\uFE0F\u20E3\s]/gu, "");
    if (noEmoji.length) return false;
    const count = [...t.matchAll(/\p{Extended_Pictographic}/gu)].length;
    return count >= 1 && count <= 3;
}

function initials(name = "?") {
    const parts = String(name).trim().split(/\s+/);
    if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
    return ((parts[0][0] || "") + (parts[parts.length - 1][0] || "")).toUpperCase();
}

// Стабильный цвет аватара по идентификатору — приятнее, чем один серый.
function avatarTint(key = "") {
    const palette = ["#00a884","#5b8def","#e0862c","#c74f6b","#7d5bd6","#2b9fa8","#c9a227","#4d7cc7"];
    let h = 0;
    for (let i = 0; i < key.length; i++) h = (h * 31 + key.charCodeAt(i)) % 100000;
    return palette[h % palette.length];
}

function toast(message, isError = false, ms = 2800) {
    const wrap = el("toast-wrap");
    if (!wrap) return;
    const t = document.createElement("div");
    t.className = "toast" + (isError ? " error" : "");
    t.textContent = message;
    wrap.appendChild(t);
    setTimeout(() => { t.style.opacity = "0"; t.style.transition = "opacity .3s"; }, ms);
    setTimeout(() => t.remove(), ms + 400);
}

function fmtTime(iso) {
    const d = new Date(iso);
    return d.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
}

function fmtDay(iso) {
    const d = new Date(iso);
    const today = new Date();
    const yest = new Date(); yest.setDate(today.getDate() - 1);
    const same = (a, b) => a.toDateString() === b.toDateString();
    if (same(d, today)) return "Сегодня";
    if (same(d, yest)) return "Вчера";
    return d.toLocaleDateString("ru-RU", {
        day: "numeric", month: "long",
        year: d.getFullYear() === today.getFullYear() ? undefined : "numeric"
    });
}

// Короткое время для списка чатов: сегодня — часы, вчера — «Вчера», иначе дата.
function fmtListTime(iso) {
    if (!iso) return "";
    const d = new Date(iso), now = new Date();
    if (d.toDateString() === now.toDateString()) return fmtTime(iso);
    const yest = new Date(now); yest.setDate(now.getDate() - 1);
    if (d.toDateString() === yest.toDateString()) return "Вчера";
    if ((now - d) < 6 * 86400000) return d.toLocaleDateString("ru-RU", { weekday: "short" });
    return d.toLocaleDateString("ru-RU", { day: "2-digit", month: "2-digit" });
}

function fmtLastSeen(iso) {
    if (!iso) return "был(а) недавно";
    const d = new Date(iso);
    const now = new Date();
    const diffMin = Math.round((now - d) / 60000);
    if (diffMin < 1) return "был(а) только что";
    if (diffMin < 60) return `был(а) ${diffMin} мин назад`;
    if (d.toDateString() === now.toDateString()) return `был(а) сегодня в ${fmtTime(iso)}`;
    const yest = new Date(now); yest.setDate(now.getDate() - 1);
    if (d.toDateString() === yest.toDateString()) return `был(а) вчера в ${fmtTime(iso)}`;
    return `был(а) ${d.toLocaleDateString("ru-RU", { day: "numeric", month: "short" })} в ${fmtTime(iso)}`;
}

function fmtDuration(sec) {
    sec = Math.max(0, Math.floor(sec || 0));
    return `${Math.floor(sec / 60)}:${String(sec % 60).padStart(2, "0")}`;
}

function fmtBytes(b) {
    b = Number(b) || 0;
    if (b < 1024) return b + " Б";
    const u = ["КБ", "МБ", "ГБ"]; let i = -1;
    do { b /= 1024; i++; } while (b >= 1024 && i < u.length - 1);
    return b.toFixed(b < 10 ? 1 : 0) + " " + u[i];
}

function pluralRu(n, one, few, many) {
    const m10 = n % 10, m100 = n % 100;
    if (m10 === 1 && m100 !== 11) return one;
    if (m10 >= 2 && m10 <= 4 && (m100 < 10 || m100 >= 20)) return few;
    return many;
}
const pluralMembers = (n) => pluralRu(n, "участник", "участника", "участников");

function clip(str, n = 48) {
    str = String(str || "").replace(/\s+/g, " ").trim();
    return str.length > n ? str.slice(0, n) + "…" : str;
}

function debounce(fn, wait) {
    let t;
    return function (...args) { clearTimeout(t); t = setTimeout(() => fn.apply(this, args), wait); };
}

function throttle(fn, wait) {
    let last = 0, timer = null;
    return function (...args) {
        const now = Date.now();
        if (now - last >= wait) { last = now; fn.apply(this, args); }
        else if (!timer) {
            timer = setTimeout(() => { timer = null; last = Date.now(); fn.apply(this, args); }, wait - (now - last));
        }
    };
}

function paintAvatar(imgEl, fallbackEl, url, name, key) {
    if (!imgEl || !fallbackEl) return;
    if (url) {
        imgEl.src = url;
        imgEl.style.display = "block";
        fallbackEl.style.display = "none";
    } else {
        imgEl.removeAttribute("src");
        imgEl.style.display = "none";
        fallbackEl.style.display = "flex";
        fallbackEl.textContent = initials(name || "?");
        fallbackEl.style.background = avatarTint(key || name || "");
    }
}

function avatarHTML(url, name, cls = "sm", key = "") {
    if (url) return `<span class="avatar ${cls}"><img src="${esc(url)}" alt="" loading="lazy"></span>`;
    return `<span class="avatar ${cls}"><span class="avatar-fallback" style="background:${avatarTint(key || name || "")}">${esc(initials(name || "?"))}</span></span>`;
}

function siteBase() {
    let b = (CFG.SITE_URL && CFG.SITE_URL.trim()) ? CFG.SITE_URL.trim() : location.origin;
    return b.replace(/\/+$/, "");
}
function profileLink(profile) {
    const key = (profile && profile.handle) ? profile.handle : (profile ? profile.id : "");
    return `${siteBase()}/?u=${encodeURIComponent(key)}`;
}
function groupLink(chatId) { return `${siteBase()}/?g=${encodeURIComponent(chatId)}`; }

async function copyText(text, okMsg = "Скопировано") {
    try {
        if (navigator.clipboard && window.isSecureContext) await navigator.clipboard.writeText(text);
        else {
            const ta = document.createElement("textarea");
            ta.value = text; ta.style.position = "fixed"; ta.style.opacity = "0";
            document.body.appendChild(ta); ta.select();
            document.execCommand("copy"); ta.remove();
        }
        toast(okMsg);
    } catch (_) { toast("Не удалось скопировать", true); }
}

function normalizeHandle(raw) { return String(raw || "").trim().replace(/^@+/, "").toLowerCase(); }
function validHandle(h) { return /^[a-z0-9_]{3,24}$/.test(h); }

function vibrate(ms) { try { if (navigator.vibrate) navigator.vibrate(ms); } catch (_) {} }

// Подтверждение действия в аккуратном окне вместо системного confirm().
function confirmBox(title, text, okLabel = "Подтвердить", danger = true) {
    return new Promise((resolve) => {
        const ov = el("confirm-modal");
        el("confirm-title").textContent = title;
        el("confirm-text").textContent = text || "";
        const okBtn = el("confirm-ok");
        okBtn.textContent = okLabel;
        okBtn.className = danger ? "btn-danger" : "btn-primary";
        show(ov);
        const done = (val) => {
            hide(ov);
            okBtn.onclick = null;
            el("confirm-cancel").onclick = null;
            resolve(val);
        };
        okBtn.onclick = () => done(true);
        el("confirm-cancel").onclick = () => done(false);
        ov.onclick = (e) => { if (e.target === ov) done(false); };
    });
}

// Ввод строки в аккуратном окне вместо prompt().
function promptBox(title, value = "", placeholder = "", maxLength = 200) {
    return new Promise((resolve) => {
        const ov = el("prompt-modal");
        el("prompt-title").textContent = title;
        const input = el("prompt-input");
        input.value = value; input.placeholder = placeholder; input.maxLength = maxLength;
        show(ov);
        setTimeout(() => input.focus(), 50);
        const done = (val) => {
            hide(ov);
            el("prompt-ok").onclick = null;
            el("prompt-cancel").onclick = null;
            input.onkeydown = null;
            resolve(val);
        };
        el("prompt-ok").onclick = () => done(input.value.trim());
        el("prompt-cancel").onclick = () => done(null);
        input.onkeydown = (e) => { if (e.key === "Enter") done(input.value.trim()); };
        ov.onclick = (e) => { if (e.target === ov) done(null); };
    });
}

/* ------------------------------------------------------------------ *
 *  1b. МЕСТНОЕ ХРАНИЛИЩЕ (IndexedDB): МГНОВЕННОЕ ОТКРЫТИЕ
 *      Раньше при открытии чата показывался спиннер, и лента появлялась
 *      только после ответа сервера — на мобильном интернете это полсекунды
 *      и больше пустого экрана, а на плохой связи и все пять.
 *      Теперь последние сообщения каждого чата лежат на устройстве:
 *      чат рисуется СРАЗУ, а свежее подтягивается уже поверх.
 *      Так же работают Telegram и WhatsApp.
 *
 *      localStorage для этого не годится: он синхронный (подвешивает
 *      интерфейс) и ограничен ~5 МБ. IndexedDB асинхронный и вмещает
 *      десятки мегабайт.
 * ------------------------------------------------------------------ */
const CACHE_PER_CHAT = 60;      // сколько сообщений держим на устройстве
const CACHE_MAX_CHATS = 40;     // и для скольких чатов

const idb = (() => {
    let dbp = null;

    function open() {
        if (dbp) return dbp;
        dbp = new Promise((resolve) => {
            if (!window.indexedDB) { resolve(null); return; }
            let req;
            try { req = indexedDB.open("centr", 1); } catch (_) { resolve(null); return; }
            req.onupgradeneeded = () => {
                const db = req.result;
                if (!db.objectStoreNames.contains("kv")) db.createObjectStore("kv");
                if (!db.objectStoreNames.contains("msgs")) db.createObjectStore("msgs");
            };
            req.onsuccess = () => resolve(req.result);
            req.onerror = () => resolve(null);
            // В приватном режиме Safari IndexedDB иногда просто не отвечает.
            setTimeout(() => resolve(null), 2500);
        });
        return dbp;
    }

    function tx(store, mode, fn) {
        return open().then(db => {
            if (!db) return null;
            return new Promise((resolve) => {
                let t;
                try { t = db.transaction(store, mode); } catch (_) { resolve(null); return; }
                const req = fn(t.objectStore(store));
                if (req) { req.onsuccess = () => resolve(req.result); req.onerror = () => resolve(null); }
                else { t.oncomplete = () => resolve(true); t.onerror = () => resolve(null); }
            });
        }).catch(() => null);
    }

    return {
        get:  (store, key)        => tx(store, "readonly",  s => s.get(key)),
        set:  (store, key, value) => tx(store, "readwrite", s => { s.put(value, key); return null; }),
        del:  (store, key)        => tx(store, "readwrite", s => { s.delete(key); return null; }),
        keys: (store)             => tx(store, "readonly",  s => s.getAllKeys()),
        clear:(store)             => tx(store, "readwrite", s => { s.clear(); return null; }),
    };
})();

// Ключи разделяем по пользователю: на общем компьютере чужая переписка
// не должна всплыть у следующего вошедшего.
function cacheNS() { return state.user ? state.user.id : "anon"; }

async function cacheSaveChats(list) {
    try { await idb.set("kv", "chats:" + cacheNS(), (list || []).slice(0, 80)); } catch (_) {}
}
async function cacheLoadChats() {
    try { return (await idb.get("kv", "chats:" + cacheNS())) || null; } catch (_) { return null; }
}

async function cacheSaveMessages(chatId, list) {
    if (!chatId || !list) return;
    try {
        const clean = list
            .filter(m => m && !m._pending && !m._failed && !String(m.id).startsWith("temp_"))
            .slice(-CACHE_PER_CHAT);
        await idb.set("msgs", cacheNS() + ":" + chatId, clean);
        await cachePrune();
    } catch (_) {}
}
async function cacheLoadMessages(chatId) {
    if (!chatId) return null;
    try { return (await idb.get("msgs", cacheNS() + ":" + chatId)) || null; } catch (_) { return null; }
}

// Держим кеш в разумных пределах: лишние чаты выкидываем.
let __pruneAt = 0;
async function cachePrune() {
    if (Date.now() - __pruneAt < 60000) return;
    __pruneAt = Date.now();
    try {
        const keys = (await idb.keys("msgs")) || [];
        const mine = keys.filter(k => String(k).startsWith(cacheNS() + ":"));
        if (mine.length <= CACHE_MAX_CHATS) return;
        // Оставляем те чаты, что выше в списке — они нужнее.
        const keep = new Set(state.chats.slice(0, CACHE_MAX_CHATS).map(c => cacheNS() + ":" + c.chat_id));
        for (const k of mine) if (!keep.has(k)) await idb.del("msgs", k);
    } catch (_) {}
}

async function cacheWipe() {
    try { await idb.clear("kv"); await idb.clear("msgs"); } catch (_) {}
}

/* ------------------------------------------------------------------ *
 *  2. СЕТЬ: ОБЁРТКА RPC С ПОВТОРАМИ + ИНДИКАТОР СОЕДИНЕНИЯ
 *     Любая операция сама переживает короткий обрыв связи, а пользователь
 *     видит понятную причину, а не «что-то пошло не так».
 * ------------------------------------------------------------------ */
let connBarTimer = null;

function setConnState(ok, label) {
    state.online = ok;
    const bar = el("conn-bar");
    if (!bar) return;
    clearTimeout(connBarTimer);
    connBarTimer = null;
    if (ok) { hide(bar); return; }
    const text = label || "Нет соединения — переподключаемся…";
    // Понятную причину (нет интернета, сообщение не ушло) показываем сразу.
    if (label) { bar.textContent = text; show(bar); return; }
    // А вот обрыв realtime почти всегда лечится сам за секунду-две.
    // Раньше баннер успевал мигнуть на каждом таком случае — теперь
    // он появляется, только если связь не вернулась за CONN_BAR_DELAY.
    connBarTimer = setTimeout(() => { bar.textContent = text; show(bar); }, CONN_BAR_DELAY);
}

// Человеческий текст ошибки Postgres/сети.
function errRu(err) {
    const msg = String(err && (err.message || err.error_description || err) || "");
    const low = msg.toLowerCase();
    if (msg.includes("CENTR_RATE_LIMIT")) return "Слишком быстро — подождите пару секунд.";
    if (msg.includes("CENTR_BLOCKED"))    return "Переписка недоступна: пользователь заблокирован.";
    if (msg.includes("CENTR_ONLY_FRIENDS")) return "Пользователь принимает сообщения только от друзей.";
    if (msg.includes("CENTR_FORBIDDEN"))  return "Недостаточно прав для этого действия.";
    if (msg.includes("CENTR_NOT_FOUND"))  return "Не найдено.";
    if (msg.includes("CENTR_EMPTY"))      return "Пустое сообщение отправить нельзя.";
    if (msg.includes("CENTR_SELF"))       return "Это действие нельзя применить к себе.";
    if (msg.includes("CENTR_AUTH"))       return "Сессия истекла — войдите заново.";
    if (msg.includes("CENTR_SIGNUP_CLOSED")) return "Регистрация закрыта администратором.";
    if (low.includes("statement timeout") || low.includes("57014")) return "Сервер долго отвечает. Попробуйте ещё раз.";
    if (low.includes("failed to fetch") || low.includes("network") || low.includes("load failed"))
        return "Нет связи с сервером. Проверьте интернет.";
    if (low.includes("jwt") || low.includes("token")) return "Сессия истекла — войдите заново.";
    if (low.includes("duplicate key")) return "Такая запись уже есть.";
    if (low.includes("row-level security")) return "Действие запрещено правами доступа.";
    return msg || "Не удалось выполнить действие.";
}

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

// Вызов функции базы с 3 попытками при сетевых сбоях.
async function rpc(name, params, opts = {}) {
    const tries = opts.tries || 3;
    let lastErr = null;
    for (let i = 0; i < tries; i++) {
        try {
            const { data, error } = await sb.rpc(name, params || {});
            if (error) throw error;
            setConnState(true);
            return data;
        } catch (e) {
            lastErr = e;
            const msg = String(e && e.message || "").toLowerCase();
            const retriable = msg.includes("fetch") || msg.includes("network") ||
                              msg.includes("timeout") || msg.includes("load failed") ||
                              msg.includes("502") || msg.includes("503") || msg.includes("504");
            if (!retriable || i === tries - 1) break;
            setConnState(false);
            await sleep(400 * Math.pow(2, i));
        }
    }
    throw lastErr;
}

// То же для обычных запросов к таблицам: query() принимает функцию-построитель.
async function query(builder, opts = {}) {
    const tries = opts.tries || 3;
    let lastErr = null;
    for (let i = 0; i < tries; i++) {
        try {
            const { data, error } = await builder();
            if (error) throw error;
            setConnState(true);
            return data;
        } catch (e) {
            lastErr = e;
            const msg = String(e && e.message || "").toLowerCase();
            if (!(msg.includes("fetch") || msg.includes("network") || msg.includes("load failed")) || i === tries - 1) break;
            setConnState(false);
            await sleep(400 * Math.pow(2, i));
        }
    }
    throw lastErr;
}

/* ------------------------------------------------------------------ *
 *  3. ЗВУК, ВИБРАЦИЯ, УВЕДОМЛЕНИЯ, СЧЁТЧИК В ЗАГОЛОВКЕ
 * ------------------------------------------------------------------ */
let audioCtx = null;
let lastSoundAt = 0;

function unlockAudio() {
    try {
        if (!audioCtx) {
            const AC = window.AudioContext || window.webkitAudioContext;
            if (!AC) return;
            audioCtx = new AC();
        }
        if (audioCtx.state === "suspended") audioCtx.resume();
    } catch (_) {}
}

function playTone(notes, volume = 0.2) {
    try {
        unlockAudio();
        if (!audioCtx) return;
        const t0 = audioCtx.currentTime;
        notes.forEach(([off, freq]) => {
            const o = audioCtx.createOscillator();
            const g = audioCtx.createGain();
            o.type = "sine"; o.frequency.value = freq;
            const s = t0 + off;
            g.gain.setValueAtTime(0.0001, s);
            g.gain.exponentialRampToValueAtTime(volume, s + 0.02);
            g.gain.exponentialRampToValueAtTime(0.0001, s + 0.22);
            o.connect(g); g.connect(audioCtx.destination);
            o.start(s); o.stop(s + 0.24);
        });
    } catch (_) {}
}

const playNotifySound = () => { if (state.soundEnabled) playTone([[0, 784], [0.11, 1047]]); };
const playSentSound   = () => { if (state.soundEnabled) playTone([[0, 1180]], 0.07); };

// Реакция на входящее: звук, вибрация и, если разрешено, системное уведомление.
function notifyIncoming(msg, chatEntry) {
    // Если чат заглушён, но в сообщении есть упоминание — уведомить всё равно
    // надо: иначе смысл упоминаний в больших группах теряется.
    const forMe = msg && mentionsMe(msg.text);
    if (chatEntry && chatEntry.is_muted && !forMe) return;
    const now = Date.now();
    if (state.soundEnabled && now - lastSoundAt > 700) { lastSoundAt = now; playNotifySound(); }
    if (document.visibilityState === "hidden") {
        vibrate(120);
        showBrowserNotification(msg, chatEntry);
    }
}

async function showBrowserNotification(msg, chatEntry) {
    try {
        if (!("Notification" in window) || Notification.permission !== "granted") return;
        if (window.__CENTR_NATIVE__) return;   // в приложении уведомления рисует оболочка
        const title = chatEntry ? chatTitleOf(chatEntry) : "Центр";
        const body = msg ? snippetForMessage(msg) : "Новое сообщение";
        const chatId = (msg && msg.chat_id) || "";
        const opts = {
            body, icon: "icon-192.png", badge: "icon-192.png",
            tag: "centr-" + chatId, renotify: true, data: { chat_id: chatId }
        };
        // На Android конструктор new Notification() запрещён — там уведомление
        // обязан показать service worker. Именно поэтому на телефоне ничего
        // не приходило. Пробуем через него, и только если его нет — напрямую.
        const reg = ("serviceWorker" in navigator)
            ? await navigator.serviceWorker.getRegistration().catch(() => null) : null;
        if (reg && reg.showNotification) { await reg.showNotification(title, opts); return; }
        const n = new Notification(title, opts);
        n.onclick = () => { window.focus(); if (chatId) openChat(chatId); n.close(); };
    } catch (_) {}
}

async function askNotificationPermission() {
    try {
        if (!("Notification" in window) || window.__CENTR_NATIVE__) return;
        if (Notification.permission === "default") await Notification.requestPermission();
        if (Notification.permission === "granted") await ensureWebPush();
    } catch (_) {}
}

/* ---- Уведомления, когда сайт/приложение закрыто (Web Push) ---- *
 *  Открытое окно уведомляет само (showBrowserNotification), но когда
 *  приложение закрыто, сообщение доставляет пуш-служба браузера.
 *  Подписку (endpoint + ключи) храним в device_tokens с platform="web";
 *  оттуда её берёт функция push-on-message. Без VAPID_PUBLIC_KEY в config.js
 *  подписаться невозможно — тихо выходим, остальное работает как раньше.  */
let webPushToken = null;

function urlBase64ToUint8Array(base64) {
    const pad = "=".repeat((4 - base64.length % 4) % 4);
    const raw = atob((base64 + pad).replace(/-/g, "+").replace(/_/g, "/"));
    const out = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; i++) out[i] = raw.charCodeAt(i);
    return out;
}

// Если ключ сервера сменился, старая подписка больше не работает — её надо пересоздать.
function samePushKey(sub, keyB64) {
    try {
        const cur = sub.options && sub.options.applicationServerKey;
        if (!cur) return true;
        const a = new Uint8Array(cur), b = urlBase64ToUint8Array(keyB64);
        if (a.length !== b.length) return false;
        for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
        return true;
    } catch (_) { return true; }
}

async function ensureWebPush() {
    try {
        if (window.__CENTR_NATIVE__) return;                 // в приложении пуши через FCM
        if (!("serviceWorker" in navigator) || !("PushManager" in window)) return;
        const key = String(CFG.VAPID_PUBLIC_KEY || "").trim();
        if (!key || key.startsWith("ВСТАВЬТЕ")) return;
        const reg = await navigator.serviceWorker.ready;
        let sub = await reg.pushManager.getSubscription();
        if (sub && !samePushKey(sub, key)) { try { await sub.unsubscribe(); } catch (_) {} sub = null; }
        if (!sub) {
            sub = await reg.pushManager.subscribe({
                userVisibleOnly: true,
                applicationServerKey: urlBase64ToUint8Array(key)
            });
        }
        webPushToken = JSON.stringify(sub);
        await saveDeviceToken(webPushToken, "web");
    } catch (e) { console.warn("web push", e && e.message); }
}

// При выходе из аккаунта подписку убираем: иначе на чужом
// устройстве продолжали бы приходить уведомления вышедшего пользователя.
async function dropWebPush() {
    try {
        if (!("serviceWorker" in navigator)) return;
        const reg = await navigator.serviceWorker.getRegistration();
        const sub = reg && await reg.pushManager.getSubscription();
        const token = webPushToken || (sub ? JSON.stringify(sub) : null);
        if (token) { try { await sb.from("device_tokens").delete().eq("token", token); } catch (_) {} }
        if (sub) { try { await sub.unsubscribe(); } catch (_) {} }
    } catch (_) {}
    webPushToken = null;
}

function updateSoundBtn() {
    const btn = el("sound-toggle");
    if (!btn) return;
    btn.innerHTML = state.soundEnabled
        ? `<svg viewBox="0 0 24 24"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3A4.5 4.5 0 0014 7.97v8.05A4.5 4.5 0 0016.5 12zM14 3.23v2.06a7 7 0 010 13.42v2.06a9 9 0 000-17.54z"/></svg>`
        : `<svg viewBox="0 0 24 24"><path d="M3 9v6h4l5 5V4L7 9H3zm18.19 8.19L4.81 .81 3.4 2.22l4.78 4.78L7 8H3v6h4l5 5v-6.61l4.78 4.78 1.41-1.41z" opacity=".55"/></svg>`;
    btn.title = state.soundEnabled ? "Звук уведомлений: вкл." : "Звук уведомлений: выкл.";
    btn.style.opacity = state.soundEnabled ? "1" : ".45";
}

function setupSound() {
    state.soundEnabled = localStorage.getItem("centr_sound") !== "0";
    updateSoundBtn();
    const btn = el("sound-toggle");
    if (btn) btn.addEventListener("click", () => {
        state.soundEnabled = !state.soundEnabled;
        localStorage.setItem("centr_sound", state.soundEnabled ? "1" : "0");
        updateSoundBtn();
        if (state.soundEnabled) { unlockAudio(); playNotifySound(); toast("Звук включён"); }
        else toast("Звук выключен");
    });
    const unlock = () => { unlockAudio(); document.removeEventListener("click", unlock); document.removeEventListener("keydown", unlock); };
    document.addEventListener("click", unlock);
    document.addEventListener("keydown", unlock);
}

// Общее число непрочитанных — в заголовок страницы и на иконку приложения.
function updateGlobalBadge() {
    const total = state.chats.reduce((s, c) => s + (c.is_muted ? 0 : (c.unread || 0)), 0);
    document.title = total > 0 ? `(${total}) Центр` : "Центр — Мессенджер";
    try {
        if (navigator.setAppBadge) { total > 0 ? navigator.setAppBadge(total) : navigator.clearAppBadge(); }
    } catch (_) {}
    const tab = el("tab-badge-chats");
    if (tab) {
        tab.textContent = String(total);
        tab.classList.toggle("hidden", total === 0);
    }
}

function resetScrollBadge() {
    state.unseenCount = 0;
    const b = el("scroll-bottom-badge");
    if (b) { b.textContent = "0"; hide(b); }
}
function bumpScrollBadge() {
    state.unseenCount = (state.unseenCount || 0) + 1;
    const b = el("scroll-bottom-badge");
    if (b) { b.textContent = String(state.unseenCount); show(b); }
    show(el("scroll-bottom"));
}

/* ------------------------------------------------------------------ *
 *  4. ОФОРМЛЕНИЕ: ТЕМА, АКЦЕНТ, ОБОИ, РАЗМЕР ШРИФТА
 *     Настройки хранятся и л��кально (мгновенно), и в профиле
 *     (переезжают на другое устройство).
 * ------------------------------------------------------------------ */
const THEMES  = [
    { id: "auto",     name: "Как в системе" },
    { id: "dark",     name: "Тёмная" },
    { id: "midnight", name: "Полночь" },
    { id: "light",    name: "Светлая" },
];

// «Как в системе» — это не отдельное оформление, а выбор между тёмным
// и светлым по настройкам телефона или компьютера.
function systemTheme() {
    try {
        return (window.matchMedia && window.matchMedia("(prefers-color-scheme: light)").matches)
            ? "light" : "dark";
    } catch (_) { return "dark"; }
}
const ACCENTS = [
    { id: "green",  name: "Изумруд",  color: "#00a884" },
    { id: "blue",   name: "Океан",    color: "#3b82f6" },
    { id: "violet", name: "Аметист",  color: "#8b5cf6" },
    { id: "orange", name: "Янтарь",   color: "#f97316" },
    { id: "rose",   name: "Роза",     color: "#f43f5e" },
];
const WALLPAPERS = [
    { id: "",        name: "Нет" },
    { id: "dots",    name: "Точки" },
    { id: "grid",    name: "Сетка" },
    { id: "waves",   name: "Волны" },
    { id: "aurora",  name: "Сияние" },
];

function applyAppearance(a = {}) {
    const root = document.documentElement;
    const theme  = a.theme  || localStorage.getItem("centr_theme")  || "dark";
    const accent = a.accent || localStorage.getItem("centr_accent") || "green";
    const wall   = a.wallpaper !== undefined ? a.wallpaper : (localStorage.getItem("centr_wall") || "");
    const fsize  = a.fontSize || parseInt(localStorage.getItem("centr_fsize") || "15", 10);

    root.setAttribute("data-theme", theme === "auto" ? systemTheme() : theme);
    root.setAttribute("data-accent", accent);
    root.setAttribute("data-wallpaper", wall || "");
    root.style.setProperty("--msg-font-size", fsize + "px");

    localStorage.setItem("centr_theme", theme);
    localStorage.setItem("centr_accent", accent);
    localStorage.setItem("centr_wall", wall || "");
    localStorage.setItem("centr_fsize", String(fsize));

    const meta = document.querySelector('meta[name="theme-color"]');
    const effective = theme === "auto" ? systemTheme() : theme;
    if (meta) meta.setAttribute("content", effective === "light" ? "#f0f2f5" : "#111b21");
}

// Если выбрано «как в системе» — переключаемся вместе с системой, на ходу.
function watchSystemTheme() {
    try {
        const mq = window.matchMedia("(prefers-color-scheme: light)");
        const onChange = () => {
            if ((localStorage.getItem("centr_theme") || "dark") === "auto") applyAppearance({});
        };
        if (mq.addEventListener) mq.addEventListener("change", onChange);
        else if (mq.addListener) mq.addListener(onChange);
    } catch (_) {}
}

async function saveAppearance(patch) {
    applyAppearance(patch);
    if (!state.user) return;
    const row = {};
    if (patch.theme)     row.ui_theme = patch.theme;
    if (patch.accent)    row.ui_accent = patch.accent;
    if (patch.wallpaper !== undefined) row.ui_wallpaper = patch.wallpaper || null;
    if (patch.fontSize)  row.ui_font_size = patch.fontSize;
    if (!Object.keys(row).length) return;
    try { await sb.from("profiles").update(row).eq("id", state.user.id); } catch (_) {}
}

/* ------------------------------------------------------------------ *
 *  5. АВТОРИЗАЦИЯ
 * ------------------------------------------------------------------ */
function authErrorRu(err) {
    const code = String(err && (err.code || err.error_code || "")).toLowerCase();
    const msg = String(err && err.message ? err.message : err || "").toLowerCase();
    const has = (s) => msg.includes(s);

    if (code === "invalid_credentials" || has("invalid login credentials"))
        return "Неверная почта или пароль.";
    if (code === "email_not_confirmed" || has("email not confirmed"))
        return "��очта не подтверждена. Откройте письмо от Центра и подтвердите адрес.";
    if (code === "user_already_exists" || has("already registered") || (has("already") && has("exist")))
        return "Аккаунт с такой почтой уже есть. Перейдите на вкладку «Вход».";
    if (code === "weak_password" || (has("password") && has("least")))
        return "Пароль слишком короткий — минимум 6 символов.";
    if (code === "over_email_send_rate_limit" || has("rate limit") || has("for security purposes") || has("too many requests"))
        return "Слишком много попыток. Подождите минуту и попробуйте снова.";
    if (has("unable to validate email") || (has("email") && has("invalid")))
        return "Неверный формат адреса почты.";
    if (has("signup is disabled") || has("signups not allowed") || has("centr_signup_closed"))
        return "Регистрация закрыта. Попросите администратора открыть её.";
    if (has("failed to fetch") || has("network") || has("load failed"))
        return "Нет соединения с сервером. Проверьте интернет и попробуйте снова.";
    return (err && err.message) ? err.message : "Что-то пошло не так. Попробуйте ещё раз.";
}

function switchAuthTab(which) {
    $$(".auth-tab").forEach(b => b.classList.toggle("active", b.dataset.authtab === which));
    el("login-form").classList.toggle("hidden", which !== "login");
    el("signup-form").classList.toggle("hidden", which !== "signup");
    hide(el("auth-error"));
}

function showAuthError(msg) {
    const box = el("auth-error");
    box.textContent = msg;
    show(box);
}

async function handleSignup(e) {
    e.preventDefault();
    const username = el("signup-username").value.trim();
    const email    = el("signup-email").value.trim();
    const password = el("signup-password").value;
    hide(el("auth-error"));
    const btn = e.target.querySelector("button[type=submit]");
    btn.disabled = true; btn.textContent = "Создаём…";
    try {
        const { data, error } = await sb.auth.signUp({
            email, password,
            options: { data: { username }, emailRedirectTo: siteBase() }
        });
        if (error) throw error;
        if (!data.session) {
            toast("Проверьте почту и подтвердите аккаунт, затем войдите.", false, 5000);
            switchAuthTab("login");
        }
    } catch (err) {
        showAuthError(authErrorRu(err));
    } finally {
        btn.disabled = false; btn.textContent = "Создать аккаунт";
    }
}

async function handleLogin(e) {
    e.preventDefault();
    const email    = el("login-email").value.trim();
    const password = el("login-password").value;
    hide(el("auth-error"));
    const btn = e.target.querySelector("button[type=submit]");
    btn.disabled = true; btn.textContent = "Входим…";
    try {
        const { error } = await sb.auth.signInWithPassword({ email, password });
        if (error) throw error;
    } catch (err) {
        showAuthError(authErrorRu(err));
    } finally {
        btn.disabled = false; btn.textContent = "Войти";
    }
}

async function handleLogout() {
    const ok = await confirmBox("Выйти из аккаунта?", "Черновики и настройки сохранятся на сервере.", "Выйти");
    if (!ok) return;
    try { await flushDrafts(); } catch (_) {}
    teardownRealtime();
    // Локальный кеш чистим, чтобы на общем компьютере ничего не осталось.
    Object.keys(localStorage).forEach(k => {
        if (k.startsWith("centr_chats_") || k.startsWith("centr_queue_")) localStorage.removeItem(k);
    });
    await cacheWipe();   // и сохранённую на устройстве переписку тоже
    await markOffline();  // иначе собеседники ещё минуту видят «в сети»
    await dropWebPush();  // и пуши этому устройству больше не нужны
    await sb.auth.signOut();
    location.href = siteBase();
}

/* ---- Восстановление / смена пароля и почты ---- */
function showRecoveryError(msg) { const b = el("recovery-error"); b.textContent = msg; show(b); }

function showRecoveryScreen() {
    hide(el("splash")); hide(el("auth-screen")); hide(el("onboarding-screen")); hide(el("messenger"));
    show(el("recovery-screen"));
}

function setupAccountSecurity() {
    const on = (id, evt, fn) => { const n = el(id); if (n) n.addEventListener(evt, fn); };

    on("forgot-password-link", "click", () => {
        el("forgot-email").value = el("login-email").value.trim();
        hide(el("auth-error"));
        openModal("forgot-modal");
    });

    on("forgot-send", "click", async () => {
        const btn = el("forgot-send");
        const email = el("forgot-email").value.trim();
        if (!email) { toast("Введите почту", true); return; }
        btn.disabled = true; btn.textContent = "Отправляем…";
        try {
            const { error } = await sb.auth.resetPasswordForEmail(email, { redirectTo: siteBase() });
            if (error) throw error;
            closeModal("forgot-modal");
            toast("Письмо со ссылкой отправлено. Проверьте почту.", false, 4500);
        } catch (err) { toast(authErrorRu(err), true); }
        finally { btn.disabled = false; btn.textContent = "Отправить ссылку"; }
    });

    on("change-password-btn", "click", async () => {
        const btn = el("change-password-btn");
        const email = state.user?.email;
        if (!email) { toast("Не удалось определить почту", true); return; }
        btn.disabled = true; btn.textContent = "Отправляем…";
        try {
            const { error } = await sb.auth.resetPasswordForEmail(email, { redirectTo: siteBase() });
            if (error) throw error;
            toast("Ссылка для смены пароля отправлена на вашу почту.", false, 4500);
        } catch (err) { toast(authErrorRu(err), true); }
        finally { btn.disabled = false; btn.textContent = "Сменить пароль"; }
    });

    on("change-email-btn", "click", () => { el("new-email").value = ""; openModal("email-modal"); });
    on("email-send", "click", async () => {
        const btn = el("email-send");
        const newEmail = el("new-email").value.trim();
        if (!newEmail) { toast("Введите новую почту", true); return; }
        btn.disabled = true; btn.textContent = "Отправляем…";
        try {
            const { error } = await sb.auth.updateUser({ email: newEmail }, { emailRedirectTo: siteBase() });
            if (error) throw error;
            closeModal("email-modal");
            toast("Письмо отправлено на новый адрес. Подтвердите его.", false, 4500);
        } catch (err) { toast(authErrorRu(err), true); }
        finally { btn.disabled = false; btn.textContent = "Отправить подтверждение"; }
    });

    on("recovery-form", "submit", async (e) => {
        e.preventDefault();
        hide(el("recovery-error"));
        const p1 = el("recovery-password").value;
        const p2 = el("recovery-password2").value;
        if (p1.length < 6) { showRecoveryError("Пароль слишком короткий — минимум 6 символов."); return; }
        if (p1 !== p2) { showRecoveryError("Пароли не совпадают."); return; }
        const btn = e.target.querySelector("button[type=submit]");
        btn.disabled = true; btn.textContent = "Сохраняем…";
        try {
            const { error } = await sb.auth.updateUser({ password: p1 });
            if (error) throw error;
            state.recoveryMode = false;
            toast("Пароль обновлён.");
            setTimeout(() => { location.href = siteBase() + "/"; }, 700);
            return;
        } catch (err) { showRecoveryError(authErrorRu(err)); }
        finally { btn.disabled = false; btn.textContent = "Сохранить пароль"; }
    });

    // Удаление аккаунта: чистим данные и выходим (запись в auth.users удаляет
    // администратор — об этом сказано в подсказке).
    on("delete-account-btn", "click", async () => {
        const ok = await confirmBox("Удалить аккаунт?",
            "Все ваши сообщения, чаты и профиль будут удалены безвозвратно.", "Удалить всё");
        if (!ok) return;
        const again = await promptBox("Для подтверждения введите слово УДАЛИТЬ", "", "УДАЛИТЬ");
        if (String(again || "").toUpperCase() !== "УДАЛИТЬ") { toast("Отменено"); return; }
        try {
            await rpc("delete_my_account");
            toast("Аккаунт удалён.");
            setTimeout(() => handleLogoutForce(), 1200);
        } catch (err) { toast(errRu(err), true); }
    });
}

async function handleLogoutForce() {
    teardownRealtime();
    await markOffline();
    await dropWebPush();
    await sb.auth.signOut();
    location.href = siteBase();
}

/* ------------------------------------------------------------------ *
 *  6. ПРОФИЛЬ, ОНБОРДИНГ, НАСТРОЙКИ
 * ------------------------------------------------------------------ */
async function loadMyProfile() {
    // Читаем через представление my_profile — только оно отдаёт секретный rt_key.
    try {
        const data = await query(() => sb.from("my_profile").select("*").maybeSingle());
        if (data) {
            state.profile = data;
            state.profilesCache[data.id] = data;
            applyAppearance({
                theme: data.ui_theme, accent: data.ui_accent,
                wallpaper: data.ui_wallpaper || "", fontSize: data.ui_font_size
            });
            return data;
        }
    } catch (e) { console.error("loadMyProfile", e); }
    return null;
}

let onboardAvatarFile = null;
function setupOnboardingAvatarPreview() {
    el("onboard-avatar-input").addEventListener("change", async (e) => {
        const file = e.target.files[0];
        e.target.value = "";
        if (!file) return;
        const cropped = await openCropper(file);
        if (!cropped) return;
        onboardAvatarFile = cropped;
        el("onboard-avatar-preview").innerHTML = `<img src="${URL.createObjectURL(cropped)}" alt="">`;
    });
}

async function handleOnboarding(e) {
    e.preventDefault();
    const username = el("onboard-username").value.trim();
    const status   = el("onboard-status").value.trim() || "Привет! Я в Центре.";
    const btn = e.target.querySelector("button[type=submit]");
    btn.disabled = true; btn.textContent = "Сохраняем…";
    hide(el("onboard-error"));
    try {
        let avatar_url = state.profile?.avatar_url || null;
        if (onboardAvatarFile) avatar_url = await uploadToBucket(CFG.AVATAR_BUCKET, onboardAvatarFile, "avatar");
        const { error } = await sb.from("profiles")
            .update({ username, status_text: status, avatar_url })
            .eq("id", state.user.id);
        if (error) throw error;
        // Ответ у profiles не запрашиваем (см. комментарий у констант) —
        // перечитываем свой профиль через my_profile.
        await loadMyProfile();
        localStorage.setItem("centr_onboarded_" + state.user.id, "1");
        enterMessenger();
    } catch (err) {
        const box = el("onboard-error");
        box.textContent = errRu(err);
        show(box);
    } finally {
        btn.disabled = false; btn.textContent = "Начать общение";
    }
}

function paintMyAvatar() {
    paintAvatar(el("my-avatar-img"), el("my-avatar-fallback"),
        state.profile?.avatar_url, state.profile?.username, state.profile?.id);
}

let __ringtonePreviewAudio = null;
function playRingtonePreview(id) {
    try {
        if (__ringtonePreviewAudio) { __ringtonePreviewAudio.pause(); __ringtonePreviewAudio = null; }
        __ringtonePreviewAudio = new Audio("sounds/" + (id || "center") + ".mp3");
        __ringtonePreviewAudio.play().catch(function () {});
    } catch (_) {}
}

/* ---- Модалка профиля и настроек ---- */
let profileAvatarFile = null;

function openProfileModal() {
    profileAvatarFile = null;
    el("profile-username").value = state.profile?.username || "";
    el("profile-handle").value = state.profile?.handle || "";
    el("profile-status").value = state.profile?.status_text || "";
    el("profile-link").value = profileLink(state.profile);
    el("profile-email").value = state.user?.email || "";
    if (el("profile-ringtone")) el("profile-ringtone").value = state.profile?.ringtone || "center";
    if (el("privacy-lastseen")) el("privacy-lastseen").value = state.profile?.privacy_last_seen || "everyone";
    if (el("privacy-messages")) el("privacy-messages").value = state.profile?.privacy_messages || "everyone";

    const prev = el("profile-avatar-preview");
    prev.innerHTML = state.profile?.avatar_url
        ? `<img src="${esc(state.profile.avatar_url)}" alt="">`
        : `<span class="avatar-upload-plus">📷</span>`;

    renderAppearanceControls();
    switchSettingsTab("account");
    openModal("profile-modal");
}

function renderAppearanceControls() {
    const themeBox = el("theme-choices");
    if (themeBox) {
        // Отмечаем именно ВЫБРАННОЕ, а не вычисленное: при «как в системе»
        // на <html> стоит dark или light, и галочка встала бы не туда.
        const cur = localStorage.getItem("centr_theme") || "dark";
        themeBox.innerHTML = THEMES.map(t =>
            `<button type="button" class="choice${t.id === cur ? " active" : ""}" data-theme-pick="${t.id}">
                <span class="choice-preview theme-${t.id === "auto" ? "auto" : t.id}"></span>${esc(t.name)}
             </button>`).join("");
        themeBox.querySelectorAll("[data-theme-pick]").forEach(b => b.addEventListener("click", () => {
            saveAppearance({ theme: b.dataset.themePick });
            renderAppearanceControls();
        }));
    }
    const accBox = el("accent-choices");
    if (accBox) {
        const cur = document.documentElement.getAttribute("data-accent");
        accBox.innerHTML = ACCENTS.map(a =>
            `<button type="button" class="swatch${a.id === cur ? " active" : ""}" title="${esc(a.name)}"
                     style="background:${a.color}" data-accent-pick="${a.id}"></button>`).join("");
        accBox.querySelectorAll("[data-accent-pick]").forEach(b => b.addEventListener("click", () => {
            saveAppearance({ accent: b.dataset.accentPick });
            renderAppearanceControls();
        }));
    }
    const wallBox = el("wall-choices");
    if (wallBox) {
        const cur = document.documentElement.getAttribute("data-wallpaper") || "";
        wallBox.innerHTML = WALLPAPERS.map(w =>
            `<button type="button" class="choice${w.id === cur ? " active" : ""}" data-wall-pick="${w.id}">
                <span class="choice-preview wall-${w.id || "none"}"></span>${esc(w.name)}
             </button>`).join("");
        wallBox.querySelectorAll("[data-wall-pick]").forEach(b => b.addEventListener("click", () => {
            saveAppearance({ wallpaper: b.dataset.wallPick });
            renderAppearanceControls();
        }));
    }
    const fs = el("font-size-range");
    if (fs) {
        fs.value = parseInt(localStorage.getItem("centr_fsize") || "15", 10);
        el("font-size-value").textContent = fs.value + " px";
    }
}

function switchSettingsTab(tab) {
    $$("[data-settab]").forEach(b => b.classList.toggle("active", b.dataset.settab === tab));
    $$("[data-setpanel]").forEach(p => p.classList.toggle("hidden", p.dataset.setpanel !== tab));
    if (tab === "blocked") renderBlockedList();
}

function setupProfileModal() {
    el("profile-avatar-input").addEventListener("change", async (e) => {
        const file = e.target.files[0];
        e.target.value = "";
        if (!file) return;
        const cropped = await openCropper(file);
        if (!cropped) return;
        profileAvatarFile = cropped;
        el("profile-avatar-preview").innerHTML = `<img src="${URL.createObjectURL(cropped)}" alt="">`;
    });

    el("profile-copy").addEventListener("click", () => copyText(el("profile-link").value, "Ссылка скопирована"));

    $$("[data-settab]").forEach(b => b.addEventListener("click", () => switchSettingsTab(b.dataset.settab)));

    const fs = el("font-size-range");
    if (fs) {
        // Применяем размер мгновенно, а в профиль записываем только когда
        // ползунок отпустили. Раньше запись шла на КАЖДОЕ движение —
        // одно перетаскивание давало десятки запросов в базу.
        const saveSize = debounce(() => saveAppearance({ fontSize: parseInt(fs.value, 10) }), 500);
        fs.addEventListener("input", () => {
            el("font-size-value").textContent = fs.value + " px";
            applyAppearance({ fontSize: parseInt(fs.value, 10) });
            saveSize();
        });
    }

    const rb = el("ringtone-preview");
    if (rb) rb.addEventListener("click", () => playRingtonePreview(el("profile-ringtone").value || "center"));
    if (el("profile-ringtone")) el("profile-ringtone").addEventListener("change", () => playRingtonePreview(el("profile-ringtone").value || "center"));

    el("profile-save").addEventListener("click", async () => {
        const btn = el("profile-save");
        const username = el("profile-username").value.trim();
        const handleRaw = normalizeHandle(el("profile-handle").value);
        const status = el("profile-status").value.trim();

        if (username.length < 3) { toast("Имя слишком короткое", true); return; }
        if (handleRaw && !validHandle(handleRaw)) { toast("ID: 3–24 символа, латиница/цифры/_", true); return; }

        btn.disabled = true; btn.textContent = "Сохраняем…";
        try {
            let avatar_url = state.profile?.avatar_url || null;
            if (profileAvatarFile) avatar_url = await uploadToBucket(CFG.AVATAR_BUCKET, profileAvatarFile, "avatar");
            const patch = {
                username, status_text: status, avatar_url,
                ringtone: el("profile-ringtone") ? (el("profile-ringtone").value || "center") : "center",
                privacy_last_seen: el("privacy-lastseen") ? el("privacy-lastseen").value : "everyone",
                privacy_messages: el("privacy-messages") ? el("privacy-messages").value : "everyone",
            };
            if (handleRaw) patch.handle = handleRaw;
            const { error } = await sb.from("profiles").update(patch).eq("id", state.user.id);
            if (error) throw error;
            await loadMyProfile();
            paintMyAvatar();
            closeModal("profile-modal");
            toast("Профиль обновлён");
            renderChatList();
        } catch (err) {
            const msg = String(err.message || "");
            if (msg.includes("profiles_handle_key") || (msg.includes("duplicate") && msg.includes("handle")))
                toast("Этот ID уже занят", true);
            else toast(errRu(err), true);
        } finally {
            btn.disabled = false; btn.textContent = "Сохранить";
        }
    });
}

/* ------------------------------------------------------------------ *
 *  7. ЗАГРУЗКА ФАЙЛОВ: сжатие + возобновляемая передача
 *     Фото пережимаются в WebP — файл полу��ается в 3–5 раз меньше, чем
 *     JPEG исходника. Это главная экономия места в бесплатном хранилище.
 * ------------------------------------------------------------------ */
function fileExt(file) {
    if (file.name && file.name.includes(".")) return file.name.split(".").pop().toLowerCase();
    if (file.type && file.type.includes("/")) return file.type.split("/")[1];
    return "bin";
}

let __webpSupported = null;
function supportsWebP() {
    if (__webpSupported !== null) return __webpSupported;
    try {
        const c = document.createElement("canvas");
        c.width = c.height = 1;
        __webpSupported = c.toDataURL("image/webp").indexOf("image/webp") === 5;
    } catch (_) { __webpSupported = false; }
    return __webpSupported;
}

// Настройки сжатия фото из config.js. Именно от них сильнее всего зависит,
// на сколько людей хватит бесплатного тарифа: фотографии съедают и место,
// и трафик в десятки раз больше, чем весь остальной мессенджер.
const PHOTO_MAX_SIDE = Math.max(640, Math.min(Number(CFG.PHOTO_MAX_SIDE) || 1280, 2560));
const PHOTO_QUALITY  = Math.max(0.5, Math.min(Number(CFG.PHOTO_QUALITY) || 0.78, 0.95));

// Уменьшить изображение до maxSide и сжать. Возвращает File.
function compressImage(file, maxSide = PHOTO_MAX_SIDE, quality = PHOTO_QUALITY) {
    return new Promise((resolve) => {
        if (!file.type.startsWith("image/") || file.type === "image/gif") { resolve(file); return; }
        const img = new Image();
        const url = URL.createObjectURL(file);
        img.onload = () => {
            try {
                let { naturalWidth: w, naturalHeight: h } = img;
                if (Math.max(w, h) > maxSide) {
                    const k = maxSide / Math.max(w, h);
                    w = Math.round(w * k); h = Math.round(h * k);
                }
                const canvas = document.createElement("canvas");
                canvas.width = w; canvas.height = h;
                const ctx = canvas.getContext("2d");
                ctx.imageSmoothingQuality = "high";
                ctx.drawImage(img, 0, 0, w, h);
                const mime = supportsWebP() ? "image/webp" : "image/jpeg";
                const ext = mime === "image/webp" ? "webp" : "jpg";
                canvas.toBlob((blob) => {
                    URL.revokeObjectURL(url);
                    if (!blob || blob.size >= file.size) { resolve(file); return; }
                    resolve(new File([blob], `photo_${Date.now()}.${ext}`, { type: mime }));
                }, mime, quality);
            } catch (_) { URL.revokeObjectURL(url); resolve(file); }
        };
        img.onerror = () => { URL.revokeObjectURL(url); resolve(file); };
        img.src = url;
    });
}

async function uploadToBucket(bucket, file, folder, onProgress) {
    const ext = fileExt(file);
    // Путь ВСЕГДА начинается с идентификатора отправителя: по нему сервер
    // проверяет право на загрузку. Без этого любой вошедший мог заливать
    // файлы под чужим именем и забить общий бесплатный гигабайт.
    const me = state.user ? state.user.id : "anon";
    const sub = String(folder || "misc").replace(/^\/+|\/+$/g, "");
    const path = `${me}/${sub}/${Date.now()}_${Math.random().toString(36).slice(2, 8)}.${ext}`;
    const RESUMABLE_MIN = 6 * 1024 * 1024;

    if (window.tus && file.size > RESUMABLE_MIN) {
        await tusUpload(bucket, path, file, onProgress);
    } else {
        if (onProgress) onProgress(0.05);
        const { error } = await sb.storage.from(bucket).upload(path, file, {
            cacheControl: "604800", upsert: false, contentType: file.type || undefined
        });
        if (error) throw error;
        if (onProgress) onProgress(1);
    }
    const { data } = sb.storage.from(bucket).getPublicUrl(path);
    return data.publicUrl;
}

function tusUpload(bucket, path, file, onProgress) {
    return new Promise(async (resolve, reject) => {
        let token = null;
        try {
            const { data } = await sb.auth.getSession();
            token = data && data.session ? data.session.access_token : null;
        } catch (_) {}
        if (!token) { reject(new Error("Нет активной сессии для загрузки")); return; }

        const endpoint = `${String(CFG.SUPABASE_URL).replace(/\/+$/, "")}/storage/v1/upload/resumable`;
        const upload = new window.tus.Upload(file, {
            endpoint,
            retryDelays: [0, 1000, 3000, 5000, 10000],
            headers: { authorization: `Bearer ${token}`, "x-upsert": "true" },
            uploadDataDuringCreation: true,
            removeFingerprintOnSuccess: true,
            chunkSize: 6 * 1024 * 1024,
            metadata: {
                bucketName: bucket, objectName: path,
                contentType: file.type || "application/octet-stream",
                cacheControl: "604800"
            },
            onError: (err) => reject(err),
            onProgress: (uploaded, total) => { if (onProgress && total) onProgress(uploaded / total); },
            onSuccess: () => resolve()
        });
        upload.findPreviousUploads()
            .then((prev) => { if (prev && prev.length) upload.resumeFromPreviousUpload(prev[0]); upload.start(); })
            .catch(() => upload.start());
    });
}

// Удалить файл из хранилища по публичной ссылке (при удалении сообщения,
// чтобы не копился мусор и не таял бесплатный гигабайт).
async function removeStorageByUrl(urls) {
    const list = (Array.isArray(urls) ? urls : [urls]).filter(Boolean);
    if (!list.length) return;
    const byBucket = {};
    list.forEach(u => {
        const m = String(u).match(/\/storage\/v1\/object\/public\/([^/]+)\/(.+)$/);
        if (!m) return;
        (byBucket[m[1]] = byBucket[m[1]] || []).push(decodeURIComponent(m[2].split("?")[0]));
    });
    for (const [bucket, paths] of Object.entries(byBucket)) {
        try { await sb.storage.from(bucket).remove(paths); } catch (_) {}
    }
}

function showUploadProgress(label) {
    const wrap = el("toast-wrap");
    const node = document.createElement("div");
    node.className = "toast upload-toast";
    node.innerHTML = `<div class="ut-label"><span class="ut-text">${esc(label)}</span> <span class="ut-pct">0%</span></div>
                      <div class="ut-bar"><span></span></div>`;
    wrap.appendChild(node);
    const pctEl = node.querySelector(".ut-pct");
    const barEl = node.querySelector(".ut-bar > span");
    let done = false;
    return {
        update(p) {
            const pct = Math.max(0, Math.min(100, Math.round((p || 0) * 100)));
            pctEl.textContent = pct + "%"; barEl.style.width = pct + "%";
        },
        finish() {
            if (done) return; done = true;
            pctEl.textContent = "100%"; barEl.style.width = "100%";
            setTimeout(() => { node.style.opacity = "0"; node.style.transition = "opacity .3s"; }, 250);
            setTimeout(() => node.remove(), 650);
        },
        fail(msg) {
            if (done) return; done = true;
            node.classList.add("error");
            node.querySelector(".ut-text").textContent = msg || "Ошибка загрузки";
            setTimeout(() => { node.style.opacity = "0"; node.style.transition = "opacity .3s"; }, 2200);
            setTimeout(() => node.remove(), 2700);
        }
    };
}

/* ------------------------------------------------------------------ *
 *  7b. КРОППЕР АВАТАРА (зум + перемещение → квадрат)
 * ------------------------------------------------------------------ */
let cropState = null;

function openCropper(file) {
    return new Promise((resolve) => {
        const img = el("cropper-img");
        const url = URL.createObjectURL(file);
        cropState = { resolve, url, active: false, dragging: false };
        openModal("cropper-modal");
        el("cropper-zoom").value = 1;
        img.onload = () => {
            requestAnimationFrame(() => {
                const stage = el("cropper-stage");
                const size = stage.clientWidth || 300;
                cropState.natW = img.naturalWidth;
                cropState.natH = img.naturalHeight;
                cropState.size = size;
                cropState.baseScale = Math.max(size / cropState.natW, size / cropState.natH);
                cropState.scale = cropState.baseScale;
                cropState.tx = (size - cropState.natW * cropState.scale) / 2;
                cropState.ty = (size - cropState.natH * cropState.scale) / 2;
                cropState.active = true;
                cropperPaint();
                el("cropper-zoom").value = 1;
            });
        };
        img.src = url;
    });
}

function cropperPaint() {
    const c = cropState; if (!c) return;
    const dw = c.natW * c.scale, dh = c.natH * c.scale;
    c.tx = Math.min(0, Math.max(c.size - dw, c.tx));
    c.ty = Math.min(0, Math.max(c.size - dh, c.ty));
    el("cropper-img").style.transform = `translate(${c.tx}px, ${c.ty}px) scale(${c.scale})`;
}

function cropperZoomTo(newScale, ax, ay) {
    const c = cropState; if (!c) return;
    ax = (ax == null) ? c.size / 2 : ax;
    ay = (ay == null) ? c.size / 2 : ay;
    newScale = Math.max(c.baseScale, Math.min(c.baseScale * 4, newScale));
    const ix = (ax - c.tx) / c.scale, iy = (ay - c.ty) / c.scale;
    c.scale = newScale;
    c.tx = ax - ix * c.scale; c.ty = ay - iy * c.scale;
    cropperPaint();
    el("cropper-zoom").value = (c.scale / c.baseScale).toFixed(2);
}

function closeCropper(result) {
    const c = cropState;
    hide(el("cropper-modal"));
    if (c) {
        try { URL.revokeObjectURL(c.url); } catch (_) {}
        const res = c.resolve; cropState = null;
        res && res(result || null);
    }
}

function cropperExport() {
    const c = cropState;
    return new Promise((resolve) => {
        const out = 512;
        const canvas = document.createElement("canvas");
        canvas.width = out; canvas.height = out;
        const ctx = canvas.getContext("2d");
        const sSize = c.size / c.scale;
        const sx = -c.tx / c.scale, sy = -c.ty / c.scale;
        try { ctx.drawImage(el("cropper-img"), sx, sy, sSize, sSize, 0, 0, out, out); } catch (_) {}
        const mime = supportsWebP() ? "image/webp" : "image/jpeg";
        const ext = mime === "image/webp" ? "webp" : "jpg";
        canvas.toBlob((blob) => {
            resolve(new File([blob], `avatar_${Date.now()}.${ext}`, { type: mime }));
        }, mime, 0.9);
    });
}

function setupCropper() {
    const stage = el("cropper-stage");

    el("cropper-zoom").addEventListener("input", (e) => {
        if (!cropState) return;
        cropperZoomTo(cropState.baseScale * parseFloat(e.target.value));
    });

    stage.addEventListener("wheel", (e) => {
        if (!cropState || !cropState.active) return;
        e.preventDefault();
        const rect = stage.getBoundingClientRect();
        cropperZoomTo(cropState.scale * (e.deltaY < 0 ? 1.08 : 0.92), e.clientX - rect.left, e.clientY - rect.top);
    }, { passive: false });

    const start = (x, y) => {
        if (!cropState || !cropState.active) return;
        cropState.dragging = true;
        cropState.sx = x; cropState.sy = y;
        cropState.stx = cropState.tx; cropState.sty = cropState.ty;
        stage.classList.add("grabbing");
    };
    const move = (x, y) => {
        const c = cropState;
        if (!c || !c.dragging) return;
        c.tx = c.stx + (x - c.sx); c.ty = c.sty + (y - c.sy);
        cropperPaint();
    };
    const end = () => { if (cropState) cropState.dragging = false; stage.classList.remove("grabbing"); };

    stage.addEventListener("mousedown", (e) => { e.preventDefault(); start(e.clientX, e.clientY); });
    window.addEventListener("mousemove", (e) => move(e.clientX, e.clientY));
    window.addEventListener("mouseup", end);
    stage.addEventListener("touchstart", (e) => { const t = e.touches[0]; start(t.clientX, t.clientY); }, { passive: true });
    stage.addEventListener("touchmove", (e) => {
        if (!cropState) return;
        if (e.touches.length === 2) {
            const [a, b] = e.touches;
            const dist = Math.hypot(a.clientX - b.clientX, a.clientY - b.clientY);
            const rect = stage.getBoundingClientRect();
            const mx = (a.clientX + b.clientX) / 2 - rect.left;
            const my = (a.clientY + b.clientY) / 2 - rect.top;
            if (cropState.pinch) cropperZoomTo(cropState.scale * (dist / cropState.pinch), mx, my);
            cropState.pinch = dist;
            cropState.dragging = false;
            e.preventDefault();
        } else { const t = e.touches[0]; move(t.clientX, t.clientY); }
    }, { passive: false });
    stage.addEventListener("touchend", () => { end(); if (cropState) cropState.pinch = null; });

    el("cropper-apply").addEventListener("click", async () => {
        if (!cropState) return;
        const file = await cropperExport();
        closeCropper(file);
    });
    el("cropper-cancel").addEventListener("click", () => closeCropper(null));
    el("cropper-cancel-2").addEventListener("click", () => closeCropper(null));
}

/* ------------------------------------------------------------------ *
 *  8. СПИСОК ЧАТОВ
 *     Раньше список собирался 2 + 2×N запросами (20 чатов = 42 запроса).
 *     Теперь всё приходит одним вызовом chat_overview().
 * ------------------------------------------------------------------ */
function chatTitleOf(e) {
    if (!e) return "Чат";
    if (e.is_group) return e.name || "Группа";
    if (e.other_id === state.user?.id || !e.other_id) return "Сохранённые сообщения";
    return e.other_username || "Пользователь";
}
function chatAvatarOf(e) {
    if (!e) return null;
    return e.is_group ? (e.avatar_url || null) : (e.other_avatar || null);
}
function chatAvatarKey(e) {
    return e ? (e.is_group ? e.chat_id : (e.other_id || e.chat_id)) : "";
}
function isSavedMessages(e) { return e && !e.is_group && (!e.other_id || e.other_id === state.user?.id); }
// Время сервера по часам устройства. Нужно, потому что на телефонах часы
// нередко врут на минуты, и без поправки «в сети» показывалось неверно.
function serverNow() { return Date.now() - (state.clockSkew || 0); }

function isOnlineEntry(e) {
    if (!e || e.is_group || !e.other_last_seen) return false;
    return (serverNow() - new Date(e.other_last_seen).getTime()) < ONLINE_WINDOW;
}
function getChatEntry(chatId) { return state.chats.find(e => e.chat_id === chatId); }
function activeEntry() { return getChatEntry(state.activeChatId); }

// Профиль собеседника из строки списка чатов — нужен для аватаров в ленте.
function cacheOtherProfile(e) {
    if (!e || !e.other_id) return;
    state.profilesCache[e.other_id] = Object.assign(state.profilesCache[e.other_id] || {}, {
        id: e.other_id, username: e.other_username,
        handle: e.other_handle, avatar_url: e.other_avatar, last_seen: e.other_last_seen
    });
}

async function loadChats(silent) {
    try {
        const rows = await rpc("chat_overview");
        state.chats = rows || [];
        state.chatsLoaded = true;
        state.chats.forEach(cacheOtherProfile);
        renderChatList();
        updateGlobalBadge();
        cacheSaveChats(state.chats);
        if (state.activeChatId) {
            updateChatHeaderStatus();
            syncOutgoingChecks();
            updateComposerAvailability();
            // Если чат открыли по ссылке или из уведомления раньше, чем загрузился
            // список, канал чата ещё не подписан — исправляем это здесь.
            if (!chatChannel) {
                const e = getChatEntry(state.activeChatId);
                if (e) subscribeChatChannel(e);
            }
        }
    } catch (err) {
        console.error("loadChats", err);
        if (!silent) toast(errRu(err), true);
    }
}

// Точечное обновление строки чата вместо полной перезагрузки списка.
// Раньше после удаления или правки сообщения вызывался chat_overview() целиком:
// самый тяжёлый запрос ради одной изменившейся строки.
const refreshChatsSoon = debounce(() => loadChats(true), 1200);

function snippetForMessage(m) {
    if (!m) return "";
    if (m.system_kind) return m.text || "";
    if (m.media_type === "image") return "📷 Фото" + (m.text ? " · " + m.text : "");
    if (m.media_type === "video") return "🎬 Видео";
    if (m.media_type === "voice") return "🎤 Голосовое сообщение";
    if (m.media_type === "audio") return "🎵 Аудио";
    if (m.media_url) return "📎 Вложение";
    return m.text || "";
}

function snippetForEntry(e) {
    if (e.last_msg_system) return e.last_msg_text || "";
    if (e.last_msg_media === "image") return "📷 Фото" + (e.last_msg_text ? " · " + e.last_msg_text : "");
    if (e.last_msg_media === "video") return "🎬 Видео";
    if (e.last_msg_media === "voice") return "🎤 Голосовое сообщение";
    if (e.last_msg_media === "audio") return "🎵 Аудио";
    if (e.last_msg_media) return "📎 Вложение";
    return e.last_msg_text || "";
}

/* ---- Галочки: считаем по курсорам собеседника ---- */
function checkIcon(status, hint) {
    if (status === "pending")
        return `<span class="check pending" title="Отправляется"><svg viewBox="0 0 24 24"><path d="M11.5 7v5.2l4 2.4.8-1.3-3.3-2V7z"/><path d="M12 3a9 9 0 100 18 9 9 0 000-18zm0 16a7 7 0 110-14 7 7 0 010 14z"/></svg></span>`;
    if (status === "failed")
        return `<span class="check failed" title="Не отправлено — нажмите, чтобы повторить">!</span>`;
    if (status === "sent")
        return `<span class="check" title="${esc(hint || "Отправлено")}"><svg viewBox="0 0 18 18"><path d="M13.6 4.5l-6.3 8.2-3-2.9-1 1 4 3.9 7.3-9.5z"/></svg></span>`;
    const cls = status === "read" ? "check read" : "check";
    const title = hint || (status === "read" ? "Прочитано" : "Доставлено");
    return `<span class="${cls}" title="${esc(title)}"><svg viewBox="0 0 20 18"><path d="M8.6 13.2l-3-2.9-1 1 4 3.9 7.3-9.5-1-.8z"/><path d="M14.2 4.9l-6.2 8.1.9.9 7.3-9.5z" opacity=".9"/></svg></span>`;
}

// Статус исходящего сообщения по курсорам собеседника.
function outgoingStatus(m, entry) {
    if (m._failed)  return "failed";
    if (m._pending) return "pending";
    entry = entry || getChatEntry(m.chat_id);
    if (!entry) return "sent";
    if (isSavedMessages(entry)) return "read";
    const t = new Date(m.created_at).getTime();
    if (entry.is_group) {
        // В группах курсор прочтения есть у каждого участника — раньше мы им
        // просто не пользовались и всегда показывали «отправлено».
        const st = groupReadCount(m, entry);
        if (!st) return "sent";
        if (st.read >= st.total) return "read";
        if (st.read > 0) return "delivered";
        return "sent";
    }
    if (entry.peer_read_at && new Date(entry.peer_read_at).getTime() >= t) return "read";
    if (entry.peer_delivered_at && new Date(entry.peer_delivered_at).getTime() >= t) return "delivered";
    return "sent";
}

// Сколько участников группы прочитали это сообщение.
function groupReadCount(m, entry) {
    const mem = state.members[entry.chat_id];
    if (!mem || mem.length < 2) return null;
    const t = new Date(m.created_at).getTime();
    const others = mem.filter(p => p.user_id !== state.user.id);
    if (!others.length) return null;
    const read = others.filter(p => p.last_read_at && new Date(p.last_read_at).getTime() >= t).length;
    return { read, total: others.length };
}

// Подпись к галочке: в группе показываем «Прочитали 2 из 5».
function checkHint(m, entry) {
    if (!entry || !entry.is_group) return "";
    const st = groupReadCount(m, entry);
    return st ? `Прочитали ${st.read} из ${st.total}` : "";
}

function renderChatList() {
    const list = el("chat-list");
    if (!list) return;

    let entries = state.chats.filter(e => !!e.is_archived === !!state.showArchived);

    if (state.searchTerm && state.sidebarTab === "chats") {
        const q = state.searchTerm.toLowerCase();
        entries = state.chats.filter(e =>
            chatTitleOf(e).toLowerCase().includes(q) ||
            (e.other_handle || "").toLowerCase().includes(q));
    }

    // Кнопка «Архив» показывается, если есть что архивировать.
    const archCount = state.chats.filter(e => e.is_archived).length;
    const archBtn = el("archive-row");
    if (archBtn) {
        archBtn.classList.toggle("hidden", archCount === 0 || state.showArchived || !!state.searchTerm);
        const c = el("archive-count");
        if (c) c.textContent = String(archCount);
    }
    const backArch = el("archive-back");
    if (backArch) backArch.classList.toggle("hidden", !state.showArchived);

    if (!entries.length) {
        list.innerHTML = "";
        const empty = el("chat-list-empty");
        if (state.chatsLoaded) {
            show(empty);
            empty.querySelector("p").textContent = state.showArchived
                ? "В архиве пока пусто."
                : (state.searchTerm ? "Ничего не найдено." : "Пока нет чатов.");
        } else hide(empty);
        return;
    }
    hide(el("chat-list-empty"));

    list.innerHTML = entries.map(e => {
        const title = chatTitleOf(e);
        const url = chatAvatarOf(e);
        const active = e.chat_id === state.activeChatId ? " active" : "";
        const unreadCls = e.unread > 0 ? " unread" : "";
        const time = fmtListTime(e.last_msg_at || e.last_message_at);
        const online = isOnlineEntry(e);
        const typing = state.typing[e.chat_id];

        let snippet, snippetCls = "chat-item-snippet";
        if (typing && typing.until > Date.now()) {
            snippet = e.is_group ? `${esc(typing.name || "кто-то")} печатает…` : "печатает…";
            snippetCls += " typing";
        } else if (e.draft && e.chat_id !== state.activeChatId) {
            snippet = `<span class="draft-mark">Черновик:</span> ${esc(clip(e.draft, 40))}`;
        } else {
            let check = "";
            if (e.last_msg_sender && e.last_msg_sender === state.user.id && !e.last_msg_system) {
                check = `<span class="chat-item-check">${checkIcon(outgoingStatus({ created_at: e.last_msg_at, chat_id: e.chat_id }, e))}</span>`;
            }
            const prefix = (e.is_group && e.last_msg_sender && e.last_msg_sender !== state.user.id && !e.last_msg_system)
                ? `${esc((e.last_msg_sender_name || "").split(" ")[0])}: ` : "";
            snippet = `${check}${prefix}${esc(snippetForEntry(e))}`;
        }

        const badges = [
            isSavedMessages(e) ? `<span class="mini-ico" title="Сохранённые">🔖</span>` : "",
            e.is_muted ? `<span class="mini-ico" title="Уведомления отключены">🔇</span>` : "",
            e.is_pinned && !state.showArchived ? `<span class="mini-ico" title="Закреплён">📌</span>` : "",
        ].join("");

        return `
        <div class="chat-item${active}${unreadCls}" data-chat="${e.chat_id}">
            <span class="avatar">
                ${url ? `<img src="${esc(url)}" alt="" loading="lazy">`
                      : `<span class="avatar-fallback" style="background:${avatarTint(chatAvatarKey(e))}">${isSavedMessages(e) ? "🔖" : esc(initials(title))}</span>`}
                ${online ? '<span class="online-dot"></span>' : ""}
            </span>
            <div class="chat-item-main">
                <div class="chat-item-row">
                    <span class="chat-item-name">${esc(title)}</span>
                    <span class="chat-item-time">${time}</span>
                </div>
                <div class="chat-item-sub">
                    <span class="${snippetCls}">${snippet}</span>
                    <span class="chat-item-flags">${badges}${e.unread > 0 ? `<span class="chat-badge${e.is_muted ? " muted" : ""}">${e.unread > 99 ? "99+" : e.unread}</span>` : ""}</span>
                </div>
            </div>
        </div>`;
    }).join("");

    list.querySelectorAll(".chat-item").forEach(node => {
        node.addEventListener("click", () => openChat(node.dataset.chat));
        node.addEventListener("contextmenu", (ev) => {
            ev.preventDefault();
            openChatMenu(node.dataset.chat, ev.clientX, ev.clientY);
        });
        let lp;
        node.addEventListener("touchstart", (ev) => {
            const t = ev.touches[0];
            lp = setTimeout(() => { vibrate(30); openChatMenu(node.dataset.chat, t.clientX, t.clientY); }, 480);
        }, { passive: true });
        node.addEventListener("touchend", () => clearTimeout(lp));
        node.addEventListener("touchmove", () => clearTimeout(lp));
    });
}

/* ---- Контекстное меню чата: закрепить, отключить звук, архив, очистить, удалить ---- */
function openChatMenu(chatId, x, y) {
    const e = getChatEntry(chatId);
    if (!e) return;
    const menu = el("chat-menu");
    menu.innerHTML = `
        <ul class="context-actions">
            <li data-cm="read">${e.unread > 0 ? "✅ Отметить прочитанным" : "🔵 Отметить ��епрочитанным"}</li>
            <li data-cm="pin">${e.is_pinned ? "📌 Открепить" : "📌 Закрепить"}</li>
            <li data-cm="mute">${e.is_muted ? "🔔 Включить уведомления" : "🔇 Отключить уведомления"}</li>
            <li data-cm="archive">${e.is_archived ? "📤 Убрать из архива" : "📥 В архив"}</li>
            <li data-cm="export">💾 Сохранить переписку в файл</li>
            <li data-cm="clear">🧽 Очистить историю у меня</li>
            ${!e.is_group ? `<li data-cm="clearall" class="danger">🔥 Удалить переписку у обоих</li>` : ""}
            <li data-cm="delete" class="danger">${e.is_group ? "🚪 Выйти из группы" : "🗑️ Удалить чат"}</li>
        </ul>`;
    show(menu);
    const mw = menu.offsetWidth, mh = menu.offsetHeight;
    menu.style.left = Math.max(8, Math.min(x, window.innerWidth - mw - 10)) + "px";
    menu.style.top  = Math.max(8, Math.min(y, window.innerHeight - mh - 10)) + "px";

    menu.querySelectorAll("[data-cm]").forEach(li => li.addEventListener("click", async () => {
        hide(menu);
        const act = li.dataset.cm;
        try {
            if (act === "pin")      { await rpc("set_chat_flags", { _chat: chatId, _pinned: !e.is_pinned }); }
            else if (act === "mute"){ await rpc("set_chat_flags", { _chat: chatId, _muted: !e.is_muted }); }
            else if (act === "archive") { await rpc("set_chat_flags", { _chat: chatId, _archived: !e.is_archived }); }
            else if (act === "read") {
                if (e.unread > 0) { await rpc("mark_chat_read", { _chat: chatId }); }
                else { await markChatUnread(chatId); }
            }
            else if (act === "export") { await exportChat(chatId); return; }
            else if (act === "clear") {
                const ok = await confirmBox("Очистить историю?",
                    "История исчезнет только у вас. У собеседника переписка останется.", "Очистить");
                if (!ok) return;
                await rpc("clear_history", { _chat: chatId });
                if (state.activeChatId === chatId) { state.messages = []; renderMessages(); }
            }
            else if (act === "clearall") {
                const ok = await confirmBox("Удалить переписку у обоих?",
                    "Все сообщения этого чата будут стёрты безвозвратно и у вас, и у собеседника. Следов не останется.", "Удалить всё");
                if (!ok) return;
                const urls = await rpc("delete_history_for_all", { _chat: chatId });
                removeStorageByUrl((urls || []).map(r => r.media_url));
                if (state.activeChatId === chatId) { state.messages = []; renderMessages(); renderPinnedBar(); }
                toast("Переписка удалена у обоих");
            }
            else if (act === "delete") {
                const ok = await confirmBox(
                    e.is_group ? "Выйти из группы?" : "Удалить чат?",
                    e.is_group ? "Вы перестанете получать сообщения этой группы."
                               : "Чат и его история будут удалены у вас.", "Удалить");
                if (!ok) return;
                const urls = await rpc("delete_chat", { _chat: chatId, _for_all: false });
                removeStorageByUrl((urls || []).map(r => r.media_url));
                if (state.activeChatId === chatId) closeActiveChat();
                toast(e.is_group ? "Вы вышли из группы" : "Чат удалён");
            }
            await loadChats(true);
        } catch (err) { toast(errRu(err), true); }
    }));
}

/* ------------------------------------------------------------------ *
 *  СОХРАНИТЬ ПЕРЕПИСКУ В ФАЙЛ
 *  Просили «взять лучшее из взрослых мессенджеров» — экспорт есть у всех.
 *  Полезно и практически: перед чисткой старой истории в админке можно
 *  сохранить то, что дорого.
 * ------------------------------------------------------------------ */
async function exportChat(chatId) {
    const entry = getChatEntry(chatId);
    if (!entry) return;
    const title = chatTitleOf(entry);

    const ok = await confirmBox("Сохранить переписку в файл?",
        `��ся доступная история чата «${title}» будет собрана в текстовый файл и скачана на это устройство. ` +
        `Файлы и фото в него не попадут — только ссылки на них.`, "Сохранить", false);
    if (!ok) return;

    const prog = showUploadProgress("Собираем переписку");
    try {
        // Тянем страницами, как обычную историю. Ограничение на 20 000
        // сообщений — чтобы не подвесить телефон на гигантском чате.
        const LIMIT = 20000, PAGE = 200;
        let before = null, all = [], guard = 0;
        while (all.length < LIMIT && guard++ < 200) {
            const rows = await rpc("messages_page", { _chat: chatId, _before: before, _limit: PAGE });
            const batch = rows || [];
            if (!batch.length) break;
            all = all.concat(batch);
            before = batch[batch.length - 1].created_at;
            prog.update(Math.min(0.9, all.length / LIMIT + 0.05));
            if (batch.length < PAGE) break;
        }
        all.reverse();
        if (!all.length) { prog.fail("В чате нет сообщений"); return; }

        await cacheProfiles(all.map(m => m.sender_id));

        const nameOf = (id) => id === state.user.id
            ? "Вы"
            : ((state.profilesCache[id] && state.profilesCache[id].username) || "Пользователь");

        const lines = [
            `Переписка: ${title}`,
            `Выгружено: ${new Date().toLocaleString("ru-RU")}`,
            `Сообщений: ${all.length}`,
            "=".repeat(60), "",
        ];
        let lastDay = "";
        for (const m of all) {
            const day = fmtDay(m.created_at);
            if (day !== lastDay) { lines.push("", `--- ${day} ---`, ""); lastDay = day; }
            if (m.system_kind) { lines.push(`* ${m.text || ""}`); continue; }
            let body = m.text || "";
            if (m.media_url) {
                const kind = { image: "Фото", video: "Видео", voice: "Голосовое",
                               audio: "Аудио" }[m.media_type] || "Файл";
                body = `[${kind}: ${m.media_url}]` + (body ? " " + body : "");
            }
            lines.push(`[${fmtTime(m.created_at)}] ${nameOf(m.sender_id)}: ${body}` +
                       (m.edited_at ? "  (изменено)" : ""));
        }

        // \ufeff в начале — чтобы Блокнот в Windows не показал кракозябры.
        const blob = new Blob(["\ufeff" + lines.join("\n")], { type: "text/plain;charset=utf-8" });
        const safe = title.replace(/[^\p{L}\p{N} _-]/gu, "").trim().slice(0, 40) || "chat";
        const a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = `Центр — ${safe} — ${new Date().toISOString().slice(0, 10)}.txt`;
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(a.href), 5000);

        prog.finish();
        toast(`Сохранено ${all.length} ${pluralRu(all.length, "сообщение", "сообщения", "сообщений")}`);
    } catch (err) {
        console.error(err);
        prog.fail(errRu(err));
    }
}

// «Отметить непрочитанным». Раньше клиент правил строку курсора напрямую,
// подставляя ВРЕМЯ СВОЕГО устройства. На телефоне с убежавшими часами курсор
// улетал в будущее, и чат больше никогда не показывал непрочитанные.
// Теперь дату считает сервер по своим часам.
async function markChatUnread(chatId) {
    await rpc("mark_chat_unread", { _chat: chatId });
}

/* ------------------------------------------------------------------ *
 *  8b. ЗАПУСК: ОДИН ЗАПРОС ВМЕСТО ПЯТИ
 *      Раньше при входе шло пять обращений подряд — профиль, чаты, друзья,
 *      блокировки, настройки. Каждое ждало предыдущего, и на мобильном
 *      интернете набегала секунда-полторы пустого экрана.
 *      Теперь: сначала рисуем то, что лежит на устройстве (мгновенно),
 *      потом одним вызовом boot() забираем всё свежее.
 * ------------------------------------------------------------------ */
async function paintFromCache() {
    const cached = await cacheLoadChats();
    if (!Array.isArray(cached) || !cached.length) return false;
    state.chats = cached;
    renderChatList();
    updateGlobalBadge();
    return true;
}

function applyBoot(data) {
    if (!data) return;

    if (data.profile) {
        state.profile = data.profile;
        state.profilesCache[data.profile.id] = data.profile;
        applyAppearance({
            theme: data.profile.ui_theme, accent: data.profile.ui_accent,
            wallpaper: data.profile.ui_wallpaper || "", fontSize: data.profile.ui_font_size
        });
        paintMyAvatar();
    }

    // Поправка часов устройства: без неё на телефоне с убежавшим временем
    // «в сети» и порядок сообщений показывались неверно.
    if (data.now) state.clockSkew = Date.now() - new Date(data.now).getTime();

    state.chats = data.chats || [];
    state.chatsLoaded = true;
    state.chats.forEach(cacheOtherProfile);

    const fr = data.friends || [];
    state.friends  = fr.filter(r => r.kind === "friend");
    state.incoming = fr.filter(r => r.kind === "incoming");
    state.outgoing = fr.filter(r => r.kind === "outgoing");
    fr.forEach(r => {
        state.profilesCache[r.user_id] = Object.assign(state.profilesCache[r.user_id] || {}, {
            id: r.user_id, username: r.username, handle: r.handle,
            avatar_url: r.avatar_url, status_text: r.status_text, last_seen: r.last_seen
        });
    });

    state.blocked = data.blocked || [];
    state.isAdmin = !!data.is_admin;

    renderChatList();
    updateGlobalBadge();
    updateFriendsBadge();
    if (state.sidebarTab === "friends") renderFriends();
    if (data.settings) applyAppSettings(data.settings);
    cacheSaveChats(state.chats);

    // Сообщения самого свежего чата пришли тем же запросом — кладём в кеш,
    // чтобы первый же клик по чату открылся без ожидания.
    if (data.top_chat && Array.isArray(data.top_messages) && data.top_messages.length) {
        const list = data.top_messages.slice().reverse();
        cacheSaveMessages(data.top_chat, list);
        if (!state.activeChatId) state.preloaded = { chatId: data.top_chat, messages: list };
    }
}

async function bootstrap() {
    try {
        const data = await rpc("boot", { _with_top_chat: true });
        applyBoot(data);
        if (state.activeChatId) {
            updateChatHeaderStatus();
            syncOutgoingChecks();
            updateComposerAvailability();
            if (!chatChannel) {
                const e = getChatEntry(state.activeChatId);
                if (e) subscribeChatChannel(e);
            }
        }
        return true;
    } catch (err) {
        console.error("boot", err);
        // Не получилось одним запросом — работаем по старой схеме, чтобы
        // мессенджер всё равно открылся.
        await loadMyProfile();
        await Promise.all([loadChats(true), loadFriends(), loadBlocked()]);
        toast(errRu(err), true);
        return false;
    }
}

/* ------------------------------------------------------------------ *
 *  9. АКТИВНЫЙ ЧАТ: ПОСТРАНИЧНАЯ ЛЕНТА
 *     Загружаем последние 40 сообщений, остальное — по прокрутке вверх.
 *     Раньше тянулись сразу 500 и лента заметно тормозила.
 * ------------------------------------------------------------------ */
async function openChat(chatId) {
    if (!chatId) return;
    if (state.activeChatId && state.activeChatId !== chatId) saveDraft(state.activeChatId);

    const prev = state.activeChatId;
    state.activeChatId = chatId;
    state.replyTo = null;
    state.pinnedIndex = 0;
    state.messages = [];
    state.hasMoreOlder = true;
    exitSelectMode();
    resetScrollBadge();
    updateReplyPreview();
    cancelEdit(true);
    notifyNativeActiveChat(chatId);
    hide(el("chat-search-bar"));
    hide(el("pinned-bar"));

    const entry = getChatEntry(chatId);
    hide(el("welcome-screen"));
    show(el("chat-view"));
    el("messenger").classList.add("chat-open");

    const title = entry ? chatTitleOf(entry) : "Чат";
    paintAvatar(el("chat-header-avatar-img"), el("chat-header-avatar-fallback"),
        chatAvatarOf(entry), title, chatAvatarKey(entry));
    el("chat-header-name").textContent = title;
    updateChatHeaderStatus();
    toggleCallButton(entry);
    updateComposerAvailability();

    // Черновик подставляем сразу.
    const input = el("message-input");
    input.value = (entry && entry.draft) || "";
    input.dispatchEvent(new Event("input"));

    // Полоса «Новые сообщения» ставится по курсору ДО отметки прочтения.
    state.firstUnreadAt = (entry && entry.unread > 0) ? entry.my_read_at : null;

    renderChatList();
    if (prev !== chatId) subscribeChatChannel(entry);

    // ── МГНОВЕННАЯ ОТРИСОВКА ───────────────────────────────────────────
    // Сначала показываем то, что уже лежит на устройстве. Спиннер видно
    // только при самом первом заходе в этот чат.
    let painted = false;
    const pre = (state.preloaded && state.preloaded.chatId === chatId) ? state.preloaded.messages : null;
    state.preloaded = null;
    const cached = pre || await cacheLoadMessages(chatId);
    if (chatId !== state.activeChatId) return;
    if (Array.isArray(cached) && cached.length) {
        state.messages = cached;
        await cacheProfiles(cached.map(m => m.sender_id));
        if (chatId !== state.activeChatId) return;
        renderMessages();
        scrollMessagesToBottom(true);
        painted = true;
    } else {
        el("messages").innerHTML = `<div class="load-more"><span class="spinner sm"></span></div>`;
    }

    // ── ДОГРУЗКА СВЕЖЕГО ──────────────────────────────────────────────
    // Все три запроса уходят одновременно, а не по очереди: три круга
    // ожидания превращаются в один.
    await Promise.all([
        loadLatestMessages(chatId, painted),
        loadPinned(chatId),
        markChatRead(chatId),
        (entry && entry.is_group) ? loadMembers(chatId, true) : Promise.resolve(),
    ]);
    if (chatId !== state.activeChatId) return;
    updateChatHeaderStatus();
    refreshPeerPresence();
}

function closeActiveChat() {
    saveDraft(state.activeChatId);
    state.activeChatId = null;
    state.messages = [];
    exitSelectMode();
    unsubscribeChatChannel();
    notifyNativeActiveChat("");
    show(el("welcome-screen"));
    hide(el("chat-view"));
    el("messenger").classList.remove("chat-open");
    renderChatList();
}

async function loadLatestMessages(chatId, alreadyPainted) {
    try {
        const rows = await rpc("messages_page", { _chat: chatId, _before: null, _limit: PAGE_SIZE });
        if (chatId !== state.activeChatId) return;
        const list = (rows || []).slice().reverse();       // с сервера — по убыванию

        // Если уже нарисовали из кеша и ничего не изменилось — не трогаем
        // ленту вообще: никакого мигания и прыжков прокрутки.
        if (alreadyPainted && sameMessageSet(state.messages, list)) {
            state.hasMoreOlder = (rows || []).length >= PAGE_SIZE;
            return;
        }

        // Незавершённые отправки из очереди сохраняем — они не с сервера.
        const pending = state.messages.filter(m => m._pending || m._failed);
        state.messages = list.concat(pending);
        state.hasMoreOlder = (rows || []).length >= PAGE_SIZE;

        await Promise.all([
            loadReactionsFor(list),
            cacheProfiles([
                ...list.map(m => m.sender_id),
                ...list.map(m => m.forwarded_from).filter(Boolean)
            ]),
        ]);
        if (chatId !== state.activeChatId) return;
        renderMessages();
        scrollMessagesToBottom(true);
        resetScrollBadge();
        cacheSaveMessages(chatId, list);
    } catch (err) {
        console.error(err);
        // Если из кеша уже что-то показано — оставляем это, а не пустой экран.
        if (!alreadyPainted) {
            el("messages").innerHTML = `<div class="day-sep">Не удалось загрузить сообщения. <button class="link-btn" data-retry-load>Повторить</button></div>`;
            const btn = el("messages").querySelector("[data-retry-load]");
            if (btn) btn.addEventListener("click", () => loadLatestMessages(chatId, false));
        } else {
            setConnState(false, "Нет связи — показана сохранённая переписка");
        }
    }
}

// Совпадает ли то, что показано, с тем, что пришло с сервера.
// В кеше держим 60 сообщений, а сервер отдаёт последние 40, поэтому
// сверяем хвост: если 40 последних те же — перерисовывать нечего,
// а лишние 20 из кеша только добавляют прокрутки вверх.
function sameMessageSet(shown, fresh) {
    const real = (shown || []).filter(m => !m._pending && !m._failed);
    const b = fresh || [];
    if (!b.length || real.length < b.length) return false;
    const tail = real.slice(-b.length);
    for (let i = 0; i < b.length; i++) {
        if (tail[i].id !== b[i].id) return false;
        if ((tail[i].edited_at || null) !== (b[i].edited_at || null)) return false;
        if (!!tail[i].is_pinned !== !!b[i].is_pinned) return false;
    }
    return true;
}

async function loadOlderMessages() {
    if (state.loadingOlder || !state.hasMoreOlder || !state.messages.length) return;
    state.loadingOlder = true;
    const chatId = state.activeChatId;
    const box = el("messages");
    const oldHeight = box.scrollHeight, oldTop = box.scrollTop;

    const loader = document.createElement("div");
    loader.className = "load-more";
    loader.innerHTML = `<span class="spinner sm"></span>`;
    box.prepend(loader);

    try {
        const before = state.messages[0].created_at;
        const rows = await rpc("messages_page", { _chat: chatId, _before: before, _limit: PAGE_SIZE });
        if (chatId !== state.activeChatId) return;
        const older = (rows || []).slice().reverse();
        state.hasMoreOlder = (rows || []).length >= PAGE_SIZE;
        if (older.length) {
            state.messages = older.concat(state.messages);
            await loadReactionsFor(older);
            await cacheProfiles(older.map(m => m.sender_id));
            renderMessages();
            // Сохраняем положение прокрутки, чтобы лента не «прыгала».
            const newHeight = box.scrollHeight;
            box.scrollTop = newHeight - oldHeight + oldTop;
        }
    } catch (err) { console.error(err); }
    finally {
        loader.remove();
        state.loadingOlder = false;
    }
}

async function loadReactionsFor(list) {
    const ids = list.map(m => m.id).filter(id => !String(id).startsWith("temp_"));
    if (!ids.length) return;
    try {
        const data = await query(() => sb.from("message_reactions").select("*").in("message_id", ids));
        (data || []).forEach(r => {
            const arr = state.reactionsByMsg[r.message_id] || (state.reactionsByMsg[r.message_id] = []);
            if (!arr.some(x => x.id === r.id)) arr.push(r);
        });
    } catch (_) {}
}

async function cacheProfiles(ids) {
    const missing = [...new Set(ids)].filter(id => id && !state.profilesCache[id]);
    if (!missing.length) return;
    try {
        const data = await query(() => sb.from("profiles").select("id,username,handle,avatar_url,last_seen,status_text").in("id", missing));
        (data || []).forEach(p => { state.profilesCache[p.id] = p; });
    } catch (_) {}
}

// Участники чата: нужны для «кто прочитал» в группах и для подсказки @имя.
// Одна функция базы вместо двух запросов (участники + профили к ним).
async function loadMembers(chatId, force) {
    if (!chatId) return [];
    if (!force && state.members[chatId]) return state.members[chatId];
    try {
        const rows = await rpc("chat_members", { _chat: chatId }, { tries: 1 });
        state.members[chatId] = rows || [];
        (rows || []).forEach(p => {
            state.profilesCache[p.user_id] = Object.assign(state.profilesCache[p.user_id] || {}, {
                id: p.user_id, username: p.username, handle: p.handle,
                avatar_url: p.avatar_url, last_seen: p.last_seen
            });
        });
        return state.members[chatId];
    } catch (_) { return state.members[chatId] || []; }
}

async function loadPinned(chatId) {
    try {
        const rows = await rpc("pinned_messages", { _chat: chatId });
        if (chatId !== state.activeChatId) return;
        state.pinned = rows || [];
        renderPinnedBar();
    } catch (_) {}
}

/* ---- Отрисовка ленты ---- */
function renderMessages() {
    const box = el("messages");
    if (!box) return;
    if (!state.messages.length) {
        box.innerHTML = `<div class="empty-chat">
            <div class="empty-chat-ico">👋</div>
            <p>${isSavedMessages(activeEntry()) ? "Здесь можно хранить заметки, ссылки и файлы для себя." : "Пока нет сообщений — поздоровайтесь!"}</p>
        </div>`;
        return;
    }
    state.messages.sort((a, b) => new Date(a.created_at) - new Date(b.created_at));

    const entry = activeEntry();
    const isGroup = !!(entry && entry.is_group);
    let html = "";
    let lastDay = "";
    let prevSender = null;
    let unreadDrawn = false;
    const unreadFrom = state.firstUnreadAt ? new Date(state.firstUnreadAt).getTime() : null;

    if (state.hasMoreOlder) html += `<div class="load-more"><button class="link-btn" data-loadmore>Показать более раннее</button></div>`;

    for (const m of state.messages) {
        const day = fmtDay(m.created_at);
        if (day !== lastDay) {
            html += `<div class="day-sep"><span>${day}</span></div>`;
            lastDay = day; prevSender = null;
        }
        if (!unreadDrawn && unreadFrom && new Date(m.created_at).getTime() > unreadFrom && m.sender_id !== state.user.id) {
            html += `<div class="unread-sep"><span>Новые сообщения</span></div>`;
            unreadDrawn = true; prevSender = null;
        }
        html += renderMessageHTML(m, isGroup, prevSender === m.sender_id && !m.system_kind);
        prevSender = m.system_kind ? null : m.sender_id;
    }
    box.innerHTML = html;
    wireMessageEvents(box);
    const lm = box.querySelector("[data-loadmore]");
    if (lm) lm.addEventListener("click", loadOlderMessages);
}

function renderMessageHTML(m, isGroup, grouped) {
    // Системные сообщения («вступил в группу») — по центру, без пузыря.
    if (m.system_kind) {
        return `<div class="system-msg" data-msg-row="${m.id}"><span>${esc(m.text || "")}</span></div>`;
    }

    const out = m.sender_id === state.user.id;
    const sender = state.profilesCache[m.sender_id] || {};
    const selected = state.selection.has(m.id) ? " selected" : "";

    let replyHTML = "";
    if (m.reply_to_message_id) {
        const rep = state.messages.find(x => x.id === m.reply_to_message_id);
        const repName = rep
            ? (rep.sender_id === state.user.id ? "Вы" : (state.profilesCache[rep.sender_id]?.username || "Пользователь"))
            : "Сообщение";
        const repText = rep ? snippetForMessage(rep) : "Сообщение удалено";
        replyHTML = `<div class="reply-quote" data-jump="${m.reply_to_message_id}">
            <div class="reply-quote-name">${esc(repName)}</div>
            <div class="reply-quote-text">${esc(clip(repText, 90))}</div></div>`;
    }

    let fwdHTML = "";
    if (m.forwarded_from) {
        const origName = (m.forwarded_from === state.user.id) ? "" : (state.profilesCache[m.forwarded_from]?.username || "");
        fwdHTML = `<div class="fwd-label">↪ Переслано${origName ? ` от <b>${esc(origName)}</b>` : ""}</div>`;
    }

    let bodyHTML = "";
    let mediaClass = "";
    if (m.media_url) {
        mediaClass = " has-media";
        if (m.media_type === "image") {
            const meta = m.media_meta || {};
            const ratio = (meta.w && meta.h) ? ` style="aspect-ratio:${meta.w}/${meta.h}"` : "";
            bodyHTML += `<div class="bubble-media"${ratio}><img src="${esc(m.media_url)}" alt="" loading="lazy" data-lightbox="image"></div>`;
        } else if (m.media_type === "video") {
            bodyHTML += `<div class="bubble-media"><video src="${esc(m.media_url)}" controls preload="metadata"></video></div>`;
        } else if (m.media_type === "voice" || m.media_type === "audio") {
            bodyHTML += renderVoiceHTML(m);
        } else {
            const nm = (m.media_meta && m.media_meta.name) || "Вложение";
            const sz = (m.media_meta && m.media_meta.size) ? ` <span class="file-size">${fmtBytes(m.media_meta.size)}</span>` : "";
            bodyHTML += `<div class="bubble-file"><a href="${esc(m.media_url)}" target="_blank" rel="noopener">📎 ${esc(nm)}</a>${sz}</div>`;
        }
    }
    if (m.text) {
        const jumbo = isJumboEmoji(m.text) && !m.media_url ? " jumbo" : "";
        bodyHTML += `<div class="bubble-text${jumbo}">${linkify(m.text)}</div>`;
    }
    const meMention = (!out && mentionsMe(m.text)) ? " mentions-me" : "";

    let meta = `<span class="bubble-time">${fmtTime(m.created_at)}</span>`;
    if (m.edited_at) meta = `<span class="edited-mark" title="Изменено">изм.</span>` + meta;
    if (m.is_pinned) meta = `<span class="pin-mark" title="Закреплено">📌</span>` + meta;
    if (out) {
        const entry = activeEntry();
        meta += checkIcon(outgoingStatus(m, entry), checkHint(m, entry));
    }

    const reactions = state.reactionsByMsg[m.id] || [];
    let reactHTML = "";
    if (reactions.length) {
        const byEmoji = {};
        reactions.forEach(r => { (byEmoji[r.emoji] ||= []).push(r); });
        reactHTML = `<div class="reactions">` + Object.entries(byEmoji).map(([emoji, arr]) => {
            const mine = arr.some(r => r.user_id === state.user.id) ? " mine" : "";
            return `<span class="reaction-pill${mine}" data-react-emoji="${esc(emoji)}" data-msg="${m.id}">${emoji}<span class="rc">${arr.length}</span></span>`;
        }).join("") + `</div>`;
    }

    const senderName = (isGroup && !out && !grouped)
        ? `<div class="bubble-sender" data-openuser="${m.sender_id}" style="color:${avatarTint(m.sender_id)}">${esc(sender.username || "Пользователь")}</div>` : "";
    const groupAvatar = (isGroup && !out && !grouped)
        ? `<span class="msg-avatar" data-openuser="${m.sender_id}">${avatarHTML(sender.avatar_url, sender.username, "xs", m.sender_id)}</span>` : "";

    return `
    <div class="msg-row ${out ? "out" : "in"}${grouped ? " grouped" : ""}${selected}" data-msg-row="${m.id}">
        ${state.selectMode ? `<span class="sel-box${selected ? " on" : ""}" data-select="${m.id}"></span>` : ""}
        ${groupAvatar}
        <div class="bubble${mediaClass}${meMention}" data-bubble="${m.id}">
            ${senderName}${fwdHTML}${replyHTML}${bodyHTML}
            <span class="bubble-meta">${meta}</span>
            <button class="msg-actions-btn" data-menu="${m.id}" title="Действия">
                <svg viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg>
            </button>
        </div>
        <div class="react-holder" data-holder="${m.id}">${reactHTML}</div>
    </div>`;
}

function renderVoiceHTML(m) {
    let bars = "";
    const idStr = String(m.id);
    for (let i = 0; i < 34; i++) {
        const seed = (idStr.charCodeAt(i % idStr.length) * (i + 3)) % 100;
        bars += `<span style="height:${20 + (seed % 70)}%"></span>`;
    }
    const dur = (m.media_meta && m.media_meta.duration) ? fmtDuration(m.media_meta.duration) : "0:00";
    return `
    <div class="voice-player" data-voice="${esc(m.media_url)}" data-msg="${m.id}">
        <button class="voice-play-btn" data-vplay><svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg></button>
        <div class="voice-wave" data-vwave>${bars}</div>
        <span class="voice-time" data-vtime>${dur}</span>
        <button class="voice-speed" data-vspeed title="Скорость">1×</button>
    </div>`;
}

function wireMessageEvents(root) {
    root = root || document;
    $$("[data-lightbox]", root).forEach(node => node.addEventListener("click", () => openLightbox(node.src, "image")));
    $$(".bubble-media video", root).forEach(v => v.addEventListener("dblclick", () => openLightbox(v.src, "video")));
    $$("[data-jump]", root).forEach(node => node.addEventListener("click", () => jumpToMessage(node.dataset.jump)));
    $$("[data-openuser]", root).forEach(node => node.addEventListener("click", (e) => {
        e.stopPropagation(); openUserProfile(node.dataset.openuser);
    }));
    $$("[data-mention]", root).forEach(node => node.addEventListener("click", (e) => {
        e.stopPropagation(); openUserProfileByKey(node.dataset.mention);
    }));
    $$("[data-menu]", root).forEach(btn => btn.addEventListener("click", (e) => {
        e.stopPropagation();
        openContextMenu(btn.dataset.menu, e.clientX, e.clientY);
    }));
    $$("[data-react-emoji]", root).forEach(pill => pill.addEventListener("click", () => {
        toggleReaction(pill.dataset.msg, pill.dataset.reactEmoji);
    }));
    $$("[data-select]", root).forEach(box => box.addEventListener("click", (e) => {
        e.stopPropagation(); toggleSelect(box.dataset.select);
    }));
    $$(".check.failed", root).forEach(c => c.addEventListener("click", (e) => {
        e.stopPropagation(); flushQueue(true);
    }));

    $$("[data-bubble]", root).forEach(b => {
        const id = b.dataset.bubble;
        b.addEventListener("click", () => { if (state.selectMode) toggleSelect(id); });
        b.addEventListener("contextmenu", (e) => { e.preventDefault(); openContextMenu(id, e.clientX, e.clientY); });
        b.addEventListener("dblclick", () => toggleReaction(id, "❤️"));

        let lpTimer, startX = 0, startY = 0, swiped = false;
        b.addEventListener("touchstart", (e) => {
            const t = e.touches[0];
            startX = t.clientX; startY = t.clientY; swiped = false;
            lpTimer = setTimeout(() => { vibrate(30); openContextMenu(id, t.clientX, t.clientY); }, 480);
        }, { passive: true });
        b.addEventListener("touchmove", (e) => {
            const t = e.touches[0];
            const dx = t.clientX - startX, dy = t.clientY - startY;
            if (Math.abs(dx) > 12 || Math.abs(dy) > 12) clearTimeout(lpTimer);
            // Свайп вправо на 60 px — быстрый ответ (как в WhatsApp).
            if (!swiped && dx > 60 && Math.abs(dy) < 40) {
                swiped = true; vibrate(20); startReply(id);
                b.classList.add("swipe-hint");
                setTimeout(() => b.classList.remove("swipe-hint"), 250);
            }
        }, { passive: true });
        b.addEventListener("touchend", () => clearTimeout(lpTimer));
    });

    $$("[data-voice]", root).forEach(setupVoicePlayer);
}

function appendMessageRow(m, animate) {
    const box = el("messages");
    if (!box) return;
    if (!box.querySelector("[data-msg-row]")) { renderMessages(); return; }

    const entry = activeEntry();
    const isGroup = !!(entry && entry.is_group);
    const idx = state.messages.findIndex(x => x.id === m.id);
    const prev = idx > 0 ? state.messages[idx - 1] : null;
    const needDay = !prev || fmtDay(prev.created_at) !== fmtDay(m.created_at);
    const grouped = !!prev && !needDay && prev.sender_id === m.sender_id && !prev.system_kind && !m.system_kind;

    if (needDay) {
        const sep = document.createElement("div");
        sep.className = "day-sep";
        sep.innerHTML = `<span>${fmtDay(m.created_at)}</span>`;
        box.appendChild(sep);
    }

    const tmp = document.createElement("div");
    tmp.innerHTML = renderMessageHTML(m, isGroup, grouped);
    if (animate) {
        const bub = tmp.querySelector(".bubble");
        if (bub) bub.classList.add("animate-in");
    }
    wireMessageEvents(tmp);
    while (tmp.firstChild) box.appendChild(tmp.firstChild);
}

function replaceMessageNode(id, m) {
    const row = document.querySelector('[data-msg-row="' + CSS.escape(String(id)) + '"]');
    if (!row) return false;
    const entry = activeEntry();
    const isGroup = !!(entry && entry.is_group);
    const grouped = row.classList.contains("grouped");
    const tmp = document.createElement("div");
    tmp.innerHTML = renderMessageHTML(m, isGroup, grouped);
    wireMessageEvents(tmp);
    const newRow = tmp.querySelector("[data-msg-row]");
    if (newRow) row.replaceWith(newRow);
    return true;
}

function removeMessageNode(id) {
    const row = document.querySelector('[data-msg-row="' + CSS.escape(String(id)) + '"]');
    if (row) row.remove();
}

function scrollMessagesToBottom(force, smooth) {
    const box = el("messages");
    if (!box) return;
    const nearBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 200;
    if (force || nearBottom) {
        if (smooth && typeof box.scrollTo === "function") box.scrollTo({ top: box.scrollHeight, behavior: "smooth" });
        else box.scrollTop = box.scrollHeight;
    }
}

async function jumpToMessage(id) {
    let row = document.querySelector(`[data-msg-row="${CSS.escape(String(id))}"] .bubble`);
    if (!row) {
        // Сообщение ещё не загружено — подгружаем историю до него.
        toast("Загружаем…", false, 1200);
        for (let i = 0; i < 8 && state.hasMoreOlder; i++) {
            await loadOlderMessages();
            row = document.querySelector(`[data-msg-row="${CSS.escape(String(id))}"] .bubble`);
            if (row) break;
        }
    }
    if (!row) { toast("Сообщение не найдено", true); return; }
    row.scrollIntoView({ behavior: "smooth", block: "center" });
    row.classList.add("highlight");
    setTimeout(() => row.classList.remove("highlight"), 1600);
}

/* ---- Панель закреплённых ---- */
function renderPinnedBar() {
    const bar = el("pinned-bar");
    if (!bar) return;
    const pinned = (state.pinned || []).filter(Boolean);
    if (!pinned.length) { hide(bar); state.pinnedIndex = 0; return; }
    if (state.pinnedIndex >= pinned.length) state.pinnedIndex = 0;
    const m = pinned[state.pinnedIndex];
    el("pinned-title").textContent = pinned.length > 1
        ? `Закреплённые (${state.pinnedIndex + 1}/${pinned.length})` : "Закреплённое сообщение";
    const who = m.sender_id === state.user.id ? "Вы" : (state.profilesCache[m.sender_id]?.username || "Пользователь");
    el("pinned-text").textContent = `${who}: ${snippetForMessage(m)}`;
    el("pinned-body").onclick = () => {
        jumpToMessage(m.id);
        if (pinned.length > 1) { state.pinnedIndex = (state.pinnedIndex + 1) % pinned.length; renderPinnedBar(); }
    };
    el("pinned-unpin").onclick = (e) => { e.stopPropagation(); togglePin(m.id, false); };
    show(bar);
}

function updateChatHeaderStatus() {
    const entry = activeEntry();
    const statusEl = el("chat-header-status");
    if (!statusEl) return;
    if (!entry) { statusEl.textContent = ""; return; }

    if (isSavedMessages(entry)) { statusEl.className = "chat-header-status"; statusEl.textContent = "только для вас"; return; }

    const typing = state.typing[entry.chat_id];
    if (typing && typing.until > Date.now()) {
        statusEl.className = "chat-header-status typing";
        statusEl.textContent = entry.is_group ? `${typing.name || "кто-то"} печатает…` : (typing.kind === "voice" ? "записывает голос��вое…" : "печатает…");
        return;
    }
    if (entry.is_group) {
        statusEl.className = "chat-header-status";
        statusEl.textContent = `${entry.member_count} ${pluralMembers(Number(entry.member_count))}`;
        return;
    }
    if (entry.blocked_by_me) { statusEl.className = "chat-header-status"; statusEl.textContent = "вы заблокировали"; return; }
    if (isOnlineEntry(entry)) { statusEl.className = "chat-header-status online"; statusEl.textContent = "в сети"; return; }
    statusEl.className = "chat-header-status";
    statusEl.textContent = entry.other_last_seen ? fmtLastSeen(entry.other_last_seen) : "";
}

// Если писать нельзя (блокировка), заменяем композер понятной плашкой.
function updateComposerAvailability() {
    const entry = activeEntry();
    const composer = el("composer");
    const blockBar = el("blocked-bar");
    if (!composer || !blockBar) return;
    if (!entry) return;
    if (entry.blocked_by_me || entry.blocked_me) {
        hide(composer); show(blockBar);
        el("blocked-text").textContent = entry.blocked_by_me
            ? "Вы заблокировали этого пользователя."
            : "Вы не можете писать этому пользователю.";
        const btn = el("blocked-unblock");
        btn.classList.toggle("hidden", !entry.blocked_by_me);
        btn.onclick = async () => {
            try { await rpc("unblock_user", { _id: entry.other_id }); await loadChats(true); updateComposerAvailability(); toast("Разблокирован"); }
            catch (e) { toast(errRu(e), true); }
        };
    } else { show(composer); hide(blockBar); }
}

/* ------------------------------------------------------------------ *
 *  10. КОМПОЗЕР И ОЧЕРЕДЬ ОТПРАВКИ
 *      Сообщение сначала попадает в очередь на диске, и только потом
 *      уходит на сервер. Если связь пропала или сервер ответил ошибкой,
 *      отправка повторяется сама, а сообщение не теряется — именно этого
 *      не хватало, когда переписка «вставала» и приходилось чистить чат.
 * ------------------------------------------------------------------ */
let outbox = [];
let flushing = false;
let flushTimer = null;

function queueKey() { return "centr_queue_" + (state.user ? state.user.id : "anon"); }

function saveQueue() {
    try { localStorage.setItem(queueKey(), JSON.stringify(outbox.slice(0, 200))); } catch (_) {}
}

function loadQueue() {
    try {
        const raw = localStorage.getItem(queueKey());
        outbox = raw ? (JSON.parse(raw) || []) : [];
    } catch (_) { outbox = []; }
    if (outbox.length) {
        toast(`Досылаем ${outbox.length} ${pluralRu(outbox.length, "сообщение", "сообщения", "сообщений")}…`);
        scheduleFlush(600);
    }
}

function scheduleFlush(delay) {
    clearTimeout(flushTimer);
    flushTimer = setTimeout(() => flushQueue(), delay || 0);
}

// Поставить сообщение в очередь и сразу показать его в ленте.
function enqueueMessage(payload) {
    const tempId = "temp_" + Date.now() + "_" + Math.random().toString(36).slice(2, 8);
    const item = {
        tempId,
        client_id: newUuid(),
        chat_id: payload.chat_id || state.activeChatId,
        text: payload.text || null,
        media_url: payload.media_url || null,
        media_type: payload.media_type || null,
        media_meta: payload.media_meta || null,
        reply_to_message_id: payload.reply_to_message_id ?? (state.replyTo ? state.replyTo.id : null),
        forwarded_from: payload.forwarded_from || null,
        created_at: new Date().toISOString(),
        tries: 0
    };
    outbox.push(item);
    saveQueue();

    if (item.chat_id === state.activeChatId) {
        const ghost = {
            id: tempId, chat_id: item.chat_id, sender_id: state.user.id,
            client_id: item.client_id,
            created_at: item.created_at, text: item.text,
            media_url: item.media_url, media_type: item.media_type, media_meta: item.media_meta,
            reply_to_message_id: item.reply_to_message_id,
            forwarded_from: item.forwarded_from,
            is_pinned: false, _pending: true
        };
        state.messages.push(ghost);
        appendMessageRow(ghost, true);
        scrollMessagesToBottom(true, true);
        resetScrollBadge();
    }
    state.replyTo = null;
    updateReplyPreview();
    scheduleFlush(0);
    return tempId;
}

async function flushQueue(manual) {
    if (flushing || !state.user) return;
    if (!outbox.length) return;
    flushing = true;

    while (outbox.length) {
        const item = outbox[0];
        if (manual) item.tries = 0;
        try {
            // Отправляем через функцию базы и передаём свой номер сообщения.
            // Если связь оборвётся после того, как сервер сообщение примет,
            // повторная попытка вернёт то же самое сообщение, а не создаст
            // вторую копию — раньше на плохой связи так и получалось.
            const rows = await rpc("send_message", {
                _chat: item.chat_id,
                _text: item.text,
                _media_url: item.media_url,
                _media_type: item.media_type,
                _media_meta: item.media_meta,
                _reply_to: item.reply_to_message_id,
                _forwarded_from: item.forwarded_from,
                _client_id: item.client_id || null,
            }, { tries: 1 });
            const data = Array.isArray(rows) ? rows[0] : rows;
            if (!data || !data.id) throw new Error("Сервер не вернул сообщение");

            outbox.shift(); saveQueue();
            setConnState(true);

            // Заменяем «призрак» настоящим сообщением.
            const idx = state.messages.findIndex(x => x.id === item.tempId);
            if (idx >= 0) {
                if (state.messages.some(x => x.id === data.id && x.id !== item.tempId)) {
                    state.messages.splice(idx, 1);
                    removeMessageNode(item.tempId);
                } else {
                    state.messages[idx] = data;
                    replaceMessageNode(item.tempId, data);
                }
            } else if (data.chat_id === state.activeChatId && !state.messages.some(x => x.id === data.id)) {
                state.messages.push(data);
                appendMessageRow(data, false);
            }
            playSentSound();
            applyIncomingToList(data, true);
        } catch (err) {
            item.tries = (item.tries || 0) + 1;
            const msg = String(err && err.message || "");
            const permanent = msg.includes("CENTR_BLOCKED") || msg.includes("CENTR_ONLY_FRIENDS") ||
                              msg.includes("CENTR_FORBIDDEN") || msg.includes("row-level security") ||
                              msg.includes("violates foreign key");

            if (permanent) {
                // Отправить не получится никогда — убираем из очереди и объясняем причину.
                outbox.shift(); saveQueue();
                const idx = state.messages.findIndex(x => x.id === item.tempId);
                if (idx >= 0) { state.messages.splice(idx, 1); removeMessageNode(item.tempId); }
                toast(errRu(err), true, 5000);
                continue;
            }

            // Временная беда (сеть, антифлуд, тайм-аут) — помечаем и пробуем позже.
            const ghostIdx = state.messages.findIndex(x => x.id === item.tempId);
            if (ghostIdx >= 0 && item.tries >= 2) {
                state.messages[ghostIdx]._pending = false;
                state.messages[ghostIdx]._failed = true;
                replaceMessageNode(item.tempId, state.messages[ghostIdx]);
            }
            if (item.tries === 2) toast(errRu(err), true, 4000);
            setConnState(false, "Сообщение не ушло — пробуем снова…");
            flushing = false;
            scheduleFlush(Math.min(30000, 1500 * Math.pow(2, Math.min(item.tries, 4))));
            return;
        }
    }
    flushing = false;
    saveQueue();
}

/* ---- Черновики: сохраняются на сервере, видны на другом устройстве ---- */
const saveDraftDebounced = debounce(() => saveDraft(state.activeChatId), 900);

async function saveDraft(chatId) {
    if (!chatId) return;
    const input = el("message-input");
    if (!input) return;
    const val = state.editing ? "" : input.value.trim();
    const entry = getChatEntry(chatId);
    if (entry && (entry.draft || "") === val) return;
    if (entry) entry.draft = val || null;
    try { await rpc("set_chat_flags", { _chat: chatId, _draft: val }, { tries: 1 }); } catch (_) {}
}

async function flushDrafts() { await saveDraft(state.activeChatId); }

function setupComposer() {
    const input = el("message-input");

    input.addEventListener("input", () => {
        input.style.height = "auto";
        input.style.height = Math.min(input.scrollHeight, 140) + "px";
        const hasText = input.value.trim().length > 0;
        el("send-btn").classList.toggle("hidden", !hasText);
        el("mic-btn").classList.toggle("hidden", hasText);
        broadcastTyping();
        saveDraftDebounced();
        updateMentionBox();
        const counter = el("char-counter");
        if (counter) {
            const left = MAX_TEXT_LEN - input.value.length;
            counter.textContent = left < 300 ? String(left) : "";
            counter.classList.toggle("hidden", left >= 300);
        }
    });

    input.addEventListener("keydown", (e) => {
        // Подсказка упоминаний забирает стрелки и Enter себе.
        if (mentionKeydown(e)) { e.preventDefault(); return; }
        if (e.key === "Enter" && !e.shiftKey && !e.ctrlKey) { e.preventDefault(); sendText(); }
        if (e.key === "Escape") { if (state.editing) cancelEdit(true); else if (state.replyTo) { state.replyTo = null; updateReplyPreview(); } }
        // Стрелка вверх на пустом поле — правка последнего своего сообщения.
        if (e.key === "ArrowUp" && !input.value) {
            const mine = state.messages.filter(m => m.sender_id === state.user.id && m.text && !m._pending);
            if (mine.length) { e.preventDefault(); startEdit(mine[mine.length - 1].id); }
        }
    });

    // Вставка картинки из буфера обмена (Ctrl+V) — удобно на компьютере.
    input.addEventListener("paste", (e) => {
        const items = e.clipboardData && e.clipboardData.items;
        if (!items) return;
        for (const it of items) {
            if (it.type && it.type.startsWith("image/")) {
                const file = it.getAsFile();
                if (file) { e.preventDefault(); openImageComposer(file); return; }
            }
        }
    });

    input.addEventListener("blur", () => setTimeout(hideMentionBox, 120));
    el("send-btn").addEventListener("click", sendText);

    el("attach-btn").addEventListener("click", () => el("file-input").click());
    el("file-input").addEventListener("change", (e) => {
        const files = Array.from(e.target.files || []);
        e.target.value = "";
        if (!files.length) return;
        if (files.length === 1 && files[0].type.startsWith("image/")) openImageComposer(files[0]);
        else files.forEach(f => sendMedia(f));
    });

    el("camera-btn").addEventListener("click", () => el("camera-input").click());
    el("camera-input").addEventListener("change", (e) => {
        const file = e.target.files[0];
        e.target.value = "";
        if (file) openImageComposer(file);
    });

    // Перетаскивание файлов в окно чата.
    const dropZone = el("chat-view");
    if (dropZone) {
        ["dragenter", "dragover"].forEach(ev => dropZone.addEventListener(ev, (e) => {
            e.preventDefault(); dropZone.classList.add("dragging");
        }));
        ["dragleave", "drop"].forEach(ev => dropZone.addEventListener(ev, (e) => {
            e.preventDefault(); dropZone.classList.remove("dragging");
        }));
        dropZone.addEventListener("drop", (e) => {
            const files = Array.from(e.dataTransfer.files || []);
            if (files.length === 1 && files[0].type.startsWith("image/")) openImageComposer(files[0]);
            else files.forEach(f => sendMedia(f));
        });
    }

    buildEmojiPicker();
    setupImageComposer();
    el("emoji-btn").addEventListener("click", (e) => {
        e.stopPropagation();
        el("emoji-picker").classList.toggle("hidden");
    });
    setupRecorderControls();
}

/* ------------------------------------------------------------------ *
 *  10b. ПОДСКАЗКА УПОМИНАНИЙ @имя
 *       В группе при наборе @ показываем список участников. Без этого
 *       упоминания были бы бесполезны: @ID никто не помнит наизусть.
 * ------------------------------------------------------------------ */
let mentionState = null;

function hideMentionBox() {
    mentionState = null;
    const box = el("mention-box");
    if (box) { hide(box); box.innerHTML = ""; }
}

// Ищем @слово прямо перед курсором.
function mentionQueryAtCaret(input) {
    const pos = input.selectionStart ?? input.value.length;
    const before = input.value.slice(0, pos);
    const m = before.match(/(^|[\s(])@([a-zA-Zа-яА-ЯёЁ0-9_]{0,24})$/);
    if (!m) return null;
    return { term: m[2] || "", start: pos - (m[2] || "").length - 1, end: pos };
}

async function updateMentionBox() {
    const entry = activeEntry();
    const input = el("message-input");
    const box = el("mention-box");
    if (!box || !input) return;
    if (!entry || !entry.is_group) { hideMentionBox(); return; }

    const q = mentionQueryAtCaret(input);
    if (!q) { hideMentionBox(); return; }

    const members = await loadMembers(entry.chat_id);
    const term = q.term.toLowerCase();
    let list = (members || []).filter(p => p.user_id !== state.user.id && p.handle);
    if (term) {
        list = list.filter(p => (p.handle || "").toLowerCase().includes(term) ||
                                (p.username || "").toLowerCase().includes(term));
    }
    list = list.slice(0, 6);
    if (!list.length) { hideMentionBox(); return; }

    mentionState = { ...q, list, active: 0 };
    paintMentionBox();
    show(box);
}

function paintMentionBox() {
    const box = el("mention-box");
    if (!box || !mentionState) return;
    box.innerHTML = mentionState.list.map((p, i) => `
        <button type="button" class="mention-item${i === mentionState.active ? " active" : ""}" data-mi="${i}">
            ${avatarHTML(p.avatar_url, p.username, "xs", p.user_id)}
            <span class="mention-name">${esc(p.username || "Пользователь")}</span>
            <span class="mention-handle">@${esc(p.handle)}</span>
        </button>`).join("");
    box.querySelectorAll("[data-mi]").forEach(b => {
        b.addEventListener("mousedown", (e) => { e.preventDefault(); pickMention(Number(b.dataset.mi)); });
    });
}

function pickMention(idx) {
    if (!mentionState) return;
    const p = mentionState.list[idx];
    if (!p) return;
    const input = el("message-input");
    const before = input.value.slice(0, mentionState.start);
    const after = input.value.slice(mentionState.end);
    const insert = "@" + p.handle + " ";
    input.value = before + insert + after;
    const pos = before.length + insert.length;
    hideMentionBox();
    input.focus();
    try { input.setSelectionRange(pos, pos); } catch (_) {}
    input.dispatchEvent(new Event("input"));
}

// Стрелки и Enter внутри подсказки. Возвращает true, если событие перехвачено.
function mentionKeydown(e) {
    if (!mentionState) return false;
    if (e.key === "ArrowDown") {
        mentionState.active = (mentionState.active + 1) % mentionState.list.length;
        paintMentionBox(); return true;
    }
    if (e.key === "ArrowUp") {
        mentionState.active = (mentionState.active - 1 + mentionState.list.length) % mentionState.list.length;
        paintMentionBox(); return true;
    }
    if (e.key === "Enter" || e.key === "Tab") { pickMention(mentionState.active); return true; }
    if (e.key === "Escape") { hideMentionBox(); return true; }
    return false;
}

/* ---- Эмодзи: с историей частых ---- */
function recentEmojis() {
    try { return JSON.parse(localStorage.getItem("centr_recent_emoji") || "[]"); } catch (_) { return []; }
}
function pushRecentEmoji(e) {
    let list = recentEmojis().filter(x => x !== e);
    list.unshift(e);
    list = list.slice(0, 32);
    localStorage.setItem("centr_recent_emoji", JSON.stringify(list));
    EMOJI_CATEGORIES[0].emojis = list;
}

function buildEmojiPicker() {
    EMOJI_CATEGORIES[0].emojis = recentEmojis();
    const picker = el("emoji-picker");
    picker.innerHTML = `
        <div class="emoji-tabs" id="emoji-tabs">
            ${EMOJI_CATEGORIES.map((c, i) => `<button type="button" class="emoji-tab${i === 1 ? " active" : ""}" data-cat="${i}" title="${esc(c.name)}">${c.icon}</button>`).join("")}
        </div>
        <div class="emoji-grid" id="emoji-grid"></div>`;

    const grid = picker.querySelector("#emoji-grid");
    const renderCat = (idx) => {
        const cat = EMOJI_CATEGORIES[idx] || EMOJI_CATEGORIES[1];
        const list = idx === 0 ? recentEmojis() : cat.emojis;
        grid.innerHTML = list.length
            ? list.map(e => `<button type="button">${e}</button>`).join("")
            : `<div class="emoji-empty">Здесь появятся эмодзи, которыми вы часто пользуетесь.</div>`;
        grid.querySelectorAll("button").forEach(b => b.addEventListener("click", () => insertEmoji(b.textContent)));
        grid.scrollTop = 0;
    };
    picker.querySelectorAll(".emoji-tab").forEach(tab => tab.addEventListener("click", () => {
        picker.querySelectorAll(".emoji-tab").forEach(t => t.classList.toggle("active", t === tab));
        renderCat(Number(tab.dataset.cat));
    }));
    renderCat(1);
}

function insertEmoji(emoji) {
    pushRecentEmoji(emoji);
    const input = el("message-input");
    const start = input.selectionStart ?? input.value.length;
    const end = input.selectionEnd ?? input.value.length;
    input.value = input.value.slice(0, start) + emoji + input.value.slice(end);
    const pos = start + emoji.length;
    input.dispatchEvent(new Event("input"));
    input.focus();
    try { input.setSelectionRange(pos, pos); } catch (_) {}
}

function sendText() {
    if (state.editing) { commitEdit(); return; }
    const input = el("message-input");
    let text = input.value.trim();
    if (!text || !state.activeChatId) return;
    if (text.length > MAX_TEXT_LEN) { toast("Слишком длинное сообщение", true); return; }
    input.value = "";
    input.style.height = "auto";
    hideMentionBox();
    input.dispatchEvent(new Event("input"));
    stopTypingBroadcast();
    saveDraft(state.activeChatId);
    enqueueMessage({ text });
}

async function sendMedia(file) {
    if (!state.activeChatId) { toast("Сначала откройте чат", true); return; }

    const maxMb = Number(CFG.MAX_UPLOAD_MB) || 25;
    if (file.size > maxMb * 1024 * 1024) {
        toast(`Файл ${(file.size / 1048576).toFixed(1)} МБ больше лимита ${maxMb} МБ.`, true, 5000);
        return;
    }

    let toSend = file;
    let type = file.type.startsWith("image/") ? "image"
             : file.type.startsWith("video/") ? "video"
             : file.type.startsWith("audio/") ? "audio" : "file";

    // Размеры картинки нужны, чтобы место под неё в ленте занялось сразу.
    // Без этого при загрузке фото вёрстка дёргалась, а прокрутка прыгала.
    let dims = null;
    if (type === "image") {
        dims = await imageSize(file);
        toSend = await compressImage(file);
    }

    const typeRu = { image: "фото", video: "видео", audio: "аудио", file: "файл" }[type];
    const prog = showUploadProgress(`Загрузка (${typeRu})`);
    try {
        const url = await uploadToBucket(CFG.MEDIA_BUCKET, toSend, state.activeChatId, (p) => prog.update(p));
        prog.finish();
        const meta = { size: toSend.size, name: file.name || null };
        if (dims) { meta.w = dims.w; meta.h = dims.h; }
        enqueueMessage({ media_url: url, media_type: type, media_meta: meta });
    } catch (err) {
        console.error(err);
        prog.fail(errRu(err));
    }
}

// Узнать ширину и высоту изображения, не загружая его целиком в память.
function imageSize(file) {
    return new Promise((resolve) => {
        if (!file || !file.type || !file.type.startsWith("image/")) { resolve(null); return; }
        const img = new Image();
        const url = URL.createObjectURL(file);
        const done = (val) => { try { URL.revokeObjectURL(url); } catch (_) {} resolve(val); };
        img.onload = () => done({ w: img.naturalWidth, h: img.naturalHeight });
        img.onerror = () => done(null);
        img.src = url;
        setTimeout(() => done(null), 3000);
    });
}

/* ------------------------------------------------------------------ *
 *  11. ФОТО-РЕДАКТОР И ГОЛОСОВЫЕ
 * ------------------------------------------------------------------ */
let imgComposer = null;

function openImageComposer(file) {
    if (!state.activeChatId) { toast("Сначала откройте чат", true); return; }
    if (!file || !file.type.startsWith("image/")) { sendMedia(file); return; }

    const maxMb = Number(CFG.MAX_UPLOAD_MB) || 25;
    if (file.size > maxMb * 1024 * 1024) { toast(`Файл больше лимита ${maxMb} МБ.`, true); return; }

    const img = el("imgsend-img");
    const url = URL.createObjectURL(file);
    imgComposer = { file, url, cropOn: false, rect: null, dispW: 0, dispH: 0, drag: null };
    el("imgsend-caption").value = "";
    hide(el("imgsend-crop"));
    hide(el("imgsend-resetbtn"));
    img.onload = () => requestAnimationFrame(() => {
        imgComposer.dispW = img.clientWidth;
        imgComposer.dispH = img.clientHeight;
    });
    img.src = url;
    openModal("imgsend-modal");
}

function closeImageComposer() {
    if (imgComposer) { try { URL.revokeObjectURL(imgComposer.url); } catch (_) {} }
    imgComposer = null;
    el("imgsend-img").removeAttribute("src");
    closeModal("imgsend-modal");
}

function paintCrop() {
    const c = imgComposer; if (!c || !c.rect) return;
    const box = el("imgsend-crop");
    box.style.left = c.rect.x + "px"; box.style.top = c.rect.y + "px";
    box.style.width = c.rect.w + "px"; box.style.height = c.rect.h + "px";
}

function enableCrop() {
    const c = imgComposer; if (!c) return;
    c.dispW = el("imgsend-img").clientWidth;
    c.dispH = el("imgsend-img").clientHeight;
    const w = Math.round(c.dispW * 0.8), h = Math.round(c.dispH * 0.8);
    c.rect = { x: Math.round((c.dispW - w) / 2), y: Math.round((c.dispH - h) / 2), w, h };
    c.cropOn = true;
    show(el("imgsend-crop")); show(el("imgsend-resetbtn"));
    paintCrop();
}

function disableCrop() {
    const c = imgComposer; if (!c) return;
    c.cropOn = false; c.rect = null;
    hide(el("imgsend-crop")); hide(el("imgsend-resetbtn"));
}

function clampRect() {
    const c = imgComposer; if (!c || !c.rect) return;
    const MIN = 30;
    let r = c.rect;
    r.w = Math.max(MIN, Math.min(r.w, c.dispW));
    r.h = Math.max(MIN, Math.min(r.h, c.dispH));
    r.x = Math.max(0, Math.min(r.x, c.dispW - r.w));
    r.y = Math.max(0, Math.min(r.y, c.dispH - r.h));
}

function setupImageComposer() {
    const stage = el("imgsend-stage");
    const cropBox = el("imgsend-crop");

    el("imgsend-close").addEventListener("click", closeImageComposer);
    el("imgsend-cancel").addEventListener("click", closeImageComposer);
    el("imgsend-cropbtn").addEventListener("click", () => {
        if (!imgComposer) return;
        imgComposer.cropOn ? disableCrop() : enableCrop();
    });
    el("imgsend-resetbtn").addEventListener("click", disableCrop);
    el("imgsend-send").addEventListener("click", doSendImage);
    el("imgsend-caption").addEventListener("keydown", (e) => { if (e.key === "Enter") doSendImage(); });

    const onDown = (e) => {
        const c = imgComposer;
        if (!c || !c.cropOn || !c.rect) return;
        const rect = el("imgsend-img").getBoundingClientRect();
        const px = e.clientX - rect.left, py = e.clientY - rect.top;
        const handle = e.target.closest("[data-h]");
        c.drag = { mode: handle ? "resize" : "move", corner: handle ? handle.dataset.h : null,
                   sx: px, sy: py, start: { ...c.rect } };
        try { stage.setPointerCapture(e.pointerId); } catch (_) {}
        e.preventDefault();
    };
    const onMove = (e) => {
        const c = imgComposer;
        if (!c || !c.drag || !c.rect) return;
        const rect = el("imgsend-img").getBoundingClientRect();
        const px = e.clientX - rect.left, py = e.clientY - rect.top;
        const dx = px - c.drag.sx, dy = py - c.drag.sy;
        const s = c.drag.start;
        if (c.drag.mode === "move") { c.rect.x = s.x + dx; c.rect.y = s.y + dy; }
        else {
            const co = c.drag.corner;
            if (co === "tl") { c.rect.x = s.x + dx; c.rect.y = s.y + dy; c.rect.w = s.w - dx; c.rect.h = s.h - dy; }
            else if (co === "tr") { c.rect.y = s.y + dy; c.rect.w = s.w + dx; c.rect.h = s.h - dy; }
            else if (co === "bl") { c.rect.x = s.x + dx; c.rect.w = s.w - dx; c.rect.h = s.h + dy; }
            else if (co === "br") { c.rect.w = s.w + dx; c.rect.h = s.h + dy; }
        }
        clampRect(); paintCrop();
        e.preventDefault();
    };
    const onUp = (e) => { if (imgComposer) imgComposer.drag = null; try { stage.releasePointerCapture(e.pointerId); } catch (_) {} };

    stage.addEventListener("pointerdown", onDown);
    stage.addEventListener("pointermove", onMove);
    stage.addEventListener("pointerup", onUp);
    stage.addEventListener("pointercancel", onUp);
    cropBox.addEventListener("pointerdown", onDown);
}

function exportComposedImage() {
    return new Promise((resolve) => {
        const c = imgComposer;
        const img = el("imgsend-img");
        const natW = img.naturalWidth, natH = img.naturalHeight;
        let sx = 0, sy = 0, sw = natW, sh = natH;

        if (c.cropOn && c.rect && c.dispW && c.dispH) {
            const scaleX = natW / c.dispW, scaleY = natH / c.dispH;
            sx = Math.round(c.rect.x * scaleX); sy = Math.round(c.rect.y * scaleY);
            sw = Math.round(c.rect.w * scaleX); sh = Math.round(c.rect.h * scaleY);
        }

        const MAX = PHOTO_MAX_SIDE;
        let outW = sw, outH = sh;
        if (Math.max(sw, sh) > MAX) {
            const k = MAX / Math.max(sw, sh);
            outW = Math.round(sw * k); outH = Math.round(sh * k);
        }
        const canvas = document.createElement("canvas");
        canvas.width = outW; canvas.height = outH;
        const ctx = canvas.getContext("2d");
        ctx.imageSmoothingQuality = "high";
        try { ctx.drawImage(img, sx, sy, sw, sh, 0, 0, outW, outH); } catch (_) {}
        const mime = supportsWebP() ? "image/webp" : "image/jpeg";
        const ext = mime === "image/webp" ? "webp" : "jpg";
        canvas.toBlob((blob) => {
            if (!blob) { resolve(null); return; }
            const f = new File([blob], `photo_${Date.now()}.${ext}`, { type: mime });
            f.__w = outW; f.__h = outH;
            resolve(f);
        }, mime, PHOTO_QUALITY);
    });
}

async function doSendImage() {
    if (!imgComposer) return;
    const caption = el("imgsend-caption").value.trim();
    const btn = el("imgsend-send");
    btn.disabled = true; btn.textContent = "Отправка…";
    try {
        const file = await exportComposedImage();
        closeImageComposer();
        if (!file) { toast("Не удалось обработать фото", true); return; }

        const prog = showUploadProgress("Загрузка (фото)");
        try {
            const url = await uploadToBucket(CFG.MEDIA_BUCKET, file, state.activeChatId, (p) => prog.update(p));
            prog.finish();
            enqueueMessage({
                media_url: url, media_type: "image", text: caption || null,
                media_meta: { size: file.size, w: file.__w, h: file.__h }
            });
        } catch (err) { console.error(err); prog.fail(errRu(err)); }
    } finally {
        btn.disabled = false; btn.textContent = "Отправить";
    }
}

/* ---- Голосовые сообщения ---- */
function setupRecorderControls() {
    el("mic-btn").addEventListener("click", startRecording);
    el("recording-cancel").addEventListener("click", () => stopRecording(false));
    el("recording-send").addEventListener("click", () => stopRecording(true));
}

async function startRecording() {
    if (!state.activeChatId) return;
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia || !window.MediaRecorder) {
        toast("Запись голоса недоступна на этом устройстве", true);
        return;
    }
    // В Android WebView активный AudioContext занимает аудиоподсистему,
    // и микрофон не открывается — на время записи его приостанавливаем.
    try { if (audioCtx && audioCtx.state === "running") await audioCtx.suspend(); } catch (_) {}

    let stream = null, micErr = null;
    const micVariants = [
        { audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false } },
        { audio: true },
    ];
    for (let i = 0; i < micVariants.length && !stream; i++) {
        try { stream = await navigator.mediaDevices.getUserMedia(micVariants[i]); }
        catch (err) {
            micErr = err;
            if (err.name === "NotReadableError" || err.name === "AbortError") { await sleep(500); continue; }
            break;
        }
    }
    if (!stream) {
        try { if (audioCtx && audioCtx.state === "suspended") audioCtx.resume(); } catch (_) {}
        toast(micErr && micErr.name === "NotAllowedError"
            ? "Доступ к микрофону запрещён. Разрешите его в настройках."
            : "Не удалось получить доступ к микрофону. Попробуйте ещё раз.", true, 4500);
        return;
    }

    try {
        // Opus с низким битрейтом: минута голосового ≈ 180 КБ вместо 1 МБ.
        const mime = MediaRecorder.isTypeSupported("audio/webm;codecs=opus") ? "audio/webm;codecs=opus"
                   : MediaRecorder.isTypeSupported("audio/webm") ? "audio/webm"
                   : MediaRecorder.isTypeSupported("audio/mp4") ? "audio/mp4" : "";
        const mr = new MediaRecorder(stream, mime ? { mimeType: mime, audioBitsPerSecond: 24000 } : undefined);
        const chunks = [];
        mr.ondataavailable = (e) => { if (e.data.size) chunks.push(e.data); };
        mr.onstop = () => {
            stream.getTracks().forEach(t => t.stop());
            try { if (audioCtx && audioCtx.state === "suspended") audioCtx.resume(); } catch (_) {}
            clearInterval(state.recorder.interval);
            hide(el("recording-bar"));
            show(el("composer"));
            const secs = state.recorder.seconds;
            if (state.recorder.send && chunks.length && secs >= 1) {
                const blob = new Blob(chunks, { type: mime || "audio/webm" });
                const ext = (mime || "audio/webm").includes("mp4") ? "m4a" : "webm";
                const file = new File([blob], `voice_${Date.now()}.${ext}`, { type: blob.type });
                uploadVoice(file, secs);
            } else if (state.recorder.send) {
                toast("Слишком коротко — удерживайте запись дольше", true);
            }
            state.recorder = null;
            broadcastTyping(false, "voice");
        };

        state.recorder = { mr, stream, chunks, send: false, seconds: 0, interval: null };
        mr.start();
        broadcastTyping(true, "voice");

        hide(el("composer"));
        show(el("recording-bar"));
        el("recording-time").textContent = "0:00";
        state.recorder.interval = setInterval(() => {
            state.recorder.seconds++;
            el("recording-time").textContent = fmtDuration(state.recorder.seconds);
            if (state.recorder.seconds >= 300) stopRecording(true);
        }, 1000);
    } catch (err) {
        console.error(err);
        try { stream.getTracks().forEach(t => t.stop()); } catch (_) {}
        try { if (audioCtx && audioCtx.state === "suspended") audioCtx.resume(); } catch (_) {}
        toast("Не удалось начать запись голоса", true);
    }
}

function stopRecording(send) {
    if (!state.recorder) return;
    state.recorder.send = send;
    if (state.recorder.mr.state !== "inactive") state.recorder.mr.stop();
}

async function uploadVoice(file, seconds) {
    const prog = showUploadProgress("Отправка голосового");
    try {
        const url = await uploadToBucket(CFG.MEDIA_BUCKET, file, state.activeChatId, (p) => prog.update(p));
        prog.finish();
        enqueueMessage({ media_url: url, media_type: "voice", media_meta: { duration: seconds, size: file.size } });
    } catch (err) { console.error(err); prog.fail(errRu(err)); }
}

function setupVoicePlayer(container) {
    const url = container.dataset.voice;
    const playBtn = container.querySelector("[data-vplay]");
    const wave = container.querySelector("[data-vwave]");
    const timeEl = container.querySelector("[data-vtime]");
    const speedBtn = container.querySelector("[data-vspeed]");
    const bars = Array.from(wave.children);
    const audio = new Audio(url);
    audio.preload = "none";
    let ready = false;

    const icoPlay = `<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>`;
    const icoPause = `<svg viewBox="0 0 24 24"><path d="M6 5h4v14H6zM14 5h4v14h-4z"/></svg>`;

    audio.addEventListener("loadedmetadata", () => {
        ready = true;
        if (isFinite(audio.duration)) timeEl.textContent = fmtDuration(audio.duration);
    });
    audio.addEventListener("timeupdate", () => {
        const pct = audio.currentTime / (audio.duration || 1);
        const upto = Math.floor(pct * bars.length);
        bars.forEach((b, i) => b.classList.toggle("played", i <= upto));
        timeEl.textContent = fmtDuration(audio.currentTime);
    });
    audio.addEventListener("ended", () => {
        playBtn.innerHTML = icoPlay;
        bars.forEach(b => b.classList.remove("played"));
        if (isFinite(audio.duration)) timeEl.textContent = fmtDuration(audio.duration);
    });

    playBtn.addEventListener("click", () => {
        document.querySelectorAll("audio").forEach(a => { if (a !== audio) a.pause(); });
        if (audio.paused) { audio.play().catch(() => toast("Не удалось воспроизвести", true)); playBtn.innerHTML = icoPause; }
        else { audio.pause(); playBtn.innerHTML = icoPlay; }
    });

    if (speedBtn) speedBtn.addEventListener("click", () => {
        const rates = [1, 1.5, 2];
        const next = rates[(rates.indexOf(audio.playbackRate) + 1) % rates.length];
        audio.playbackRate = next;
        speedBtn.textContent = next + "×";
    });

    wave.addEventListener("click", (e) => {
        if (!ready || !isFinite(audio.duration)) return;
        const rect = wave.getBoundingClientRect();
        audio.currentTime = ((e.clientX - rect.left) / rect.width) * audio.duration;
    });
}

/* ------------------------------------------------------------------ *
 *  12. ДЕЙСТВИЯ НАД СООБЩЕНИЯМИ
 * ------------------------------------------------------------------ */
let ctxMessageId = null;

function openContextMenu(msgId, x, y) {
    const m = state.messages.find(z => z.id === msgId);
    if (!m || m.system_kind) return;
    if (state.selectMode) { toggleSelect(msgId); return; }

    ctxMessageId = msgId;
    const menu = el("context-menu");
    const mine = m.sender_id === state.user.id;
    const entry = activeEntry();
    const canWrite = !(entry && (entry.blocked_by_me || entry.blocked_me));
    const isGroupAdmin = entry && entry.is_group && entry.my_role === "admin";

    menu.querySelector(".context-reactions").innerHTML =
        REACTION_EMOJIS.map(e => `<button data-emoji="${e}">${e}</button>`).join("");

    menu.querySelector(".context-actions").innerHTML = `
        ${canWrite ? `<li data-action="reply">↩️ Ответить</li>` : ""}
        ${mine && m.text && !m._pending ? `<li data-action="edit">✏️ Изменить</li>` : ""}
        <li data-action="forward">↪️ Переслать</li>
        <li data-action="pin">📌 ${m.is_pinned ? "Открепить" : "Закрепить"}</li>
        ${m.text ? `<li data-action="copy">📋 Копировать текст</li>` : ""}
        ${m.media_url ? `<li data-action="download">⬇️ Сохранить файл</li>` : ""}
        ${(mine && entry && entry.is_group) ? `<li data-action="readby">👁 Кто прочитал</li>` : ""}
        <li data-action="select">☑️ Выделить</li>
        ${!mine ? `<li data-action="report">🚩 Пожаловаться</li>` : ""}
        <li data-action="hide">🙈 Удалить у меня</li>
        ${(mine || isGroupAdmin) ? `<li data-action="delete" class="danger">🗑️ Удалить у всех</li>` : ""}`;

    show(menu);
    const mw = menu.offsetWidth, mh = menu.offsetHeight;
    menu.style.left = Math.max(8, Math.min(x, window.innerWidth - mw - 10)) + "px";
    menu.style.top  = Math.max(8, Math.min(y, window.innerHeight - mh - 10)) + "px";
    bindContextMenuActions();
}

function closeContextMenu() { hide(el("context-menu")); hide(el("chat-menu")); ctxMessageId = null; }

function bindContextMenuActions() {
    const menu = el("context-menu");
    menu.querySelectorAll("[data-emoji]").forEach(btn => btn.onclick = () => {
        toggleReaction(ctxMessageId, btn.dataset.emoji);
        closeContextMenu();
    });
    menu.querySelectorAll("[data-action]").forEach(li => li.onclick = async () => {
        const act = li.dataset.action;
        const id = ctxMessageId;
        closeContextMenu();
        const m = state.messages.find(x => x.id === id);
        if (!m) return;

        if (act === "reply") startReply(id);
        else if (act === "edit") startEdit(id);
        else if (act === "forward") openForwardModal(id);
        else if (act === "pin") togglePin(id, !m.is_pinned);
        else if (act === "copy") copyText(m.text || "", "Текст скопирован");
        else if (act === "download") downloadMedia(m);
        else if (act === "readby") showReadBy(m);
        else if (act === "select") { enterSelectMode(); toggleSelect(id); }
        else if (act === "report") reportMessage(m);
        else if (act === "hide") await hideMessages([id]);
        else if (act === "delete") await deleteMessages([id]);
    });
}

function setupContextMenu() {
    document.addEventListener("click", (e) => {
        const menu = el("context-menu"), cmenu = el("chat-menu");
        if (menu && !menu.contains(e.target) && !e.target.closest("[data-menu]")) hide(menu);
        if (cmenu && !cmenu.contains(e.target)) hide(cmenu);
    });
}

async function downloadMedia(m) {
    if (!m.media_url) return;
    try {
        const res = await fetch(m.media_url);
        const blob = await res.blob();
        const a = document.createElement("a");
        a.href = URL.createObjectURL(blob);
        a.download = (m.media_meta && m.media_meta.name) || ("centr_" + m.id.slice(0, 8) + "." + (blob.type.split("/")[1] || "bin"));
        document.body.appendChild(a); a.click(); a.remove();
        setTimeout(() => URL.revokeObjectURL(a.href), 3000);
        toast("Файл сохранён");
    } catch (_) { window.open(m.media_url, "_blank"); }
}

async function reportMessage(m) {
    const reason = await promptBox("Пожаловаться на сообщение", "", "Что не так? (спам, оскорбления…)", 300);
    if (reason === null) return;
    try {
        await rpc("report_user", {
            _target: m.sender_id, _message: m.id, _chat: m.chat_id,
            _reason: "message", _note: reason
        });
        toast("Жалоба отправлена администратору");
    } catch (err) { toast(errRu(err), true); }
}

// Кто из группы уже прочитал сообщение, а кто ещё нет.
async function showReadBy(m) {
    const entry = activeEntry();
    if (!entry || !entry.is_group) return;
    const mem = await loadMembers(entry.chat_id, true);
    const t = new Date(m.created_at).getTime();
    const others = (mem || []).filter(p => p.user_id !== state.user.id);
    const read = others.filter(p => p.last_read_at && new Date(p.last_read_at).getTime() >= t);
    const unread = others.filter(p => !read.includes(p));

    const line = (p) => `<div class="user-item">
        ${avatarHTML(p.avatar_url, p.username, "sm", p.user_id)}
        <div class="user-item-info">
            <div class="user-item-name">${esc(p.username || "Пользователь")}</div>
            <div class="user-item-handle">@${esc(p.handle || "")}</div>
        </div></div>`;

    el("readby-count").textContent = `${read.length} из ${others.length}`;
    el("readby-list").innerHTML =
        (read.length ? `<div class="section-label">Прочитали</div>` + read.map(line).join("") : "") +
        (unread.length ? `<div class="section-label">Ещё не прочитали</div>` + unread.map(line).join("") : "") ||
        `<div class="section-label">В группе больше никого нет</div>`;
    openModal("readby-modal");
}

/* ---- Выделение нескольких сообщений ---- */
function enterSelectMode() {
    state.selectMode = true;
    show(el("select-bar"));
    el("messenger").classList.add("select-mode");
    renderMessages();
}
function exitSelectMode() {
    state.selectMode = false;
    state.selection.clear();
    hide(el("select-bar"));
    el("messenger").classList.remove("select-mode");
    if (state.messages.length) renderMessages();
}
function toggleSelect(id) {
    if (!state.selectMode) enterSelectMode();
    if (state.selection.has(id)) state.selection.delete(id);
    else state.selection.add(id);
    if (!state.selection.size) { exitSelectMode(); return; }
    el("select-count").textContent = `${state.selection.size} ${pluralRu(state.selection.size, "сообщение", "сообщения", "сообщений")}`;
    const ids = [...state.selection];
    const allMine = ids.every(i => (state.messages.find(m => m.id === i) || {}).sender_id === state.user.id);
    el("sel-delete-all").classList.toggle("hidden", !allMine);
    renderMessages();
}

function setupSelectBar() {
    el("select-cancel").addEventListener("click", exitSelectMode);
    el("sel-copy").addEventListener("click", () => {
        const ids = [...state.selection];
        const txt = state.messages.filter(m => ids.includes(m.id))
            .map(m => {
                const who = m.sender_id === state.user.id ? "Вы" : (state.profilesCache[m.sender_id]?.username || "");
                return `[${fmtTime(m.created_at)}] ${who}: ${snippetForMessage(m)}`;
            }).join("\n");
        copyText(txt, "Скопировано");
        exitSelectMode();
    });
    el("sel-forward").addEventListener("click", () => {
        const ids = [...state.selection];
        openForwardModal(ids);
    });
    el("sel-delete-me").addEventListener("click", async () => {
        const ids = [...state.selection];
        await hideMessages(ids);
        exitSelectMode();
    });
    el("sel-delete-all").addEventListener("click", async () => {
        const ids = [...state.selection];
        await deleteMessages(ids);
        exitSelectMode();
    });
}

/* ---- Удаление: физическое, без следов ---- */
async function deleteMessages(ids) {
    if (!ids || !ids.length) return;
    const ok = await confirmBox(
        ids.length > 1 ? `Удалить ${ids.length} ${pluralRu(ids.length, "сообщение", "сообщения", "сообщений")}?` : "Удалить сообщение?",
        "Удалится у всех участников безвозвратно. Пометки «сообщение удалено» не останется.",
        "Удалить у всех");
    if (!ok) return;
    try {
        const res = await rpc("delete_messages", { _ids: ids });
        // Подчищаем и файлы, чтобы не занимали место в хранилище.
        removeStorageByUrl((res || []).map(r => r.media_url));
        ids.forEach(id => {
            state.messages = state.messages.filter(m => m.id !== id);
            state.pinned = (state.pinned || []).filter(m => m.id !== id);
            removeMessageNode(id);
            delete state.reactionsByMsg[id];
        });
        renderPinnedBar();
        if (!state.messages.length) renderMessages();
        cacheSaveMessages(state.activeChatId, state.messages);
        refreshChatsSoon();
    } catch (err) { toast(errRu(err), true); }
}

async function hideMessages(ids) {
    if (!ids || !ids.length) return;
    const ok = await confirmBox(
        ids.length > 1 ? `Скрыть ${ids.length} сообщ.?` : "Удалить у меня?",
        "Сообщение исчезнет только у вас, у собеседника останется.", "Удалить у меня");
    if (!ok) return;
    try {
        await rpc("hide_messages", { _ids: ids });
        ids.forEach(id => {
            state.messages = state.messages.filter(m => m.id !== id);
            removeMessageNode(id);
        });
        if (!state.messages.length) renderMessages();
        cacheSaveMessages(state.activeChatId, state.messages);
        refreshChatsSoon();
    } catch (err) { toast(errRu(err), true); }
}

/* ---- Реакции ---- */
async function toggleReaction(msgId, emoji) {
    if (!msgId || String(msgId).startsWith("temp_")) return;
    const existing = (state.reactionsByMsg[msgId] || []).find(r => r.user_id === state.user.id);
    // Мгновенно перерисовываем, не дожидаясь ответа сервера.
    const arr = state.reactionsByMsg[msgId] || (state.reactionsByMsg[msgId] = []);
    const removing = existing && existing.emoji === emoji;
    state.reactionsByMsg[msgId] = arr.filter(r => r.user_id !== state.user.id);
    if (!removing) state.reactionsByMsg[msgId].push({ id: "tmp", message_id: msgId, user_id: state.user.id, emoji });
    const m = state.messages.find(x => x.id === msgId);
    if (m) replaceMessageNode(msgId, m);
    vibrate(15);

    try {
        if (removing) {
            await query(() => sb.from("message_reactions").delete().eq("message_id", msgId).eq("user_id", state.user.id));
        } else {
            await query(() => sb.from("message_reactions").upsert(
                { message_id: msgId, user_id: state.user.id, emoji },
                { onConflict: "message_id,user_id" }));
        }
        await refreshReactions(msgId);
    } catch (err) { toast(errRu(err), true); await refreshReactions(msgId); }
}

async function refreshReactions(msgId) {
    try {
        const data = await query(() => sb.from("message_reactions").select("*").eq("message_id", msgId));
        state.reactionsByMsg[msgId] = data || [];
        const m = state.messages.find(x => x.id === msgId);
        if (m) replaceMessageNode(msgId, m);
    } catch (_) {}
}

/* ---- Ответ и редактирование ---- */
function startReply(msgId) {
    const m = state.messages.find(x => x.id === msgId);
    if (!m) return;
    cancelEdit();
    state.replyTo = m;
    updateReplyPreview();
    el("message-input").focus();
}

function updateReplyPreview() {
    const box = el("reply-preview");
    if (!state.replyTo) { hide(box); return; }
    const m = state.replyTo;
    const name = m.sender_id === state.user.id ? "Вы" : (state.profilesCache[m.sender_id]?.username || "Пользователь");
    el("reply-preview-name").textContent = name;
    el("reply-preview-text").textContent = clip(snippetForMessage(m), 60);
    show(box);
}

function startEdit(msgId) {
    const m = state.messages.find(x => x.id === msgId);
    if (!m || m.sender_id !== state.user.id || !m.text) return;
    state.replyTo = null; updateReplyPreview();
    state.editing = m;
    updateEditPreview();
    const input = el("message-input");
    input.value = m.text;
    input.dispatchEvent(new Event("input"));
    input.focus();
    try { input.setSelectionRange(input.value.length, input.value.length); } catch (_) {}
}

function updateEditPreview() {
    const box = el("edit-preview");
    if (!box) return;
    if (!state.editing) { hide(box); return; }
    el("edit-preview-text").textContent = clip(state.editing.text, 70);
    show(box);
}

function cancelEdit(clearInput) {
    if (!state.editing) return;
    state.editing = null;
    updateEditPreview();
    if (clearInput) {
        const input = el("message-input");
        input.value = "";
        input.dispatchEvent(new Event("input"));
    }
}

async function commitEdit() {
    const m = state.editing;
    if (!m) return;
    const input = el("message-input");
    const text = input.value.trim();
    if (!text) { toast("Сообщение н�� может быть пустым", true); return; }
    if (text === m.text) { cancelEdit(true); return; }
    try {
        await rpc("edit_message", { _id: m.id, _text: text });
        const idx = state.messages.findIndex(x => x.id === m.id);
        if (idx >= 0) {
            state.messages[idx] = { ...state.messages[idx], text, edited_at: new Date().toISOString() };
            replaceMessageNode(m.id, state.messages[idx]);
        }
        cancelEdit(true);
        toast("Сообщение изменено");
        cacheSaveMessages(state.activeChatId, state.messages);
        refreshChatsSoon();
    } catch (err) { toast(errRu(err), true); }
}

async function togglePin(msgId, pin) {
    try {
        await rpc("pin_message", { _id: msgId, _pin: !!pin });
        const m = state.messages.find(x => x.id === msgId);
        if (m) {
            m.is_pinned = !!pin;
            m.pinned_at = pin ? new Date().toISOString() : null;
            replaceMessageNode(msgId, m);
        }
        state.pinnedIndex = 0;
        await loadPinned(state.activeChatId);
        toast(pin ? "Сообщение закреплено" : "Сообщение откреплено");
    } catch (err) { toast(errRu(err), true); }
}

/* ---- Пересылка (одно или несколько сообщений) ---- */
const forwardSelection = new Map();
const forwardCandidates = new Map();
let forwardSourceIds = [];

function forwardTargets() {
    const targets = [];
    state.chats.forEach(e => {
        targets.push({
            key: "chat:" + e.chat_id, type: "chat", chatId: e.chat_id,
            title: chatTitleOf(e), url: chatAvatarOf(e),
            handle: e.is_group ? "" : (e.other_handle || ""),
            isGroup: !!e.is_group, avatarKey: chatAvatarKey(e)
        });
    });
    const directIds = new Set(state.chats.filter(e => !e.is_group && e.other_id).map(e => e.other_id));
    state.friends.forEach(p => {
        if (!directIds.has(p.user_id)) {
            targets.push({ key: "user:" + p.user_id, type: "user", userId: p.user_id,
                           title: p.username, url: p.avatar_url, handle: p.handle || "",
                           isGroup: false, avatarKey: p.user_id });
        }
    });
    return targets;
}

function openForwardModal(msgIdOrIds) {
    const ids = Array.isArray(msgIdOrIds) ? msgIdOrIds : [msgIdOrIds];
    const msgs = state.messages.filter(m => ids.includes(m.id));
    if (!msgs.length) return;
    forwardSourceIds = ids;
    state.sharePayload = null;
    forwardSelection.clear(); forwardCandidates.clear();
    el("forward-search").value = "";
    el("forward-chips").innerHTML = "";
    el("forward-send").disabled = true;
    el("forward-send").textContent = "Переслать";
    const first = msgs[0];
    const who = first.sender_id === state.user.id ? "Вы" : (state.profilesCache[first.sender_id]?.username || "Пользователь");
    el("forward-preview").innerHTML = msgs.length > 1
        ? `<div class="fp-name">${msgs.length} ${pluralRu(msgs.length, "сообщение", "сообщения", "сообщений")}</div><div class="fp-text">Выберите, куда переслать</div>`
        : `<div class="fp-name">${esc(who)}</div><div class="fp-text">${esc(clip(snippetForMessage(first), 90))}</div>`;
    openModal("forward-modal");
    renderForwardTargets(forwardTargets());
    el("forward-search").focus();
}

function openShareModal(payload) {
    if (!payload) return;
    forwardSourceIds = [];
    state.sharePayload = payload;
    state.pendingShare = null;
    forwardSelection.clear(); forwardCandidates.clear();
    el("forward-search").value = "";
    el("forward-chips").innerHTML = "";
    el("forward-send").disabled = true;
    el("forward-send").textContent = "Отправить";
    el("forward-preview").innerHTML = payload.kind === "image"
        ? `<div class="fp-name">📷 Фото</div><div class="fp-text">Выберите, кому отправить</div>`
        : `<div class="fp-name">✉️ Сообщение</div><div class="fp-text">${esc(clip(payload.text, 90))}</div>`;
    switchSidebarTab("chats");
    openModal("forward-modal");
    renderForwardTargets(forwardTargets());
    el("forward-search").focus();
}

function renderForwardTargets(targets) {
    const box = el("forward-list");
    targets.forEach(t => forwardCandidates.set(t.key, t));
    if (!targets.length) { box.innerHTML = `<div class="section-label">Ничего не найдено</div>`; return; }
    box.innerHTML = targets.map(t => {
        const sel = forwardSelection.has(t.key) ? " selected" : "";
        const sub = t.handle ? "@" + esc(t.handle) : (t.isGroup ? "группа" : "чат");
        return `<div class="user-item${sel}" data-fwd="${esc(t.key)}">
            ${avatarHTML(t.url, t.title, "sm", t.avatarKey)}
            <div class="user-item-info">
                <div class="user-item-name">${esc(t.title)}</div>
                <div class="user-item-handle">${sub}</div>
            </div>
            <div class="user-item-check">✓</div>
        </div>`;
    }).join("");
    box.querySelectorAll("[data-fwd]").forEach(node => node.addEventListener("click", () => {
        const key = node.dataset.fwd;
        if (forwardSelection.has(key)) forwardSelection.delete(key);
        else forwardSelection.set(key, forwardCandidates.get(key));
        node.classList.toggle("selected");
        renderForwardChips();
    }));
}

function renderForwardChips() {
    const chips = el("forward-chips");
    chips.innerHTML = [...forwardSelection.values()].map(t =>
        `<span class="chip">${esc(t.title)}<button data-fwdremove="${esc(t.key)}">✕</button></span>`).join("");
    chips.querySelectorAll("[data-fwdremove]").forEach(b => b.addEventListener("click", () => {
        forwardSelection.delete(b.dataset.fwdremove);
        renderForwardChips();
        const node = document.querySelector(`[data-fwd="${CSS.escape(b.dataset.fwdremove)}"]`);
        node && node.classList.remove("selected");
    }));
    el("forward-send").disabled = forwardSelection.size < 1;
}

function setupForward() {
    el("forward-search").addEventListener("input", debounce(async () => {
        const term = el("forward-search").value.trim();
        let targets = forwardTargets();
        if (term) {
            const q = term.toLowerCase().replace(/^@+/, "");
            targets = targets.filter(t => t.title.toLowerCase().includes(q) || (t.handle || "").toLowerCase().includes(q));
            const users = await searchProfiles(term);
            const existing = new Set(targets.map(t => t.key));
            const directIds = new Set(state.chats.filter(e => !e.is_group && e.other_id).map(e => e.other_id));
            users.forEach(u => {
                const key = "user:" + u.id;
                if (!existing.has(key) && !directIds.has(u.id)) {
                    targets.push({ key, type: "user", userId: u.id, title: u.username,
                                   url: u.avatar_url, handle: u.handle || "", isGroup: false, avatarKey: u.id });
                }
            });
        }
        renderForwardTargets(targets);
    }, 220));
    el("forward-send").addEventListener("click", doForward);
}

async function doForward() {
    const share = state.sharePayload;
    const msgs = state.messages.filter(m => forwardSourceIds.includes(m.id));
    if ((!msgs.length && !share) || !forwardSelection.size) return;
    const btn = el("forward-send");
    const label = share ? "Отправить" : "Переслать";
    btn.disabled = true; btn.textContent = share ? "Отправляем…" : "Пересылаем…";

    let sharedImageUrl = null, lastChatId = null;
    try {
        if (share && share.kind === "image") {
            const file = dataUrlToFile(share.dataUrl, `shared_${Date.now()}.jpg`);
            if (!file) throw new Error("Не удалось прочитать изображение");
            const small = await compressImage(file);
            sharedImageUrl = await uploadToBucket(CFG.MEDIA_BUCKET, small, "shared");
        }

        for (const t of forwardSelection.values()) {
            let chatId = t.chatId;
            if (t.type === "user") chatId = await rpc("get_or_create_direct_chat", { other_user: t.userId });

            if (share) {
                enqueueMessage({
                    chat_id: chatId,
                    text: share.kind === "text" ? share.text : (share.caption || null),
                    media_url: share.kind === "image" ? sharedImageUrl : null,
                    media_type: share.kind === "image" ? "image" : null,
                    reply_to_message_id: null
                });
            } else {
                for (const src of msgs) {
                    enqueueMessage({
                        chat_id: chatId,
                        text: src.text || null,
                        media_url: src.media_url || null,
                        media_type: src.media_type || null,
                        media_meta: src.media_meta || null,
                        forwarded_from: src.forwarded_from || src.sender_id,
                        reply_to_message_id: null
                    });
                }
            }
            lastChatId = chatId;
        }

        const count = forwardSelection.size;
        state.sharePayload = null;
        closeModal("forward-modal");
        exitSelectMode();
        toast(count > 1 ? `Отправлено в ${count} ${pluralRu(count, "чат", "чата", "чатов")}` : (share ? "Отправлено" : "Переслано"));
        await flushQueue();
        await loadChats(true);
        if (lastChatId && lastChatId !== state.activeChatId) { switchSidebarTab("chats"); await openChat(lastChatId); }
    } catch (err) {
        console.error(err);
        toast(errRu(err), true);
    } finally {
        btn.disabled = false; btn.textContent = label;
    }
}

/* ------------------------------------------------------------------ *
 *  13. ПРОЧТЕНИЕ И ГАЛОЧКИ
 *      Один вызов на открытие чата — и всё. Никаких массовых UPDATE.
 * ------------------------------------------------------------------ */
const markReadThrottled = throttle((chatId) => { markChatRead(chatId); }, 1500);

async function markChatRead(chatId) {
    if (!chatId) return;
    const entry = getChatEntry(chatId);
    if (entry) {
        entry.unread = 0;
        entry.my_read_at = new Date().toISOString();
        renderChatList();
        updateGlobalBadge();
    }
    try {
        await rpc("mark_chat_read", { _chat: chatId }, { tries: 2 });
        // Сообщаем собеседнику мгновенно (не ждём, пока он обновит список).
        chatBroadcast("read", { user_id: state.user.id, read_at: new Date().toISOString() });
    } catch (err) { console.warn("mark_chat_read", err); }
}

// Пришёл сигнал «собеседник прочитал» — перекрашиваем галочки.
function applyPeerRead(chatId, userId, readAt, deliveredAt) {
    const entry = getChatEntry(chatId);
    if (!entry || userId === state.user.id) return;

    if (entry.is_group) {
        // В группе у каждого свой курсор — обновляем нужного участника,
        // чтобы «Прочитали N из M» менялось сразу.
        const mem = state.members[chatId];
        if (mem) {
            const p = mem.find(x => x.user_id === userId);
            if (p && readAt && (!p.last_read_at || new Date(readAt) > new Date(p.last_read_at))) {
                p.last_read_at = readAt;
            }
        }
        if (chatId === state.activeChatId) syncOutgoingChecks();
        return;
    }

    if (readAt && (!entry.peer_read_at || new Date(readAt) > new Date(entry.peer_read_at))) entry.peer_read_at = readAt;
    if (deliveredAt && (!entry.peer_delivered_at || new Date(deliveredAt) > new Date(entry.peer_delivered_at))) entry.peer_delivered_at = deliveredAt;
    if (chatId === state.activeChatId) syncOutgoingChecks();
    renderChatList();
}

// Перерисовать галочки у своих сообщений (без полной перерисовки ленты).
function syncOutgoingChecks() {
    const entry = activeEntry();
    if (!entry) return;
    state.messages.forEach(m => {
        if (m.sender_id !== state.user.id || m._pending || m._failed || m.system_kind) return;
        const row = document.querySelector(`[data-msg-row="${CSS.escape(String(m.id))}"] .bubble-meta .check`);
        if (!row) return;
        const wanted = outgoingStatus(m, entry);
        const isRead = row.classList.contains("read");
        const wantTitle = checkHint(m, entry);
        if ((wanted === "read") !== isRead || (wantTitle && row.getAttribute("title") !== wantTitle)) {
            replaceMessageNode(m.id, m);
        }
    });
}

/* ------------------------------------------------------------------ *
 *  14. ПРИСУТСТВИЕ («в сети» / «был(а)»)
 *      Пишем last_seen раз в 45 секунд и только когда приложение видно.
 *      «В сети» = last_seen свежее 75 секунд. Простая и честная схема,
 *      которая не врёт (в отличие от прежнего presence-канала).
 *
 *      Раньше это было ДВА таймера и два запроса: «я в сети» каждые 45 с
 *      и «а собеседник?» каждые 30 с. При 1000 активных выходило около
 *      50 запросов в секунду только ради зелёной точки. Теперь один вызов
 *      heartbeat() делает и то, и другое.
 * ------------------------------------------------------------------ */
let presenceTimer = null;

async function heartbeat() {
    if (!state.user || document.visibilityState === "hidden") return;
    // Спрашиваем только про того, чей чат открыт: остальных знать не нужно.
    const entry = activeEntry();
    const ids = (entry && !entry.is_group && entry.other_id && entry.other_id !== state.user.id)
        ? [entry.other_id] : [];
    try {
        const data = await rpc("heartbeat", { _ids: ids }, { tries: 1 });
        if (!data) return;
        if (data.now) state.clockSkew = Date.now() - new Date(data.now).getTime();
        applyPresence(data.peers);
    } catch (_) {}
}

function applyPresence(peers) {
    if (!Array.isArray(peers) || !peers.length) return;
    let touched = false;
    peers.forEach(p => {
        const prof = state.profilesCache[p.user_id];
        if (prof) prof.last_seen = p.last_seen;
        state.chats.forEach(e => {
            if (e.other_id === p.user_id && e.other_last_seen !== p.last_seen) {
                e.other_last_seen = p.last_seen;
                touched = true;
            }
        });
    });
    if (touched) { updateChatHeaderStatus(); renderChatList(); }
}

/* ---- Затухание статуса ---- *
 *  heartbeat приносит новое last_seen только когда собеседник стучит.
 *  Ушёдший стучать перестаёт — его last_seen больше не меняется, а
 *  значит и перерисовывать было нечего: надпись «в сети» висела до
 *  перезагрузки страницы. Поэтому раз в 15 секунд пересчитываем
 *  статус сами: время идёт, и last_seen рано или поздно выходит за
 *  ONLINE_WINDOW. Шапка — одна строка, её обновляем всегда (заодно
 *  тикает «был(а) N мин назад»), а список чатов — только когда состав
 *  «кто в сети» действительно изменился.                                */
const PRESENCE_TICK = 15000;
let presenceTickTimer = null;
let onlineSnapshot = "";

function onlineIdsSnapshot() {
    const ids = [];
    state.chats.forEach(e => { if (isOnlineEntry(e)) ids.push(e.other_id); });
    return ids.sort().join(",");
}

function refreshPresenceView() {
    if (document.visibilityState === "hidden") return;
    updateChatHeaderStatus();
    const snap = onlineIdsSnapshot();
    if (snap === onlineSnapshot) return;
    onlineSnapshot = snap;
    renderChatList();
}

function startPresence() {
    stopPresence();
    heartbeat();
    refreshPresenceView();
    presenceTimer     = setInterval(heartbeat, PRESENCE_BEAT);
    presenceTickTimer = setInterval(refreshPresenceView, PRESENCE_TICK);
}
function stopPresence() {
    if (presenceTimer)     { clearInterval(presenceTimer);     presenceTimer = null; }
    if (presenceTickTimer) { clearInterval(presenceTickTimer); presenceTickTimer = null; }
}

/* ---- Явный «я ушёл» ---- *
 *  Сам по себе heartbeat просто перестаёт стучать, и собеседники ещё
 *  ONLINE_WINDOW (75 с) видят «в сети», а если последний heartbeat успел
 *  уйти перед закрытием — ст��тус выглядит «залипшим». Поэтому при
 *  выходе, свёртывании и закрытии отодвигаем last_seen в прошлое
 *  (функция базы go_offline).                                              */
let accessToken = null;

function currentAccessToken() {
    if (accessToken) return accessToken;
    // Резервный путь: supabase-js держит сессию в localStorage.
    try {
        const key = Object.keys(localStorage).find(k => k.startsWith("sb-") && k.endsWith("-auth-token"));
        if (!key) return null;
        const raw = JSON.parse(localStorage.getItem(key) || "null");
        return (raw && (raw.access_token || (raw.currentSession && raw.currentSession.access_token))) || null;
    } catch (_) { return null; }
}

async function markOffline() {
    if (!state.user) return;
    try { await rpc("go_offline", {}, { tries: 1 }); } catch (_) {}
}

// Закрытие страницы: обычный запрос браузер отменит, поэтому keepalive —
// такой запрос доживает до отправки уже без страницы.
function markOfflineBeacon() {
    const token = currentAccessToken();
    if (!state.user || !token) return;
    try {
        fetch(CFG.SUPABASE_URL.replace(/\/+$/, "") + "/rest/v1/rpc/go_offline", {
            method: "POST",
            keepalive: true,
            body: "{}",
            headers: {
                "content-type": "application/json",
                apikey: CFG.SUPABASE_ANON_KEY,
                authorization: "Bearer " + token
            }
        }).catch(() => {});
    } catch (_) {}
}

// Свежий статус собеседника в открытом чате (при открытии чата и возврате
// из фона). Регулярное обновление делает heartbeat выше.
async function refreshPeerPresence() {
    const entry = activeEntry();
    if (!entry || entry.is_group || !entry.other_id) return;
    try {
        const data = await rpc("heartbeat", { _ids: [entry.other_id] }, { tries: 1 });
        if (data) applyPresence(data.peers);
    } catch (_) {}
}

/* ---- «Печатает…» через broadcast канала чата ---- */
let typingSentAt = 0;
let typingStopTimer = null;

function broadcastTyping(force, kind) {
    if (!state.activeChatId) return;
    const now = Date.now();
    if (force === false) { chatBroadcast("typing", { user_id: state.user.id, typing: false, kind }); return; }
    if (force === true || now - typingSentAt > 2000) {
        typingSentAt = now;
        chatBroadcast("typing", {
            user_id: state.user.id, typing: true, kind: kind || "text",
            name: (state.profile && state.profile.username) || ""
        });
    }
    clearTimeout(typingStopTimer);
    typingStopTimer = setTimeout(stopTypingBroadcast, 3000);
}

function stopTypingBroadcast() {
    clearTimeout(typingStopTimer);
    typingSentAt = 0;
    chatBroadcast("typing", { user_id: state.user.id, typing: false });
}

function applyTyping(chatId, payload) {
    if (!payload || payload.user_id === state.user.id) return;
    if (payload.typing) {
        state.typing[chatId] = { userId: payload.user_id, name: payload.name, kind: payload.kind, until: Date.now() + 4000 };
        clearTimeout(state.typingTimers[chatId]);
        state.typingTimers[chatId] = setTimeout(() => {
            delete state.typing[chatId];
            updateChatHeaderStatus(); renderChatList();
        }, 4000);
    } else {
        delete state.typing[chatId];
        clearTimeout(state.typingTimers[chatId]);
    }
    updateChatHeaderStatus();
    renderChatList();
}

/* ------------------------------------------------------------------ *
 *  15. ДРУЗЬЯ И БЛОКИРОВКИ
 * ------------------------------------------------------------------ */
async function loadFriends() {
    try {
        const rows = await rpc("friends_overview");
        state.friends  = (rows || []).filter(r => r.kind === "friend");
        state.incoming = (rows || []).filter(r => r.kind === "incoming");
        state.outgoing = (rows || []).filter(r => r.kind === "outgoing");
        (rows || []).forEach(r => {
            state.profilesCache[r.user_id] = Object.assign(state.profilesCache[r.user_id] || {}, {
                id: r.user_id, username: r.username, handle: r.handle,
                avatar_url: r.avatar_url, status_text: r.status_text, last_seen: r.last_seen
            });
        });
        updateFriendsBadge();
        if (state.sidebarTab === "friends") renderFriends();
    } catch (err) { console.error("loadFriends", err); }
}

function updateFriendsBadge() {
    const badge = el("friends-badge");
    if (!badge) return;
    const n = state.incoming.length;
    badge.textContent = String(n);
    badge.classList.toggle("hidden", n === 0);
}

function friendStatusWith(userId) {
    if (state.friends.some(p => p.user_id === userId)) return "friends";
    if (state.incoming.some(p => p.user_id === userId)) return "incoming";
    if (state.outgoing.some(p => p.user_id === userId)) return "outgoing";
    return "none";
}

function isOnlineProfile(p) {
    const ls = p && (p.last_seen || p.other_last_seen);
    return ls ? (serverNow() - new Date(ls).getTime()) < ONLINE_WINDOW : false;
}

function renderFriends() {
    const reqBox = el("friend-requests");
    const listBox = el("friends-list");
    const label = el("friends-list-label");
    const empty = el("friends-empty");

    if (state.incoming.length) {
        reqBox.innerHTML = `<div class="section-label">Заявки в друзья (${state.incoming.length})</div>` +
            state.incoming.map(p => `
            <div class="request-item">
                <span data-openuser="${p.user_id}">${avatarHTML(p.avatar_url, p.username, "sm", p.user_id)}</span>
                <div class="user-item-info" data-openuser="${p.user_id}">
                    <div class="user-item-name">${esc(p.username)}</div>
                    <div class="user-item-handle">@${esc(p.handle || "")}</div>
                </div>
                <div class="request-actions">
                    <button class="request-accept" data-accept="${p.user_id}" title="Принять">✓</button>
                    <button class="request-decline" data-decline="${p.user_id}" title="Отклонить">✕</button>
                </div>
            </div>`).join("");
    } else reqBox.innerHTML = "";

    let friends = state.friends;
    if (state.searchTerm) {
        const q = state.searchTerm.toLowerCase();
        friends = friends.filter(p => (p.username || "").toLowerCase().includes(q) || (p.handle || "").toLowerCase().includes(q));
    }

    if (!state.friends.length) {
        label.classList.add("hidden");
        listBox.innerHTML = "";
        show(empty);
    } else {
        label.classList.remove("hidden");
        label.textContent = `Друзья · ${state.friends.length}`;
        hide(empty);
        listBox.innerHTML = friends.map(p => `
            <div class="user-item" data-friend="${p.user_id}">
                <span class="avatar">
                    ${p.avatar_url ? `<img src="${esc(p.avatar_url)}" alt="" loading="lazy">`
                                   : `<span class="avatar-fallback" style="background:${avatarTint(p.user_id)}">${esc(initials(p.username))}</span>`}
                    ${isOnlineProfile(p) ? '<span class="online-dot"></span>' : ""}
                </span>
                <div class="user-item-info">
                    <div class="user-item-name">${esc(p.username)}</div>
                    <div class="user-item-status">${isOnlineProfile(p) ? '<span class="online-text">в сети</span>' : esc(p.status_text || ("@" + (p.handle || "")))}</div>
                </div>
                <div class="user-item-action">
                    <button class="mini-btn" data-message="${p.user_id}">Написать</button>
                </div>
            </div>`).join("");
    }

    if (state.outgoing.length) {
        listBox.innerHTML += `<div class="section-label">Ожидают ответа (${state.outgoing.length})</div>` +
            state.outgoing.map(p => `
            <div class="user-item" data-friend="${p.user_id}">
                ${avatarHTML(p.avatar_url, p.username, "sm", p.user_id)}
                <div class="user-item-info">
                    <div class="user-item-name">${esc(p.username)}</div>
                    <div class="user-item-handle">@${esc(p.handle || "")}</div>
                </div>
                <div class="user-item-action"><button class="mini-btn ghost" data-cancelreq="${p.user_id}">Отменить</button></div>
            </div>`).join("");
    }

    reqBox.querySelectorAll("[data-accept]").forEach(b => b.addEventListener("click", () => respondFriendRequest(b.dataset.accept, true)));
    reqBox.querySelectorAll("[data-decline]").forEach(b => b.addEventListener("click", () => respondFriendRequest(b.dataset.decline, false)));
    reqBox.querySelectorAll("[data-openuser]").forEach(n => n.addEventListener("click", () => openUserProfile(n.dataset.openuser)));
    listBox.querySelectorAll("[data-message]").forEach(b => b.addEventListener("click", (e) => { e.stopPropagation(); startDirectChat(b.dataset.message); }));
    listBox.querySelectorAll("[data-cancelreq]").forEach(b => b.addEventListener("click", async (e) => { e.stopPropagation(); await removeFriend(b.dataset.cancelreq); }));
    listBox.querySelectorAll("[data-friend]").forEach(n => n.addEventListener("click", () => openUserProfile(n.dataset.friend)));
}

async function sendFriendRequest(userId) {
    try {
        const data = await rpc("send_friend_request", { addressee: userId });
        toast(data === "accepted" ? "Теперь вы друзья 🎉" : "Заявка отправлена");
        await loadFriends();
        return data;
    } catch (err) { toast(errRu(err), true); return null; }
}

async function respondFriendRequest(requesterId, accept) {
    try {
        await rpc("respond_friend_request", { requester: requesterId, accept });
        toast(accept ? "Заявка принята" : "Заявка отклонена");
        await loadFriends();
        if (accept) await loadChats(true);
    } catch (err) { toast(errRu(err), true); }
}

async function removeFriend(userId) {
    try {
        await rpc("remove_friend", { other: userId });
        toast("Удалено");
        await loadFriends();
    } catch (err) { toast(errRu(err), true); }
}

async function blockUser(userId) {
    const p = state.profilesCache[userId] || {};
    const ok = await confirmBox("Заблокировать?",
        `${p.username || "Пользователь"} больше не сможет вам писать и звонить. Вы также исчезнете из его друзей.`,
        "Заблокировать");
    if (!ok) return false;
    try {
        await rpc("block_user", { _id: userId });
        toast("Пользователь заблокирован");
        await Promise.all([loadFriends(), loadChats(true), loadBlocked()]);
        updateComposerAvailability();
        return true;
    } catch (err) { toast(errRu(err), true); return false; }
}

async function unblockUser(userId) {
    try {
        await rpc("unblock_user", { _id: userId });
        toast("Разблокирован");
        await Promise.all([loadChats(true), loadBlocked()]);
        updateComposerAvailability();
    } catch (err) { toast(errRu(err), true); }
}

async function loadBlocked() {
    try { state.blocked = (await rpc("blocked_list")) || []; } catch (_) { state.blocked = []; }
}

function renderBlockedList() {
    const box = el("blocked-list");
    if (!box) return;
    loadBlocked().then(() => {
        if (!state.blocked.length) {
            box.innerHTML = `<div class="section-label">Заблокированных нет</div>`;
            return;
        }
        box.innerHTML = state.blocked.map(p => `
            <div class="user-item">
                ${avatarHTML(p.avatar_url, p.username, "sm", p.user_id)}
                <div class="user-item-info">
                    <div class="user-item-name">${esc(p.username)}</div>
                    <div class="user-item-handle">@${esc(p.handle || "")}</div>
                </div>
                <div class="user-item-action"><button class="mini-btn" data-unblock="${p.user_id}">Разблокировать</button></div>
            </div>`).join("");
        box.querySelectorAll("[data-unblock]").forEach(b => b.addEventListener("click", async () => {
            await unblockUser(b.dataset.unblock);
            renderBlockedList();
        }));
    });
}

function switchSidebarTab(tab) {
    state.sidebarTab = tab;
    $$(".sidebar-tab").forEach(b => b.classList.toggle("active", b.dataset.tab === tab));
    el("panel-chats").classList.toggle("hidden", tab !== "chats");
    el("panel-friends").classList.toggle("hidden", tab !== "friends");
    el("search-input").placeholder = tab === "friends" ? "Поиск друзей…" : "Поиск чатов и сообщений…";
    if (tab === "friends") renderFriends(); else renderChatList();
}

/* ------------------------------------------------------------------ *
 *  16. ПРОФИЛИ И ИНФОРМАЦИЯ О ЧАТЕ
 * ------------------------------------------------------------------ */
async function fetchProfile(userId) {
    if (state.profilesCache[userId] && state.profilesCache[userId].username) return state.profilesCache[userId];
    try {
        const data = await query(() => sb.from("profiles")
            .select("id,username,handle,avatar_url,status_text,last_seen").eq("id", userId).maybeSingle());
        if (data) state.profilesCache[data.id] = data;
        return data;
    } catch (_) { return null; }
}

/* ---- Профиль пользователя ---- *
 *  Раньше окно показывалось только после трёх запросов подряд:
 *  профиль, присутствие и список блокировок. Пока они шли, на экране
 *  ничего не менялось — отсюда пауза почти в полторы секунды после
 *  клика по имени. Теперь окно открывается сразу с тем, что уже известно
 *  (профили собеседников лежат в кеше со списка чатов), а свежие
 *  данные дорисовываются по мере ответов сервера.                    */
function paintUserProfile(prof) {
    paintAvatar(el("up-avatar-img"), el("up-avatar-fallback"), prof.avatar_url, prof.username, prof.id);
    el("up-avatar").onclick = () => { if (prof.avatar_url) openLightbox(prof.avatar_url, "image"); };
    el("up-name").textContent = prof.username || "Пользователь";
    el("up-handle").textContent = prof.handle ? "@" + prof.handle : "";
    el("up-status").textContent = prof.status_text || "";
    el("up-link").value = profileLink(prof);
    el("up-copy").onclick = () => copyText(el("up-link").value, "Ссылка скопирована");
}

async function fillUserProfileExtras(userId) {
    // Свежий статус «в сети» — с учётом настроек приватности со��еседника.
    const presenceEl = el("up-presence");
    if (userId === state.user.id) presenceEl.textContent = "Это вы";
    else {
        presenceEl.textContent = "…";
        try {
            const data = await rpc("heartbeat", { _ids: [userId] }, { tries: 1 });
            const r = ((data && data.peers) || [])[0];
            presenceEl.textContent = !r || !r.last_seen ? "" : (r.online ? "в сети" : fmtLastSeen(r.last_seen));
            presenceEl.className = "up-presence" + (r && r.online ? " online" : "");
        } catch (_) { presenceEl.textContent = ""; }
    }

    const btnFriend = el("up-friend");
    const btnRemove = el("up-remove-friend");
    const btnMsg = el("up-message");
    const btnBlock = el("up-block");
    const btnReport = el("up-report");
    [btnFriend, btnRemove, btnMsg, btnBlock, btnReport].forEach(hide);

    if (userId !== state.user.id) {
        await loadBlocked();
        const isBlocked = state.blocked.some(b => b.user_id === userId);

        show(btnBlock);
        btnBlock.textContent = isBlocked ? "Разблокировать" : "Заблокировать";
        btnBlock.onclick = async () => {
            if (isBlocked) { await unblockUser(userId); closeModal("userprofile-modal"); }
            else { const done = await blockUser(userId); if (done) closeModal("userprofile-modal"); }
        };

        show(btnReport);
        btnReport.onclick = async () => {
            const note = await promptBox("Жалоба на пользователя", "", "Опишите проблему", 300);
            if (note === null) return;
            try { await rpc("report_user", { _target: userId, _reason: "profile", _note: note }); toast("Жалоба отправлена"); }
            catch (e) { toast(errRu(e), true); }
        };

        if (!isBlocked) {
            show(btnMsg);
            btnMsg.textContent = "Написать";
            btnMsg.onclick = () => { closeModal("userprofile-modal"); startDirectChat(userId); };

            const status = friendStatusWith(userId);
            if (status === "friends") {
                show(btnRemove);
                btnRemove.textContent = "Удалить из друзей";
                btnRemove.onclick = async () => { await removeFriend(userId); closeModal("userprofile-modal"); };
            } else if (status === "incoming") {
                show(btnFriend);
                btnFriend.disabled = false;
                btnFriend.textContent = "Принять заявку";
                btnFriend.onclick = async () => { await respondFriendRequest(userId, true); await loadChats(true); closeModal("userprofile-modal"); };
            } else if (status === "outgoing") {
                show(btnFriend);
                btnFriend.textContent = "Заявка отправлена";
                btnFriend.disabled = true;
            } else {
                show(btnFriend);
                btnFriend.disabled = false;
                btnFriend.textContent = "Добавить в друзья";
                btnFriend.onclick = async () => { await sendFriendRequest(userId); openUserProfile(userId); };
            }
        }
    }
}

async function openUserProfile(userId) {
    state.viewProfileId = userId;

    // Шаг 1. Мгновенно показываем то, что уже знаем.
    const known = state.profilesCache[userId];
    if (known && known.username) {
        state.viewProfile = known;
        paintUserProfile(known);
        openModal("userprofile-modal");
    }

    // Шаг 2. Уточняем у сервера.
    const prof = await fetchProfile(userId);
    if (state.viewProfileId !== userId) return;      // успели открыть другой
    if (!prof && !(known && known.username)) { toast("Профиль не найден", true); return; }

    const p = prof || known;
    state.viewProfile = p;
    paintUserProfile(p);
    openModal("userprofile-modal");

    // Шаг 3. Присутствие и кнопки — уже при открытом окне.
    await fillUserProfileExtras(userId);
}

async function openUserProfileByKey(key) {
    try {
        let q = sb.from("profiles").select("id,username,handle,avatar_url,status_text,last_seen");
        q = UUID_RE.test(key) ? q.eq("id", key) : q.eq("handle", normalizeHandle(key));
        const data = await query(() => q.maybeSingle());
        if (!data) { toast("Пользователь не найден", true); return; }
        state.profilesCache[data.id] = data;
        openUserProfile(data.id);
    } catch (err) { toast(errRu(err), true); }
}

/* ---- Информация о чате: участники, медиа, действия ---- */
async function openChatInfo() {
    const entry = activeEntry();
    if (!entry) return;
    if (!entry.is_group) {
        if (entry.other_id && entry.other_id !== state.user.id) { openUserProfile(entry.other_id); return; }
        openProfileModal(); return;
    }

    paintAvatar(el("gi-avatar-img"), el("gi-avatar-fallback"), entry.avatar_url, entry.name, entry.chat_id);
    el("gi-name").textContent = entry.name || "Группа";
    el("gi-count").textContent = `${entry.member_count} ${pluralMembers(Number(entry.member_count))}`;
    el("gi-link").value = groupLink(entry.chat_id);
    el("gi-copy").onclick = () => copyText(el("gi-link").value, "Ссылка скопирована");
    el("gi-add-member").onclick = () => openAddMemberModal(entry.chat_id);
    el("gi-leave").onclick = async () => {
        const ok = await confirmBox("Выйти из группы?", "Вы перестанете получать её сообщения.", "Выйти");
        if (!ok) return;
        try {
            await rpc("leave_chat", { _chat_id: entry.chat_id });
            closeModal("groupinfo-modal");
            closeActiveChat();
            await loadChats(true);
            toast("Вы вышли из группы");
        } catch (err) { toast(errRu(err), true); }
    };
    el("gi-clear").onclick = async () => {
        const ok = await confirmBox("Очистить историю у меня?", "У остальных участников сообщения останутся.", "Очистить");
        if (!ok) return;
        await rpc("clear_history", { _chat: entry.chat_id });
        state.messages = []; renderMessages();
        closeModal("groupinfo-modal");
        loadChats(true);
    };

    el("gi-avatar-input").onchange = async (e) => {
        const file = e.target.files[0];
        e.target.value = "";
        if (!file) return;
        const cropped = await openCropper(file);
        if (!cropped) return;
        try {
            const url = await uploadToBucket(CFG.AVATAR_BUCKET, cropped, "group_" + entry.chat_id);
            await query(() => sb.from("chats").update({ avatar_url: url }).eq("id", entry.chat_id));
            entry.avatar_url = url;
            paintAvatar(el("gi-avatar-img"), el("gi-avatar-fallback"), url, entry.name, entry.chat_id);
            paintAvatar(el("chat-header-avatar-img"), el("chat-header-avatar-fallback"), url, entry.name, entry.chat_id);
            renderChatList();
            toast("Аватар группы обновлён");
        } catch (err) { toast(errRu(err), true); }
    };

    el("gi-rename").onclick = async () => {
        const name = await promptBox("Название группы", entry.name || "", "Например: 9А класс", 40);
        if (!name) return;
        try {
            await query(() => sb.from("chats").update({ name }).eq("id", entry.chat_id));
            entry.name = name;
            el("gi-name").textContent = name;
            el("chat-header-name").textContent = name;
            renderChatList();
            toast("Группа переименована");
        } catch (err) { toast(errRu(err), true); }
    };

    await renderGroupMembers(entry);
    loadChatMediaGallery(entry.chat_id);
    openModal("groupinfo-modal");
}

async function renderGroupMembers(entry) {
    const box = el("gi-members");
    box.innerHTML = `<div class="section-label">Загрузка…</div>`;
    try {
        // Раньше здесь было два запроса: участники, потом профили к ним.
        const parts = await loadMembers(entry.chat_id, true);
        const iAmAdmin = (parts || []).some(p => p.user_id === state.user.id && p.role === "admin");
        entry.my_role = iAmAdmin ? "admin" : "member";
        box.innerHTML = (parts || []).map(p => {
            const prof = state.profilesCache[p.user_id] || {};
            const isMe = p.user_id === state.user.id;
            return `
            <div class="user-item">
                <span data-openuser="${p.user_id}">
                    <span class="avatar">
                        ${prof.avatar_url ? `<img src="${esc(prof.avatar_url)}" alt="" loading="lazy">`
                                          : `<span class="avatar-fallback" style="background:${avatarTint(p.user_id)}">${esc(initials(prof.username || "?"))}</span>`}
                        ${isOnlineProfile(prof) ? '<span class="online-dot"></span>' : ""}
                    </span>
                </span>
                <div class="user-item-info" data-openuser="${p.user_id}">
                    <div class="user-item-name">${esc(prof.username || "Пользователь")}${isMe ? ' <span class="gi-you">(вы)</span>' : ""}${p.role === "admin" ? ' <span class="role-tag">админ</span>' : ""}</div>
                    <div class="user-item-handle">@${esc(prof.handle || "")}</div>
                </div>
                ${(iAmAdmin && !isMe) ? `<div class="user-item-action"><button class="mini-btn ghost" data-kick="${p.user_id}">Удалить</button></div>` : ""}
            </div>`;
        }).join("");
        box.querySelectorAll("[data-openuser]").forEach(n => n.addEventListener("click", () => {
            const id = n.dataset.openuser;
            if (id !== state.user.id) openUserProfile(id);
        }));
        box.querySelectorAll("[data-kick]").forEach(b => b.addEventListener("click", async () => {
            const ok = await confirmBox("Удалить из группы?", "", "Удалить");
            if (!ok) return;
            try { await rpc("kick_member", { _chat_id: entry.chat_id, _user_id: b.dataset.kick }); await renderGroupMembers(entry); await loadChats(true); }
            catch (err) { toast(errRu(err), true); }
        }));
    } catch (err) { box.innerHTML = `<div class="section-label">Не удалось загрузить участников</div>`; }
}

async function loadChatMediaGallery(chatId) {
    const box = el("gi-media");
    if (!box) return;
    box.innerHTML = `<div class="section-label">Загрузка…</div>`;
    try {
        const rows = await rpc("chat_media", { _chat: chatId, _limit: 60, _offset: 0 });
        const imgs = (rows || []).filter(m => m.media_type === "image");
        const others = (rows || []).filter(m => m.media_type !== "image");
        if (!rows || !rows.length) { box.innerHTML = `<div class="section-label">Пока нет файлов</div>`; return; }
        box.innerHTML =
            (imgs.length ? `<div class="media-grid">` + imgs.map(m =>
                `<img src="${esc(m.media_url)}" alt="" loading="lazy" data-gal="${esc(m.media_url)}">`).join("") + `</div>` : "") +
            (others.length ? others.map(m =>
                `<div class="media-row"><a href="${esc(m.media_url)}" target="_blank" rel="noopener">
                    ${m.media_type === "voice" ? "🎤 Голосовое" : m.media_type === "audio" ? "🎵 Аудио" : "📎 Файл"}
                    <span class="muted">${fmtListTime(m.created_at)}</span></a></div>`).join("") : "");
        box.querySelectorAll("[data-gal]").forEach(i => i.addEventListener("click", () => openLightbox(i.dataset.gal, "image")));
    } catch (_) { box.innerHTML = `<div class="section-label">Не удалось загрузить</div>`; }
}

let addMemberChatId = null;
function openAddMemberModal(chatId) {
    addMemberChatId = chatId;
    el("addmember-search").value = "";
    openModal("addmember-modal");
    renderAddMemberList(state.friends.map(f => ({ id: f.user_id, username: f.username, handle: f.handle, avatar_url: f.avatar_url })));
    el("addmember-search").focus();
}

async function renderAddMemberList(users) {
    const box = el("addmember-list");
    let already = new Set();
    try {
        const parts = await query(() => sb.from("chat_participants").select("user_id").eq("chat_id", addMemberChatId));
        already = new Set((parts || []).map(p => p.user_id));
    } catch (_) {}
    const list = (users || []).filter(u => u.id !== state.user.id);
    if (!list.length) { box.innerHTML = `<div class="section-label">Никого не найдено</div>`; return; }
    box.innerHTML = list.map(u => `
        <div class="user-item">
            ${avatarHTML(u.avatar_url, u.username, "sm", u.id)}
            <div class="user-item-info">
                <div class="user-item-name">${esc(u.username)}</div>
                <div class="user-item-handle">@${esc(u.handle || "")}</div>
            </div>
            <div class="user-item-action">
                ${already.has(u.id) ? `<button class="mini-btn ghost" disabled>В группе</button>`
                                    : `<button class="mini-btn" data-add="${u.id}">Добавить</button>`}
            </div>
        </div>`).join("");
    box.querySelectorAll("[data-add]").forEach(b => b.addEventListener("click", () => addGroupMember(b.dataset.add)));
}

function setupAddMember() {
    el("addmember-search").addEventListener("input", debounce(async () => {
        const term = el("addmember-search").value.trim();
        if (!term) {
            renderAddMemberList(state.friends.map(f => ({ id: f.user_id, username: f.username, handle: f.handle, avatar_url: f.avatar_url })));
            return;
        }
        renderAddMemberList(await searchProfiles(term));
    }, 220));
}

async function addGroupMember(userId) {
    try {
        await rpc("add_group_member", { _chat_id: addMemberChatId, _user_id: userId });
        toast("Участник добавлен");
        await loadChats(true);
        const entry = getChatEntry(addMemberChatId);
        if (entry) { await renderGroupMembers(entry); el("gi-count").textContent = `${entry.member_count} ${pluralMembers(Number(entry.member_count))}`; }
        openAddMemberModal(addMemberChatId);
    } catch (err) { toast(errRu(err), true); }
}

/* ---- Вступление в группу по ссылке ---- */
async function promptJoinGroup(chatId) {
    if (isMyChat(chatId)) { openChat(chatId); return; }
    try {
        const data = await rpc("group_preview", { _chat_id: chatId });
        const g = (data || [])[0];
        if (!g) { toast("Группа не найдена", true); return; }
        paintAvatar(el("jg-avatar-img"), el("jg-avatar-fallback"), g.avatar_url, g.name, chatId);
        el("jg-name").textContent = g.name || "Группа";
        el("jg-count").textContent = `${g.member_count} ${pluralMembers(Number(g.member_count))}`;
        el("jg-join").onclick = () => joinGroup(chatId);
        openModal("joingroup-modal");
    } catch (err) { toast(errRu(err), true); }
}

async function joinGroup(chatId) {
    try {
        const id = await rpc("join_group_by_id", { _chat_id: chatId });
        closeModal("joingroup-modal");
        await loadChats(true);
        await openChat(id || chatId);
        toast("Вы вступили в группу");
    } catch (err) { toast(errRu(err), true); }
}

/* ------------------------------------------------------------------ *
 *  17. ПОИСК
 * ------------------------------------------------------------------ */
function setupSearch() {
    const input = el("search-input");
    const clear = el("search-clear");

    input.addEventListener("input", debounce(async () => {
        state.searchTerm = input.value.trim();
        clear.classList.toggle("hidden", !state.searchTerm);
        if (state.sidebarTab === "friends") { renderFriends(); return; }
        renderChatList();
        // Глобальный поиск: люди и сообщения.
        const box = el("global-results");
        if (!state.searchTerm || state.searchTerm.length < 2) { hide(box); box.innerHTML = ""; return; }
        show(box);
        box.innerHTML = `<div class="section-label">Ищем…</div>`;
        try {
            const [people, msgs] = await Promise.all([
                searchProfiles(state.searchTerm),
                rpc("search_messages", { _q: state.searchTerm, _chat: null, _limit: 20 }).catch(() => [])
            ]);
            let html = "";
            if (people.length) {
                html += `<div class="section-label">Пользователи</div>` + people.map(u => `
                    <div class="user-item" data-gopen="${u.id}">
                        ${avatarHTML(u.avatar_url, u.username, "sm", u.id)}
                        <div class="user-item-info">
                            <div class="user-item-name">${esc(u.username)}</div>
                            <div class="user-item-handle">@${esc(u.handle || "")}</div>
                        </div>
                    </div>`).join("");
            }
            if ((msgs || []).length) {
                html += `<div class="section-label">Сообщения</div>` + msgs.map(m => `
                    <div class="user-item" data-gmsg="${m.id}" data-gchat="${m.chat_id}">
                        <span class="msg-find-ico">💬</span>
                        <div class="user-item-info">
                            <div class="user-item-name">${esc(m.chat_name || "Чат")} <span class="muted">· ${fmtListTime(m.created_at)}</span></div>
                            <div class="user-item-handle">${esc(clip(m.text || "", 60))}</div>
                        </div>
                    </div>`).join("");
            }
            box.innerHTML = html || `<div class="section-label">Ничего не найдено</div>`;
            box.querySelectorAll("[data-gopen]").forEach(n => n.addEventListener("click", () => openUserProfile(n.dataset.gopen)));
            box.querySelectorAll("[data-gmsg]").forEach(n => n.addEventListener("click", async () => {
                await openChat(n.dataset.gchat);
                jumpToMessage(n.dataset.gmsg);
                clearSearch();
            }));
        } catch (_) { box.innerHTML = `<div class="section-label">Поиск не удался</div>`; }
    }, 300));

    clear.addEventListener("click", clearSearch);

    el("chat-search-btn").addEventListener("click", () => {
        const bar = el("chat-search-bar");
        bar.classList.toggle("hidden");
        if (!bar.classList.contains("hidden")) el("chat-search-input").focus();
        else { el("chat-search-input").value = ""; renderMessages(); }
    });
    el("chat-search-close").addEventListener("click", () => {
        hide(el("chat-search-bar"));
        el("chat-search-input").value = "";
        el("chat-search-hits").textContent = "";
        renderMessages();
    });
    el("chat-search-input").addEventListener("input", debounce(() => filterInChat(el("chat-search-input").value.trim()), 250));
}

function clearSearch() {
    el("search-input").value = "";
    state.searchTerm = "";
    hide(el("search-clear"));
    const box = el("global-results");
    hide(box); box.innerHTML = "";
    if (state.sidebarTab === "friends") renderFriends(); else renderChatList();
}

async function searchProfiles(term) {
    const t = String(term || "").replace(/^@+/, "").trim();
    if (t.length < 1) return [];
    try {
        const data = await rpc("search_people", { _q: t, _limit: 20 });
        (data || []).forEach(p => { state.profilesCache[p.id] = Object.assign(state.profilesCache[p.id] || {}, p); });
        return data || [];
    } catch (_) { return []; }
}

// Поиск внутри открытого чата: ищем и в загруженном, и на сервере.
async function filterInChat(term) {
    const hits = el("chat-search-hits");
    if (!term) { renderMessages(); hits.textContent = ""; return; }
    try {
        const rows = await rpc("search_messages", { _q: term, _chat: state.activeChatId, _limit: 50 });
        hits.textContent = (rows || []).length ? `${rows.length} совпадений` : "не найдено";
        const box = el("messages");
        renderMessages();
        const ids = new Set((rows || []).map(r => r.id));
        let shown = 0;
        $$("[data-msg-row]", box).forEach(row => {
            const id = row.dataset.msgRow;
            const match = ids.has(id);
            row.style.display = match ? "" : "none";
            if (match) {
                shown++;
                const b = row.querySelector(".bubble-text");
                if (b) b.innerHTML = b.innerHTML.replace(
                    new RegExp(`(${term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")})`, "ig"),
                    '<mark>$1</mark>');
            }
        });
        $$(".day-sep, .unread-sep, .load-more", box).forEach(n => n.style.display = "none");
        if (!shown && (rows || []).length) {
            // Совпадения есть, но они в неподгруженной истории.
            box.insertAdjacentHTML("afterbegin",
                `<div class="day-sep"><span>Найдено в более старых сообщениях — нажмите на результат в списке слева</span></div>`);
        }
    } catch (err) { hits.textContent = "ошибка поиска"; }
}

/* ------------------------------------------------------------------ *
 *  18. МОДАЛКИ, НАЧАЛО ЧАТА, ДИПЛИНКИ
 * ------------------------------------------------------------------ */
function openModal(id) { show(el(id)); }
function closeModal(id) { hide(el(id)); }

function userItemHTML(u) {
    return `
    <div class="user-item" data-user="${u.id}">
        ${avatarHTML(u.avatar_url, u.username, "sm", u.id)}
        <div class="user-item-info">
            <div class="user-item-name">${esc(u.username)}</div>
            <div class="user-item-handle">@${esc(u.handle || "")}</div>
        </div>
    </div>`;
}

function setupModals() {
    $$("[data-close-modal]").forEach(btn => btn.addEventListener("click", () => closeModal(btn.dataset.closeModal)));
    $$(".modal-overlay").forEach(ov => ov.addEventListener("click", (e) => { if (e.target === ov) hide(ov); }));

    el("my-avatar").addEventListener("click", openProfileModal);
    el("new-chat-btn").addEventListener("click", openNewChatModal);
    el("empty-new-chat").addEventListener("click", openNewChatModal);
    el("new-group-btn").addEventListener("click", openNewGroupModal);
    el("logout-btn").addEventListener("click", handleLogout);
    setupAccountSecurity();
    el("add-friend-btn").addEventListener("click", openAddFriendModal);

    $$(".sidebar-tab").forEach(b => b.addEventListener("click", () => switchSidebarTab(b.dataset.tab)));

    // Архив
    const arch = el("archive-row");
    if (arch) arch.addEventListener("click", () => { state.showArchived = true; renderChatList(); });
    const archBack = el("archive-back");
    if (archBack) archBack.addEventListener("click", () => { state.showArchived = false; renderChatList(); });

    // «Сохранённые сообщения»
    const saved = el("saved-btn");
    if (saved) saved.addEventListener("click", () => startDirectChat(state.user.id));

    el("chat-back-btn").addEventListener("click", closeActiveChat);
    el("reply-cancel").addEventListener("click", () => { state.replyTo = null; updateReplyPreview(); });
    el("edit-cancel").addEventListener("click", () => cancelEdit(true));

    el("chat-header-info").addEventListener("click", openChatInfo);
    el("chat-info-btn").addEventListener("click", openChatInfo);

    el("lightbox-close").addEventListener("click", closeLightbox);
    el("lightbox").addEventListener("click", (e) => { if (e.target === el("lightbox")) closeLightbox(); });
    const lbDl = el("lightbox-download");
    if (lbDl) lbDl.addEventListener("click", () => {
        const src = el("lightbox").dataset.src;
        if (src) downloadMedia({ media_url: src, id: "img" });
    });

    document.addEventListener("keydown", (e) => {
        if (e.key === "Escape") {
            $$(".modal-overlay").forEach(hide);
            closeLightbox(); closeContextMenu();
            el("emoji-picker").classList.add("hidden");
            if (state.selectMode) exitSelectMode();
        }
        // Быстрый поиск по Ctrl+K / Ctrl+F
        if ((e.ctrlKey || e.metaKey) && (e.key === "k" || e.key === "f")) {
            e.preventDefault(); el("search-input").focus(); el("search-input").select();
        }
    });
    document.addEventListener("click", (e) => {
        const picker = el("emoji-picker");
        if (!picker.classList.contains("hidden") && !picker.contains(e.target) && e.target.id !== "emoji-btn")
            picker.classList.add("hidden");
    });
    setupSelectBar();
}

/* ---- Новый чат ---- */
function openNewChatModal() {
    el("newchat-search").value = "";
    openModal("newchat-modal");
    renderNewChatFriends();
    el("newchat-search").focus();
}
function renderNewChatFriends() {
    const box = el("newchat-user-list");
    let html = `<div class="user-item" data-user="${state.user.id}">
        <span class="avatar sm"><span class="avatar-fallback" style="background:${avatarTint(state.user.id)}">🔖</span></span>
        <div class="user-item-info">
            <div class="user-item-name">Сохранённые сообщения</div>
            <div class="user-item-handle">заметки для себя</div>
        </div></div>`;
    if (!state.friends.length) {
        html += `<div class="section-label">Добавьте друзей или найдите человека по @ID</div>`;
    } else {
        html += `<div class="section-label">Друзья</div>` + state.friends.map(f =>
            userItemHTML({ id: f.user_id, username: f.username, handle: f.handle, avatar_url: f.avatar_url })).join("");
    }
    box.innerHTML = html;
    box.querySelectorAll("[data-user]").forEach(n => n.addEventListener("click", () => startDirectChat(n.dataset.user)));
}
function renderNewChatResults(users) {
    const box = el("newchat-user-list");
    if (!users.length) { box.innerHTML = `<div class="section-label">Никого не найдено по этому ID</div>`; return; }
    box.innerHTML = `<div class="section-label">Результаты</div>` + users.map(userItemHTML).join("");
    box.querySelectorAll("[data-user]").forEach(n => n.addEventListener("click", () => startDirectChat(n.dataset.user)));
}

async function startDirectChat(otherUserId) {
    try {
        const chatId = await rpc("get_or_create_direct_chat", { other_user: otherUserId });
        closeModal("newchat-modal");
        closeModal("userprofile-modal");
        clearSearch();
        switchSidebarTab("chats");
        state.showArchived = false;
        await loadChats(true);
        await openChat(chatId);
    } catch (err) { toast(errRu(err), true); }
}

function setupNewChatSearch() {
    el("newchat-search").addEventListener("input", debounce(async () => {
        const term = el("newchat-search").value.trim();
        if (!term) { renderNewChatFriends(); return; }
        renderNewChatResults(await searchProfiles(term));
    }, 220));
}

/* ---- Добавить друга ---- */
function openAddFriendModal() {
    el("addfriend-search").value = "";
    el("addfriend-results").innerHTML = "";
    el("addfriend-myid").textContent = "@" + (state.profile?.handle || "—");
    openModal("addfriend-modal");
    el("addfriend-search").focus();
}
function friendActionButton(u) {
    const s = friendStatusWith(u.id);
    if (s === "friends") return `<button class="mini-btn ghost" disabled>В друзьях</button>`;
    if (s === "outgoing") return `<button class="mini-btn ghost" disabled>Отправлено</button>`;
    if (s === "incoming") return `<button class="mini-btn" data-accept="${u.id}">Принять</button>`;
    return `<button class="mini-btn" data-add="${u.id}">Добавить</button>`;
}
function renderAddFriendResults(users) {
    const box = el("addfriend-results");
    if (!users.length) { box.innerHTML = `<div class="section-label">Никого не найдено</div>`; return; }
    box.innerHTML = users.map(u => `
        <div class="user-item">
            <span data-openuser="${u.id}" class="user-item-clickable">
                ${avatarHTML(u.avatar_url, u.username, "sm", u.id)}
                <span class="user-item-info">
                    <span class="user-item-name">${esc(u.username)}</span>
                    <span class="user-item-handle">@${esc(u.handle || "")}</span>
                </span>
            </span>
            <div class="user-item-action">${friendActionButton(u)}</div>
        </div>`).join("");
    box.querySelectorAll("[data-add]").forEach(b => b.addEventListener("click", async () => {
        await sendFriendRequest(b.dataset.add);
        renderAddFriendResults(await searchProfiles(el("addfriend-search").value.trim()));
    }));
    box.querySelectorAll("[data-accept]").forEach(b => b.addEventListener("click", async () => {
        await respondFriendRequest(b.dataset.accept, true);
        await loadChats(true);
        renderAddFriendResults(await searchProfiles(el("addfriend-search").value.trim()));
    }));
    box.querySelectorAll("[data-openuser]").forEach(n => n.addEventListener("click", () => openUserProfile(n.dataset.openuser)));
}
function setupAddFriend() {
    el("addfriend-search").addEventListener("input", debounce(async () => {
        const term = el("addfriend-search").value.trim();
        if (!term) { el("addfriend-results").innerHTML = ""; return; }
        renderAddFriendResults(await searchProfiles(term));
    }, 220));
    el("addfriend-copymine").addEventListener("click", () => copyText(profileLink(state.profile), "Ссылка скопирована"));
}

/* ---- Новая группа ---- */
const groupSelection = new Map();
function openNewGroupModal() {
    groupSelection.clear();
    el("newgroup-name").value = "";
    el("newgroup-search").value = "";
    el("newgroup-chips").innerHTML = "";
    el("newgroup-create").disabled = true;
    openModal("newgroup-modal");
    renderGroupUserList(state.friends.map(f => ({ id: f.user_id, username: f.username, handle: f.handle, avatar_url: f.avatar_url })));
}
function renderGroupUserList(users) {
    const box = el("newgroup-user-list");
    const list = (users || []).filter(u => u.id !== state.user.id);
    if (!list.length) { box.innerHTML = `<div class="section-label">Нет друзей — найдите по @ID</div>`; return; }
    box.innerHTML = list.map(u => {
        const sel = groupSelection.has(u.id) ? " selected" : "";
        return `<div class="user-item${sel}" data-guser="${u.id}">
            ${avatarHTML(u.avatar_url, u.username, "sm", u.id)}
            <div class="user-item-info"><div class="user-item-name">${esc(u.username)}</div><div class="user-item-handle">@${esc(u.handle || "")}</div></div>
            <div class="user-item-check">✓</div>
        </div>`;
    }).join("");
    box.querySelectorAll("[data-guser]").forEach(node => node.addEventListener("click", () => {
        const id = node.dataset.guser;
        if (groupSelection.has(id)) groupSelection.delete(id);
        else groupSelection.set(id, list.find(u => u.id === id) || state.profilesCache[id]);
        node.classList.toggle("selected");
        renderGroupChips();
    }));
}
function renderGroupChips() {
    const chips = el("newgroup-chips");
    chips.innerHTML = [...groupSelection.values()].map(u =>
        `<span class="chip">${esc(u.username)}<button data-remove="${u.id}">✕</button></span>`).join("");
    chips.querySelectorAll("[data-remove]").forEach(b => b.addEventListener("click", () => {
        groupSelection.delete(b.dataset.remove);
        renderGroupChips();
        const node = document.querySelector(`[data-guser="${CSS.escape(b.dataset.remove)}"]`);
        node && node.classList.remove("selected");
    }));
    el("newgroup-create").disabled = groupSelection.size < 1;
}
function setupNewGroup() {
    el("newgroup-search").addEventListener("input", debounce(async () => {
        const term = el("newgroup-search").value.trim();
        if (!term) {
            renderGroupUserList(state.friends.map(f => ({ id: f.user_id, username: f.username, handle: f.handle, avatar_url: f.avatar_url })));
            return;
        }
        renderGroupUserList(await searchProfiles(term));
    }, 220));
    el("newgroup-create").addEventListener("click", async () => {
        const name = el("newgroup-name").value.trim() || "Новая группа";
        const members = [...groupSelection.keys()];
        const btn = el("newgroup-create");
        btn.disabled = true; btn.textContent = "Создаём…";
        try {
            const id = await rpc("create_group_chat", { group_name: name, members });
            closeModal("newgroup-modal");
            switchSidebarTab("chats");
            await loadChats(true);
            await openChat(id);
            toast("Группа создана");
        } catch (err) { toast(errRu(err), true); }
        finally { btn.disabled = false; btn.textContent = "Создать группу"; }
    });
}

/* ---- Лайтбокс ---- */
function openLightbox(src, type) {
    const content = el("lightbox-content");
    content.innerHTML = type === "video"
        ? `<video src="${esc(src)}" controls autoplay></video>`
        : `<img src="${esc(src)}" alt="">`;
    el("lightbox").dataset.src = src;
    show(el("lightbox"));
}
function closeLightbox() {
    el("lightbox-content").innerHTML = "";
    hide(el("lightbox"));
}

/* ---- Диплинки ---- */
function captureDeepLink() {
    const params = new URLSearchParams(location.search);
    const u = params.get("u"), g = params.get("g"), c = params.get("c");
    if (u) state.pendingDeepLink = { type: "user", value: u };
    else if (g) state.pendingDeepLink = { type: "group", value: g };
    else if (c) state.pendingDeepLink = { type: "chat", value: c };
    if (u || g || c) history.replaceState({}, document.title, location.pathname);
}

async function runDeepLink() {
    const dl = state.pendingDeepLink;
    if (!dl) return;
    state.pendingDeepLink = null;
    if (dl.type === "user") await openUserProfileByKey(dl.value);
    else if (dl.type === "group") await promptJoinGroup(dl.value);
    else if (dl.type === "chat") await openChatDeepLink(dl.value);
}

async function openChatDeepLink(chatId) {
    if (!chatId) return;
    chatId = String(chatId);
    if (!isMyChat(chatId)) { try { await loadChats(true); } catch (_) {} }
    switchSidebarTab("chats");
    state.showArchived = false;
    await openChat(chatId);
}

function isMyChat(chatId) { return state.chats.some(e => e.chat_id === chatId); }

/* ------------------------------------------------------------------ *
 *  19. REALTIME
 *      Раньше клиент подписывался на ВСЕ изменения таблиц messages,
 *      profiles, reactions, friendships. При 100 активных пользователях
 *      одно сообщение превращалось в 100 событий, и бесплатная квота
 *      Supabase сгорала за считанные дни, а браузер захлёбывался.
 *
 *      Теперь два канала:
 *        u:<секретный ключ профиля> — только МОИ события (новое сообщение
 *                                     в любом моём чате, друзья, блокировки);
 *        c:<секретный ключ чата>    — события открытого чата (сообщения,
 *                                     реакции, «печатает», «прочитано»).
 *      Ключи знают только участники, поэтому подписаться на чужое нельзя.
 * ------------------------------------------------------------------ */
let userChannel = null;
let chatChannel = null;
let chatChannelId = null;
let reconnectAttempts = 0;
let pollTimer = null;
let bgTimer = null;

function markEvent() { state.lastEventAt = Date.now(); setConnState(true); }

function handleChannelStatus(status, which, retry, channel) {
    // removeChannel() присылает CLOSED уже снятому каналу. Раньше такой
    // «посмертный» колбэк считался обрывом связи: при каждом переключении
    // чата всплывал баннер «нет соединения» и запускалась лишняя
    // переподписка — и так по кругу. Статусы неактуальных каналов игнорируем.
    if (channel) {
        const current = which === "chat" ? chatChannel : userChannel;
        if (current !== channel) return;
    }
    if (status === "SUBSCRIBED") {
        reconnectAttempts = 0;
        setConnState(true);
        return;
    }
    if (status === "CHANNEL_ERROR" || status === "TIMED_OUT" || status === "CLOSED") {
        // Раньше упавший канал больше не восстанавливался — сообщения просто
        // перестава­ли приходить до перезагрузки страницы. Теперь переподключаемся.
        if (document.visibilityState === "hidden") return;
        reconnectAttempts++;
        const delay = Math.min(30000, 1000 * Math.pow(1.7, Math.min(reconnectAttempts, 6)));
        setConnState(false);
        setTimeout(() => { if (state.user && document.visibilityState === "visible") retry(); }, delay);
    }
}

function subscribeUserChannel() {
    if (!state.profile || !state.profile.rt_key) return;
    if (userChannel) { try { sb.removeChannel(userChannel); } catch (_) {} }
    const topic = "u:" + state.profile.rt_key;
    // Канал держим в локальной переменной: тогда его колбэк видит, что
    // именно он прислал статус, и можно отличить живой канал от снятого.
    const ch = sb.channel(topic, { config: { broadcast: { self: false } } });
    userChannel = ch;

    ch.on("broadcast", { event: "inbox" }, ({ payload }) => {
        markEvent();
        handleInbox(payload);
    });
    ch.on("broadcast", { event: "friends" }, () => { markEvent(); loadFriends(); });
    ch.on("broadcast", { event: "blocks" }, () => { markEvent(); loadChats(true); loadBlocked(); updateComposerAvailability(); });

    ch.subscribe((status) => handleChannelStatus(status, "user", subscribeUserChannel, ch));
    state.channels.user = ch;
}

function subscribeChatChannel(entry) {
    unsubscribeChatChannel();
    if (!entry || !entry.rt_key) return;
    chatChannelId = entry.chat_id;
    const topic = "c:" + entry.rt_key;
    const ch = sb.channel(topic, { config: { broadcast: { self: false } } });
    chatChannel = ch;

    ch.on("broadcast", { event: "msg_new" }, ({ payload }) => { markEvent(); handleChatMessage(payload); });
    ch.on("broadcast", { event: "msg_upd" }, ({ payload }) => { markEvent(); handleMessageUpdate(payload); });
    ch.on("broadcast", { event: "msg_del" }, ({ payload }) => { markEvent(); handleMessageDelete(payload); });
    ch.on("broadcast", { event: "react" },   ({ payload }) => { markEvent(); if (payload && payload.message_id) refreshReactions(payload.message_id); });
    ch.on("broadcast", { event: "read" },    ({ payload }) => {
        markEvent();
        if (payload) applyPeerRead(chatChannelId, payload.user_id, payload.read_at, payload.delivered_at);
    });
    ch.on("broadcast", { event: "typing" },  ({ payload }) => { markEvent(); applyTyping(chatChannelId, payload); });

    ch.subscribe((status) => handleChannelStatus(status, "chat", () => {
        const e = getChatEntry(chatChannelId);
        if (e) subscribeChatChannel(e);
    }, ch));
    state.channels.chat = ch;
}

function unsubscribeChatChannel() {
    if (chatChannel) { try { sb.removeChannel(chatChannel); } catch (_) {} }
    chatChannel = null; chatChannelId = null;
}

function chatBroadcast(event, payload) {
    if (!chatChannel) return;
    try { chatChannel.send({ type: "broadcast", event, payload: payload || {} }); } catch (_) {}
}

// Событие «в одном из моих чатов новое сообщение».
async function handleInbox(m) {
    if (!m || !m.chat_id) return;
    const mine = m.sender_id === state.user.id;

    if (!isMyChat(m.chat_id)) { await loadChats(true); return; }

    // Если чат открыт — сообщение уже пришло по каналу чата.
    if (m.chat_id === state.activeChatId) { applyIncomingToList(m, mine); return; }

    const entry = getChatEntry(m.chat_id);
    if (entry) {
        entry.last_msg_id = m.id;
        entry.last_msg_text = m.text;
        entry.last_msg_media = m.media_type;
        entry.last_msg_sender = m.sender_id;
        entry.last_msg_sender_name = m.sender_name;
        entry.last_msg_at = m.created_at;
        entry.last_msg_system = m.system_kind;
        entry.last_message_at = m.created_at;
        if (!mine && !m.system_kind) entry.unread = (entry.unread || 0) + 1;
        sortChats();
        renderChatList();
        updateGlobalBadge();
        if (!mine) {
            notifyIncoming(m, entry);
            // Помечаем «доставлено», чтобы у отправителя появилась вторая галочка.
            rpc("mark_delivered", { _chat: m.chat_id }, { tries: 1 }).catch(() => {});
        }
    } else await loadChats(true);
}

// Событие канала открытого чата.
async function handleChatMessage(m) {
    if (!m || m.chat_id !== state.activeChatId) return;
    if (state.messages.some(x => x.id === m.id)) return;

    const mine = m.sender_id === state.user.id;
    // Своё эхо: если «призрак» ещё висит — заменяем его.
    // Ищем по номеру сообщения, а не по совпадению текста: раньше при отправке
    // двух одинаковых сообщений подряд подменялось не то, которое нужно.
    if (mine) {
        const ghost = (m.client_id && state.messages.find(x => x._pending && x.client_id === m.client_id))
            || state.messages.find(x => x._pending && (x.text || null) === (m.text || null) && (x.media_url || null) === (m.media_url || null));
        if (ghost) {
            const gid = ghost.id;
            Object.assign(ghost, m, { _pending: false });
            const idx = state.messages.findIndex(x => x.id === gid);
            if (idx >= 0) state.messages[idx] = { ...m };
            replaceMessageNode(gid, m);
            applyIncomingToList(m, true);
            return;
        }
    }

    await cacheProfiles([m.sender_id, m.forwarded_from].filter(Boolean));
    const box = el("messages");
    const wasNear = box.scrollHeight - box.scrollTop - box.clientHeight < 200;

    state.messages.push(m);
    appendMessageRow(m, true);
    if (m.is_pinned) loadPinned(state.activeChatId);

    if (!mine) {
        const entry = activeEntry();
        if (document.hidden) notifyIncoming(m, entry);
        else if (state.soundEnabled) playNotifySound();
        markReadThrottled(m.chat_id);
    }
    if (wasNear || mine) { scrollMessagesToBottom(true, true); resetScrollBadge(); }
    else bumpScrollBadge();

    applyIncomingToList(m, mine);
    cacheSaveMessages(m.chat_id, state.messages);
}

// Обновить строку чата в списке (без полной перезагрузки).
function applyIncomingToList(m, mine) {
    const entry = getChatEntry(m.chat_id);
    if (!entry) return;
    entry.last_msg_id = m.id;
    entry.last_msg_text = m.text;
    entry.last_msg_media = m.media_type;
    entry.last_msg_sender = m.sender_id;
    // Имя автора: в группах перед текстом показывается «Имя: …». Раньше это
    // поле здесь не обновлялось, и после нового сообщения имя пропадало.
    entry.last_msg_sender_name = m.sender_name
        || (state.profilesCache[m.sender_id] && state.profilesCache[m.sender_id].username)
        || entry.last_msg_sender_name;
    entry.last_msg_at = m.created_at;
    entry.last_msg_system = m.system_kind;
    entry.last_message_at = m.created_at;
    if (m.chat_id === state.activeChatId) entry.unread = 0;
    sortChats();
    renderChatList();
    updateGlobalBadge();
}

function sortChats() {
    state.chats.sort((a, b) => {
        if (!!a.is_pinned !== !!b.is_pinned) return a.is_pinned ? -1 : 1;
        return new Date(b.last_msg_at || b.last_message_at || b.created_at) -
               new Date(a.last_msg_at || a.last_message_at || a.created_at);
    });
}

function handleMessageUpdate(m) {
    if (!m || m.chat_id !== state.activeChatId) return;
    const idx = state.messages.findIndex(x => x.id === m.id);
    if (idx >= 0) {
        state.messages[idx] = { ...state.messages[idx], ...m };
        replaceMessageNode(m.id, state.messages[idx]);
    }
    loadPinned(state.activeChatId);
    const entry = getChatEntry(m.chat_id);
    if (entry && entry.last_msg_id === m.id) { entry.last_msg_text = m.text; renderChatList(); }
}

function handleMessageDelete(p) {
    if (!p || !p.id) return;
    state.messages = state.messages.filter(x => x.id !== p.id);
    state.pinned = (state.pinned || []).filter(x => x.id !== p.id);
    removeMessageNode(p.id);
    renderPinnedBar();
    if (!state.messages.length && p.chat_id === state.activeChatId) renderMessages();
    cacheSaveMessages(p.chat_id, state.messages);
    refreshChatsSoon();
}

/* ---- Настройки приложения: объявление и сброс кеша ---- */
function subscribeAppSettings() {
    const ch = sb.channel("app-settings-db")
        .on("postgres_changes", { event: "UPDATE", schema: "public", table: "app_settings" }, (payload) => {
            markEvent();
            applyAppSettings(payload.new);
        })
        .subscribe();
    state.channels.appSettings = ch;
    checkAppSettings();
}

async function checkAppSettings() {
    try {
        const data = await query(() => sb.from("app_settings").select("*").eq("id", 1).maybeSingle(), { tries: 1 });
        if (data) applyAppSettings(data);
    } catch (_) {}
}

function applyAppSettings(s) {
    if (!s) return;
    state.settings = s;
    const remote = parseInt(s.asset_version, 10) || 1;
    if (remote > currentAssetVersion()) { forceRefreshApp(remote); return; }
    const bar = el("motd-bar");
    if (bar) {
        if (s.motd) { bar.textContent = s.motd; show(bar); }
        else hide(bar);
    }
}

function currentAssetVersion() { return parseInt(localStorage.getItem("centr_asset_v") || "1", 10) || 1; }

async function forceRefreshApp(newVersion) {
    try {
        localStorage.setItem("centr_asset_v", String(newVersion));
        Object.keys(localStorage).forEach(k => { if (k.indexOf("centr_chats_") === 0) localStorage.removeItem(k); });
        await cacheWipe();
        if (window.caches && caches.keys) {
            const names = await caches.keys();
            await Promise.all(names.map(n => caches.delete(n)));
        }
        // И просим service worker сбросить свой кеш оболочки.
        if (navigator.serviceWorker && navigator.serviceWorker.controller) {
            navigator.serviceWorker.controller.postMessage("centr-clear-cache");
        }
    } catch (_) {}
    if (window.CentrNative && typeof window.CentrNative.clearCache === "function") {
        try { window.CentrNative.clearCache(); return; } catch (_) {}
    }
    location.reload();
}

/* ---- Резервный опрос: если realtime молчит, тихо догружаем ---- */
function startPolling() {
    stopPolling();
    pollTimer = setInterval(async () => {
        if (!state.user || document.visibilityState !== "visible") return;
        if (Date.now() - state.lastEventAt < POLL_INTERVAL) return;
        try {
            await loadChats(true);
            await syncActiveChat();
        } catch (_) {}
    }, POLL_INTERVAL);
}
function stopPolling() { if (pollTimer) { clearInterval(pollTimer); pollTimer = null; } }

// Догрузить сообщения, появившиеся пока связи не было.
async function syncActiveChat() {
    if (!state.activeChatId) return;
    const last = state.messages.filter(m => !m._pending).slice(-1)[0];
    const after = last ? last.created_at : new Date(Date.now() - 86400000).toISOString();
    try {
        const rows = await rpc("messages_since", { _chat: state.activeChatId, _after: after }, { tries: 1 });
        const fresh = (rows || []).filter(m => !state.messages.some(x => x.id === m.id));
        if (!fresh.length) return;
        await cacheProfiles(fresh.map(m => m.sender_id));
        await loadReactionsFor(fresh);
        fresh.forEach(m => { state.messages.push(m); appendMessageRow(m, false); });
        scrollMessagesToBottom(false, true);
        markReadThrottled(state.activeChatId);
        cacheSaveMessages(state.activeChatId, state.messages);
    } catch (_) {}
}

/* ---- Экономия ресурсов: в фоне отключаем realtime ---- *
 *  Бесплатный тариф Supabase ограничивает число ОДНОВРЕМЕННЫХ подключений.
 *  Держать сокет открытым, когда приложение свёрнуто, незачем: о новых
 *  сообщениях сообщит пуш-уведомление, а при возврате мы догрузим всё
 *  пропущенное. Это в разы поднимает число ��ользователей, которые
 *  одновременно влезают в бесплатные лимиты.                            */
function handleVisibility() {
    if (!state.user) return;
    if (document.visibilityState === "hidden") {
        clearTimeout(bgTimer);
        bgTimer = setTimeout(() => {
            teardownRealtime(true);
            stopPresence();
            markOffline();   // свёрнуто больше минуты — значит, честно «не в сети»
        }, BG_DISCONNECT);
        saveDraft(state.activeChatId);
    } else {
        clearTimeout(bgTimer);
        if (!userChannel) {
            subscribeUserChannel();
            subscribeAppSettings();
            subscribeCallSignaling();
            const e = activeEntry();
            if (e) subscribeChatChannel(e);
        }
        startPresence();
        loadChats(true).then(() => { syncActiveChat(); refreshPeerPresence(); });
        flushQueue();
    }
}

function teardownRealtime(keepCallChannel) {
    Object.entries(state.channels).forEach(([k, ch]) => {
        if (keepCallChannel && k === "rtc") return;
        try { sb.removeChannel(ch); } catch (_) {}
        delete state.channels[k];
    });
    userChannel = null; chatChannel = null; chatChannelId = null;
}

/* ------------------------------------------------------------------ *
 *  20. МОСТ ДЛЯ ПРИЛОЖЕНИЯ (MAUI / Android WebView)
 * ------------------------------------------------------------------ */
async function saveDeviceToken(token, platform) {
    if (!token || !state.user) return;
    try {
        await sb.from("device_tokens").upsert(
            { user_id: state.user.id, token, platform: platform || "android", updated_at: new Date().toISOString() },
            { onConflict: "token" });
    } catch (e) { console.warn("push token", e && e.message); }
}
window.centrOnPushToken = function (token, platform) {
    window.__centrPushToken = { token, platform: platform || "android" };
    saveDeviceToken(token, platform);
};

function nativeSignal(path) {
    if (!window.__CENTR_NATIVE__) return;
    try {
        const f = document.createElement("iframe");
        f.style.display = "none";
        f.src = "centrnative://" + path;
        (document.body || document.documentElement).appendChild(f);
        setTimeout(() => { try { f.remove(); } catch (_) {} }, 0);
    } catch (_) {}
}
function notifyNativeActiveChat(chatId) { nativeSignal("activechat/" + encodeURIComponent(chatId || "")); }

window.centrOpenChat = function (chatId) {
    if (!chatId) return;
    chatId = String(chatId);
    const ready = state.user && el("messenger") && !el("messenger").classList.contains("hidden");
    if (ready) openChatDeepLink(chatId);
    else state.pendingDeepLink = { type: "chat", value: chatId };
};

function centrHandleShare(payload) {
    const ready = state.user && el("messenger") && !el("messenger").classList.contains("hidden");
    if (ready && state.chats) openShareModal(payload);
    else state.pendingShare = payload;
}
window.centrShareText = function (text) { if (text) centrHandleShare({ kind: "text", text: String(text) }); };
window.centrShareImage = function (dataUrl, mime) {
    if (dataUrl) centrHandleShare({ kind: "image", dataUrl: String(dataUrl), mime: mime || "image/jpeg" });
};

function dataUrlToFile(dataUrl, name) {
    try {
        const [head, b64] = dataUrl.split(",");
        const mime = (head.match(/data:([^;]+)/) || [])[1] || "image/jpeg";
        const bin = atob(b64);
        const arr = new Uint8Array(bin.length);
        for (let i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
        return new File([arr], name || `shared_${Date.now()}.jpg`, { type: mime });
    } catch (_) { return null; }
}

/* ================================================================== *
 *  21. ЗВОНКИ — WebRTC аудио 1-на-1
 *  Сигналинг: Supabase Realtime broadcast. Каждый слушает свой канал
 *  rtc:<своё_id>; чтобы отправить пиру — вещаем в rtc:<peer_id>.
 *  Медиа идёт напрямую между устройствами (сервер не нагружается).
 * ================================================================== */
const CALL_RING_TIMEOUT = 35000;

function staticIceServers() {
    const cfg = CFG.ICE_SERVERS;
    return (Array.isArray(cfg) && cfg.length) ? cfg.slice()
        : [{ urls: "stun:stun.l.google.com:19302" }, { urls: "stun:stun1.l.google.com:19302" }];
}

let _iceCache = null, _iceCacheAt = 0;
function callIceServers() { return (_iceCache && _iceCache.length) ? _iceCache : staticIceServers(); }

async function ensureIceServers() {
    const sub = CFG.METERED_SUBDOMAIN, key = CFG.METERED_API_KEY;
    if (_iceCache && (Date.now() - _iceCacheAt) < 50 * 60 * 1000) return _iceCache;
    let servers = staticIceServers();
    if (sub && key) {
        try {
            const r = await fetch("https://" + sub + ".metered.live/api/v1/turn/credentials?apiKey=" + encodeURIComponent(key));
            if (r.ok) {
                const list = await r.json();
                if (Array.isArray(list) && list.length) servers = servers.concat(list);
            }
        } catch (e) { console.warn("TURN fetch failed", e); }
    }
    _iceCache = servers; _iceCacheAt = Date.now();
    return _iceCache;
}

const _rtcSendChannels = {};
function _getRtcSendChannel(peerId) {
    let entry = _rtcSendChannels[peerId];
    if (entry) return entry;
    const ch = sb.channel(`rtc:${peerId}`);
    entry = { ch, ready: false, queue: [] };
    _rtcSendChannels[peerId] = entry;
    ch.subscribe((status) => {
        if (status === "SUBSCRIBED") {
            entry.ready = true;
            entry.queue.splice(0).forEach(payload => {
                try { ch.send({ type: "broadcast", event: "signal", payload }); } catch (_) {}
            });
        } else if (status === "CHANNEL_ERROR" || status === "TIMED_OUT" || status === "CLOSED") {
            try { sb.removeChannel(ch); } catch (_) {}
            if (_rtcSendChannels[peerId] === entry) delete _rtcSendChannels[peerId];
        }
    });
    return entry;
}

function rtcSend(peerId, type, extra) {
    const entry = _getRtcSendChannel(peerId);
    const payload = Object.assign(
        { type, from: state.user.id, fromName: (state.profile && state.profile.username) || "Пользователь" },
        extra || {});
    if (entry.ready) { try { entry.ch.send({ type: "broadcast", event: "signal", payload }); } catch (_) {} }
    else entry.queue.push(payload);
}

function subscribeCallSignaling() {
    if (!state.user || state.channels.rtc) return;
    const ch = sb.channel(`rtc:${state.user.id}`, { config: { broadcast: { self: false } } });
    ch.on("broadcast", { event: "signal" }, ({ payload }) => handleCallSignal(payload));
    ch.subscribe();
    state.channels.rtc = ch;
    ensureIceServers();
}

function notifyCallPush(peerId, chatId, type) {
    if (!peerId) return;
    try {
        sb.functions.invoke("push-on-call", {
            body: {
                type: type || "call", to_user: peerId, chat_id: chatId || null,
                caller_id: state.user && state.user.id,
                caller_name: (state.profile && state.profile.username) || "Пользователь",
            },
        }).catch(() => {});
    } catch (_) {}
}

function processCallIntent(intent) {
    subscribeCallSignaling();
    if (intent.action === "decline") {
        rtcSend(intent.peerId, "reject", {});
        state.autoAcceptPeer = null;
        return;
    }
    state.autoAcceptPeer = intent.peerId;
    if (state.call && state.call.role === "callee" && state.call.peerId === intent.peerId && state.call.offer && !state.call.pc) {
        state.autoAcceptPeer = null; acceptCall();
    } else rtcSend(intent.peerId, "ready", { chatId: intent.chatId });
}
function handleCallIntent(action, peerId, chatId, callId) {
    if (!peerId) return;
    const intent = { action, peerId: String(peerId), chatId: chatId || null, callId: callId || null };
    const ready = state.user && el("messenger") && !el("messenger").classList.contains("hidden");
    if (ready) processCallIntent(intent);
    else state.pendingCallIntent = intent;
}
window.centrAcceptCall  = (peerId, chatId, callId) => handleCallIntent("accept",  peerId, chatId, callId);
window.centrDeclineCall = (peerId, chatId, callId) => handleCallIntent("decline", peerId, chatId, callId);

function toggleCallButton(entry) {
    const btn = el("chat-call-btn");
    if (!btn) return;
    const can = entry && !entry.is_group && entry.other_id && entry.other_id !== state.user.id
                && !entry.blocked_by_me && !entry.blocked_me;
    btn.classList.toggle("hidden", !can);
}

function setupCalls() {
    const btn = el("chat-call-btn");
    if (btn) btn.addEventListener("click", startCall);
    const acc = el("call-accept"); if (acc) acc.addEventListener("click", acceptCall);
    const hang = el("call-hangup"); if (hang) hang.addEventListener("click", () => endCall(true));
    const mute = el("call-mute"); if (mute) mute.addEventListener("click", toggleMute);
    const spk = el("call-speaker"); if (spk) spk.addEventListener("click", toggleSpeaker);
}

function showCallUI(o) {
    paintAvatar(el("call-avatar-img"), el("call-avatar-fallback"), o.avatar, o.name, o.peerId || "");
    el("call-name").textContent = o.name || "Звонок";
    el("call-status").textContent = o.status || "";
    el("call-accept").classList.toggle("hidden", !o.incoming);
    show(el("call-overlay"));
}
function setCallStatus(t) { const s = el("call-status"); if (s) s.textContent = t; }
function hideCallUI() { hide(el("call-overlay")); el("call-accept").classList.add("hidden"); }

let _ringCtx = null, _ringTimer = null;
function startRing(kind) {
    stopRing();
    try {
        _ringCtx = new (window.AudioContext || window.webkitAudioContext)();
        const beep = () => {
            if (!_ringCtx) return;
            const o = _ringCtx.createOscillator(), g = _ringCtx.createGain();
            o.type = "sine"; o.frequency.value = 480;
            o.connect(g); g.connect(_ringCtx.destination);
            const t = _ringCtx.currentTime;
            g.gain.setValueAtTime(0.0001, t);
            g.gain.exponentialRampToValueAtTime(0.14, t + 0.05);
            g.gain.exponentialRampToValueAtTime(0.0001, t + 0.4);
            o.start(t); o.stop(t + 0.45);
        };
        beep();
        _ringTimer = setInterval(beep, kind === "in" ? 1300 : 2600);
    } catch (_) {}
}
function stopRing() {
    if (_ringTimer) { clearInterval(_ringTimer); _ringTimer = null; }
    if (_ringCtx) { try { _ringCtx.close(); } catch (_) {} _ringCtx = null; }
}

let _callTimer = null;
function startCallTimer() {
    const t0 = Date.now(); stopCallTimer();
    _callTimer = setInterval(() => {
        const s = Math.floor((Date.now() - t0) / 1000);
        setCallStatus(`${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`);
    }, 500);
}
function stopCallTimer() { if (_callTimer) { clearInterval(_callTimer); _callTimer = null; } }

async function getMic() {
    return navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }, video: false
    });
}

function createPeer(peerId) {
    const pc = new RTCPeerConnection({ iceServers: callIceServers() });
    pc.onicecandidate = (e) => {
        if (!e.candidate) return;
        if (state.call && Array.isArray(state.call.localCandidates)) state.call.localCandidates.push(e.candidate);
        rtcSend(peerId, "ice", { candidate: e.candidate });
    };
    pc.ontrack = (e) => {
        const audio = el("call-audio");
        if (audio && e.streams[0]) { audio.srcObject = e.streams[0]; audio.play().catch(() => {}); }
    };
    pc.onconnectionstatechange = () => {
        if (pc.connectionState === "connected" && state.call) setCallStatus("00:00");
        if (pc.connectionState === "failed") { toast("Связь прервалась", true); endCall(false); }
    };
    return pc;
}

function limitAudioBitrate(pc, kbps) {
    pc.getSenders().forEach(sender => {
        if (sender.track && sender.track.kind === "audio") {
            const p = sender.getParameters();
            if (!p.encodings || !p.encodings.length) p.encodings = [{}];
            p.encodings[0].maxBitrate = (kbps || 32) * 1000;
            sender.setParameters(p).catch(() => {});
        }
    });
}

async function flushPendingIce() {
    if (!state.call || !state.call.pending) return;
    for (const c of state.call.pending) {
        try { await state.call.pc.addIceCandidate(new RTCIceCandidate(c)); } catch (_) {}
    }
    state.call.pending = [];
}

async function startCall() {
    if (state.call) return;
    const entry = activeEntry();
    if (!entry || entry.is_group || !entry.other_id) { toast("Звонки только в личных чатах", true); return; }
    const peerId = entry.other_id;
    let stream;
    try { stream = await getMic(); } catch (_) { toast("Нет доступа к микрофону", true); return; }
    await ensureIceServers();
    const pc = createPeer(peerId);
    stream.getTracks().forEach(t => pc.addTrack(t, stream));
    state.call = { pc, stream, peerId, chatId: entry.chat_id, role: "caller", pending: [], localCandidates: [], muted: false };
    showCallUI({ name: entry.other_username, avatar: entry.other_avatar, status: "Звоним…", incoming: false, peerId });
    startRing("out");
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    rtcSend(peerId, "invite", { chatId: entry.chat_id, sdp: offer });
    notifyCallPush(peerId, entry.chat_id, "call");
    state.call.resend = setInterval(() => {
        if (!state.call || state.call.role !== "caller" || state.call.answered) return;
        rtcSend(peerId, "invite", { chatId: entry.chat_id, sdp: state.call.pc.localDescription || offer });
        (state.call.localCandidates || []).forEach(c => rtcSend(peerId, "ice", { candidate: c }));
    }, 2500);
    state.call.timeout = setTimeout(() => {
        if (state.call && state.call.role === "caller" && !state.call.answered) {
            rtcSend(peerId, "cancel", {}); toast("Абонент не ответил"); endCall(false);
        }
    }, CALL_RING_TIMEOUT);
}

async function handleCallSignal(msg) {
    if (!msg || !state.user || msg.from === state.user.id) return;

    if (msg.type === "invite") {
        if (state.call) {
            if (state.call.role === "callee" && state.call.peerId === msg.from && !state.call.pc) {
                state.call.offer = msg.sdp;
                if (state.autoAcceptPeer === msg.from) { state.autoAcceptPeer = null; acceptCall(); }
            } else if (state.call.peerId !== msg.from) rtcSend(msg.from, "busy", {});
            return;
        }
        // Заблокированным звонить нельзя.
        const blocked = state.blocked.some(b => b.user_id === msg.from);
        if (blocked) { rtcSend(msg.from, "reject", {}); return; }

        state.call = { peerId: msg.from, chatId: msg.chatId, role: "callee", offer: msg.sdp, pending: [], muted: false };
        const prof = state.profilesCache[msg.from] || {};
        showCallUI({ name: prof.username || msg.fromName, avatar: prof.avatar_url, status: "Входящий звонок…", incoming: true, peerId: msg.from });
        startRing("in");
        if (state.autoAcceptPeer === msg.from) { state.autoAcceptPeer = null; acceptCall(); }
        return;
    }

    if (msg.type === "ready") {
        if (state.call && state.call.role === "caller" && msg.from === state.call.peerId && !state.call.answered) {
            rtcSend(state.call.peerId, "invite", { chatId: state.call.chatId, sdp: state.call.pc.localDescription });
            (state.call.localCandidates || []).forEach(c => rtcSend(state.call.peerId, "ice", { candidate: c }));
        }
        return;
    }

    if (!state.call || msg.from !== state.call.peerId) return;

    if (msg.type === "answer") {
        state.call.answered = true;
        if (state.call.timeout) { clearTimeout(state.call.timeout); state.call.timeout = null; }
        if (state.call.resend) { clearInterval(state.call.resend); state.call.resend = null; }
        notifyCallPush(state.call.peerId, state.call.chatId, "call_cancel");
        stopRing();
        await state.call.pc.setRemoteDescription(new RTCSessionDescription(msg.sdp));
        await flushPendingIce();
        limitAudioBitrate(state.call.pc, 32);
        setCallStatus("Соединение…");
        startCallTimer();
    } else if (msg.type === "ice") {
        if (state.call.pc && state.call.pc.remoteDescription && state.call.pc.remoteDescription.type) {
            try { await state.call.pc.addIceCandidate(new RTCIceCandidate(msg.candidate)); } catch (_) {}
        } else state.call.pending.push(msg.candidate);
    } else if (msg.type === "reject") { toast("Звонок отклонён"); endCall(false); }
    else if (msg.type === "busy") { toast("Абонент занят"); endCall(false); }
    else if (msg.type === "cancel" || msg.type === "hangup") { endCall(false); }
}

async function acceptCall() {
    if (!state.call || state.call.role !== "callee") return;
    stopRing();
    let stream;
    try { stream = await getMic(); }
    catch (_) { toast("Нет доступа к микрофону", true); rtcSend(state.call.peerId, "reject", {}); endCall(false); return; }
    await ensureIceServers();
    const pc = createPeer(state.call.peerId);
    stream.getTracks().forEach(t => pc.addTrack(t, stream));
    state.call.pc = pc; state.call.stream = stream;
    await pc.setRemoteDescription(new RTCSessionDescription(state.call.offer));
    await flushPendingIce();
    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    rtcSend(state.call.peerId, "answer", { sdp: answer });
    limitAudioBitrate(pc, 32);
    el("call-accept").classList.add("hidden");
    setCallStatus("Соединение…");
    startCallTimer();
}

function toggleMute() {
    if (!state.call || !state.call.stream) return;
    state.call.muted = !state.call.muted;
    state.call.stream.getAudioTracks().forEach(t => { t.enabled = !state.call.muted; });
    const b = el("call-mute");
    b.classList.toggle("muted", state.call.muted);
    b.title = state.call.muted ? "Включить микрофон" : "Выключить микрофон";
}

function toggleSpeaker() {
    const audio = el("call-audio");
    const b = el("call-speaker");
    if (!audio) return;
    const on = !b.classList.contains("on");
    b.classList.toggle("on", on);
    // На части устройств помогает переключение громкости вывода.
    try { audio.volume = on ? 1 : 0.7; } catch (_) {}
    b.title = on ? "Громкая связь включена" : "Громкая связь выключена";
}

function endCall(notifyPeer) {
    const call = state.call;
    if (!call) { hideCallUI(); return; }
    if (notifyPeer && call.peerId) {
        if (call.role === "callee" && !call.pc) rtcSend(call.peerId, "reject", {});
        else rtcSend(call.peerId, "hangup", {});
    }
    if (call.role === "caller" && !call.answered) notifyCallPush(call.peerId, call.chatId, "call_cancel");
    if (call.resend) { clearInterval(call.resend); call.resend = null; }
    if (call.timeout) clearTimeout(call.timeout);
    stopRing(); stopCallTimer();
    try { call.pc && call.pc.close(); } catch (_) {}
    try { call.stream && call.stream.getTracks().forEach(t => t.stop()); } catch (_) {}
    const audio = el("call-audio");
    if (audio) { try { audio.srcObject = null; } catch (_) {} }
    state.call = null;
    hideCallUI();
}

/* ------------------------------------------------------------------ *
 *  22. ЗАПУСК
 * ------------------------------------------------------------------ */
function enterMessenger() {
    hide(el("splash")); hide(el("auth-screen")); hide(el("onboarding-screen"));
    show(el("messenger"));
    paintMyAvatar();

    loadQueue();
    subscribeUserChannel();
    subscribeAppSettings();
    subscribeCallSignaling();
    startPresence();
    startPolling();

    // Сначала показываем сохранённое на устройстве, потом обновляем с сервера.
    // Экран становится живым до того, как придёт ответ сервера.
    paintFromCache().then(() => bootstrap()).then(() => {
        askNotificationPermission();
    });

    if (window.__centrPushToken) saveDeviceToken(window.__centrPushToken.token, window.__centrPushToken.platform);
    if (state.pendingCallIntent) {
        const ci = state.pendingCallIntent; state.pendingCallIntent = null;
        setTimeout(() => processCallIntent(ci), 400);
    }

    const box = el("messages");
    box.addEventListener("scroll", () => {
        const far = box.scrollHeight - box.scrollTop - box.clientHeight > 300;
        if (!far) resetScrollBadge();
        el("scroll-bottom").classList.toggle("hidden", !far && (state.unseenCount || 0) === 0);
        // Дошли до верха — подгружаем более раннее.
        if (box.scrollTop < 120) loadOlderMessages();
    });
    el("scroll-bottom").addEventListener("click", () => { scrollMessagesToBottom(true, true); resetScrollBadge(); });

    setTimeout(() => {
        runDeepLink();
        if (state.pendingShare) { const p = state.pendingShare; state.pendingShare = null; openShareModal(p); }
    }, 500);
}

async function routeAfterAuth() {
    await loadMyProfile();

    if (!state.profile) {
        // Профиль создаёт триггер базы; если его почему-то нет — создаём сами.
        try {
            await sb.from("profiles").insert({ id: state.user.id, username: "user_" + state.user.id.slice(0, 5) });
        } catch (_) {}
        await loadMyProfile();
    }
    if (!state.profile) {
        showAuthError("Не удалось загрузить профиль. Проверьте интернет и обновите страницу.");
        showAuthScreen();
        return;
    }

    const onboardedFlag = localStorage.getItem("centr_onboarded_" + state.user.id);
    const firstTime = !onboardedFlag && !state.profile.avatar_url;

    if (firstTime) {
        hide(el("splash")); hide(el("auth-screen"));
        el("onboard-username").value = state.profile.username || "";
        el("onboard-status").value = state.profile.status_text || "";
        show(el("onboarding-screen"));
    } else {
        localStorage.setItem("centr_onboarded_" + state.user.id, "1");
        enterMessenger();
    }
}

function showAuthScreen() {
    hide(el("splash")); hide(el("messenger")); hide(el("onboarding-screen"));
    show(el("auth-screen"));
}

/* ---- Экранная клавиатура в мобильном WebView ---- */
function setupKeyboardViewport() {
    const vv = window.visualViewport;
    const app = el("app");
    if (!vv || !app) return;
    let raf = 0;
    const apply = () => {
        raf = 0;
        app.style.height = vv.height + "px";
        app.style.transform = vv.offsetTop ? `translateY(${vv.offsetTop}px)` : "";
        if (window.scrollX || window.scrollY) window.scrollTo(0, 0);
    };
    const schedule = () => { if (!raf) raf = requestAnimationFrame(apply); };
    vv.addEventListener("resize", schedule);
    vv.addEventListener("scroll", schedule);
    window.addEventListener("orientationchange", () => setTimeout(apply, 300));
    apply();

    const input = el("message-input");
    if (input) input.addEventListener("focus", () => setTimeout(() => scrollMessagesToBottom(false, true), 350));
}

/* ---- Установка как приложение (PWA) ----
 *  Chrome и Edge сами присылают событие «этот сайт можно установить».
 *  Раньше мы его не слушали, и предложение установки нигде не появлялось.  */
let installPrompt = null;

function setupInstallPrompt() {
    const btn = el("install-btn");
    if (!btn) return;

    window.addEventListener("beforeinstallprompt", (e) => {
        e.preventDefault();
        installPrompt = e;
        if (!window.__CENTR_NATIVE__ && localStorage.getItem("centr_install_hidden") !== "1") show(btn);
    });

    window.addEventListener("appinstalled", () => {
        installPrompt = null;
        hide(btn);
        localStorage.setItem("centr_install_hidden", "1");
        toast("Центр установлен на устройство");
    });

    btn.addEventListener("click", async () => {
        if (!installPrompt) {
            toast("В этом браузере установка делается через меню → «Установить приложение»", false, 5000);
            return;
        }
        installPrompt.prompt();
        try {
            const res = await installPrompt.userChoice;
            if (res && res.outcome === "dismissed") localStorage.setItem("centr_install_hidden", "1");
        } catch (_) {}
        installPrompt = null;
        hide(btn);
    });

    // Уже установлено — предлагать незачем.
    if (window.matchMedia && window.matchMedia("(display-mode: standalone)").matches) hide(btn);
}

function wireStaticEvents() {
    $$(".auth-tab").forEach(b => b.addEventListener("click", () => switchAuthTab(b.dataset.authtab)));
    el("login-form").addEventListener("submit", handleLogin);
    el("signup-form").addEventListener("submit", handleSignup);
    el("onboarding-form").addEventListener("submit", handleOnboarding);
    setupOnboardingAvatarPreview();
    setupProfileModal();
    setupCropper();
    setupComposer();
    setupContextMenu();
    setupCalls();
    setupSearch();
    setupModals();
    setupNewChatSearch();
    setupNewGroup();
    setupAddFriend();
    setupAddMember();
    setupForward();
    setupSound();
    setupKeyboardViewport();
    setupInstallPrompt();
    watchSystemTheme();

    window.addEventListener("online",  () => { setConnState(true);  flushQueue(); syncActiveChat(); loadChats(true); });
    window.addEventListener("offline", () => setConnState(false, "Нет интернета — сообщения отправятся позже"));

    window.addEventListener("pagehide", () => {
        if (!state.user) return;
        saveDraft(state.activeChatId);
        markOfflineBeacon();   // закрыли окно/приложение — статус честно гаснет
    });
    document.addEventListener("visibilitychange", handleVisibility);

    // Разговор со service worker'ом:
    //  • centr-open-chat — клик по уведомлению: открываем переписку
    //    без перезагрузки страницы.
    //  • centr-who — перед показом пуша worker спрашивает, что сейчас
    //    на экране. Открыт тот самый чат — шторка не нужна.
    if ("serviceWorker" in navigator) {
        navigator.serviceWorker.addEventListener("message", (e) => {
            const d = e.data;
            if (!d) return;
            if (d.type === "centr-who") {
                const port = e.ports && e.ports[0];
                if (port) port.postMessage({
                    chat_id: state.activeChatId || "",
                    visible: document.visibilityState === "visible"
                });
                return;
            }
            if (d.type === "centr-open-chat" && d.chat_id) openChat(d.chat_id);
        });
    }
}

async function main() {
    applyAppearance({});          // тема — до первой отрисовки, чтобы не мигало
    captureDeepLink();
    wireStaticEvents();

    const authHint = INITIAL_HASH + " " + (window.location.search || "");
    if (authHint.includes("type=recovery")) state.recoveryMode = true;
    if (authHint.includes("type=email_change")) setTimeout(() => toast("Почта обновлена."), 800);
    if (authHint.includes("error_description=") || authHint.includes("error=access_denied")) {
        const m = decodeURIComponent(authHint).match(/error_description=([^&\s]+)/);
        setTimeout(() => toast("Ссылка недействительна или устарела. Запросите новое письмо." +
            (m ? " (" + m[1].replace(/\+/g, " ") + ")" : ""), true, 6000), 900);
    }

    sb.auth.onAuthStateChange((event, session) => {
        accessToken = session?.access_token || null;   // нужен для keepalive-запроса при закрытии
        if (event === "PASSWORD_RECOVERY") {
            state.recoveryMode = true;
            if (session?.user) state.user = session.user;
            showRecoveryScreen();
            return;
        }
        if (session?.user) {
            const changedUser = state.user?.id !== session.user.id;
            state.user = session.user;
            if (state.recoveryMode) { showRecoveryScreen(); return; }
            if (event === "SIGNED_IN" && changedUser) routeAfterAuth();
        } else if (event === "SIGNED_OUT") {
            state.user = null;
            showAuthScreen();
        }
    });

    const { data: { session } } = await sb.auth.getSession();
    if (state.recoveryMode) {
        if (session?.user) state.user = session.user;
        showRecoveryScreen();
        return;
    }
    if (session?.user) {
        state.user = session.user;
        await routeAfterAuth();
    } else showAuthScreen();
}

if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", main);
else main();
