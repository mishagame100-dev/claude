// ============================================================================
//  ЦЕНТР 3.0 — ПУШ-УВЕДОМЛЕНИЯ О ЗВОНКАХ
//  ---------------------------------------------------------------------------
//  Вызывается самим сайтом (sb.functions.invoke("push-on-call")) в момент
//  звонка. Будит телефон собеседника, чтобы он увидел плашку «входящий
//  звонок», даже если приложение закрыто. Отдельная функция нужна потому,
//  что у звонка высокий приоритет и своё оформление.
//
//  Установка:
//    supabase functions deploy push-on-call --no-verify-jwt
//    supabase secrets set FIREBASE_SERVICE_ACCOUNT="$(cat service-account.json)"
//
//  Флаг --no-verify-jwt нужен, чтобы функция сама возвращала понятную ошибку
//  вместо глухого отказа платформы. Токен вошедшего человека мы проверяем
//  ниже сами (функция callerFromToken) — без него функция ничего не делает.
// ============================================================================

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
const SERVICE_KEY  = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
const FIREBASE_SA  = Deno.env.get("FIREBASE_SERVICE_ACCOUNT") || "";

const admin = createClient(SUPABASE_URL, SERVICE_KEY, { auth: { persistSession: false } });

const CORS = {
    "access-control-allow-origin": "*",
    "access-control-allow-headers": "authorization, x-client-info, apikey, content-type",
    "content-type": "application/json",
};

let cachedToken: { value: string; exp: number } | null = null;

function pemToBinary(pem: string): Uint8Array {
    const body = pem.replace(/-----BEGIN PRIVATE KEY-----/, "")
                    .replace(/-----END PRIVATE KEY-----/, "")
                    .replace(/\s/g, "");
    const raw = atob(body);
    const bytes = new Uint8Array(raw.length);
    for (let i = 0; i < raw.length; i++) bytes[i] = raw.charCodeAt(i);
    return bytes;
}

function b64url(data: Uint8Array | string): string {
    const bytes = typeof data === "string" ? new TextEncoder().encode(data) : data;
    let bin = "";
    bytes.forEach(b => bin += String.fromCharCode(b));
    return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

async function getFirebaseToken(): Promise<{ token: string; projectId: string } | null> {
    if (!FIREBASE_SA) return null;
    let sa: any;
    try { sa = JSON.parse(FIREBASE_SA); } catch { return null; }
    if (!sa.client_email || !sa.private_key || !sa.project_id) return null;

    const now = Math.floor(Date.now() / 1000);
    if (cachedToken && cachedToken.exp > now + 60) return { token: cachedToken.value, projectId: sa.project_id };

    const unsigned = `${b64url(JSON.stringify({ alg: "RS256", typ: "JWT" }))}.${b64url(JSON.stringify({
        iss: sa.client_email,
        scope: "https://www.googleapis.com/auth/firebase.messaging",
        aud: "https://oauth2.googleapis.com/token",
        iat: now, exp: now + 3600,
    }))}`;

    const key = await crypto.subtle.importKey("pkcs8", pemToBinary(sa.private_key),
        { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" }, false, ["sign"]);
    const sig = await crypto.subtle.sign("RSASSA-PKCS1-v1_5", key, new TextEncoder().encode(unsigned));
    const jwt = `${unsigned}.${b64url(new Uint8Array(sig))}`;

    const res = await fetch("https://oauth2.googleapis.com/token", {
        method: "POST",
        headers: { "content-type": "application/x-www-form-urlencoded" },
        body: new URLSearchParams({
            grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer", assertion: jwt,
        }),
    });
    if (!res.ok) { console.error("OAuth error", await res.text()); return null; }
    const json = await res.json();
    cachedToken = { value: json.access_token, exp: now + 3500 };
    return { token: json.access_token, projectId: sa.project_id };
}

/* ---------------------------------------------------------------------------
 *  ЗАЩИТА ФУНКЦИИ.
 *  Эту функцию зовёт не база, а сам сайт из браузера — значит, у вызова
 *  всегда есть токен вошедшего человека. Раньше токен не проверялся, а имя
 *  звонящего брали прямо из запроса. Зная адрес функции, можно было прислать
 *  кому угодно уведомление «вам звонит директор». Теперь личность звонящего
 *  берётся ИЗ ТОКЕНА, а присланному в запросе значению мы не верим.
 * ------------------------------------------------------------------------- */
async function callerFromToken(req: Request): Promise<{ id: string; name: string } | null> {
    const jwt = (req.headers.get("authorization") || "").replace(/^Bearer\s+/i, "");
    if (!jwt) return null;
    const { data, error } = await admin.auth.getUser(jwt);
    if (error || !data?.user) return null;
    const { data: prof } = await admin.from("profiles").select("username").eq("id", data.user.id).maybeSingle();
    return { id: data.user.id, name: prof?.username || "Пользователь" };
}

Deno.serve(async (req) => {
    if (req.method === "OPTIONS") return new Response("ok", { headers: CORS });

    try {
        const caller = await callerFromToken(req);
        if (!caller) {
            return new Response(JSON.stringify({ error: "нужен вход" }), { status: 401, headers: CORS });
        }

        const body = await req.json().catch(() => ({}));
        const { type, to_user, chat_id } = body || {};
        if (!to_user) return new Response(JSON.stringify({ error: "нет получателя" }), { status: 200, headers: CORS });

        // Личность звонящего — только из токена, не из тела запроса.
        const caller_id = caller.id;
        const caller_name = caller.name;

        const auth = await getFirebaseToken();
        if (!auth) return new Response(JSON.stringify({ skipped: "Firebase не настроен" }), { status: 200, headers: CORS });

        // Заблокированные звонить не могут.
        if (caller_id) {
            const { data: blk } = await admin.from("blocks").select("blocker_id")
                .eq("blocker_id", to_user).eq("blocked_id", caller_id).maybeSingle();
            if (blk) return new Response(JSON.stringify({ skipped: "заблокирован" }), { status: 200, headers: CORS });
        }

        // Мелодия, выбранная получателем в своём профиле, — её проиграет приложение.
        const { data: prof } = await admin.from("profiles").select("ringtone").eq("id", to_user).maybeSingle();

        const { data: tokens } = await admin.from("device_tokens").select("token").eq("user_id", to_user);
        if (!tokens || !tokens.length) return new Response(JSON.stringify({ sent: 0 }), { status: 200, headers: CORS });

        const payload: Record<string, string> = {
            type: type === "call_cancel" ? "call_cancel" : "call",
            ringtone: String(prof?.ringtone || "center"),
            chat_id: String(chat_id || ""),
            caller_id: String(caller_id || ""),
            caller_name: String(caller_name || "Пользователь"),
            call_id: String(caller_id || "") + "-" + String(chat_id || ""),
        };

        await Promise.all(tokens.map(async (t) => {
            const res = await fetch(`https://fcm.googleapis.com/v1/projects/${auth.projectId}/messages:send`, {
                method: "POST",
                headers: { authorization: `Bearer ${auth.token}`, "content-type": "application/json" },
                body: JSON.stringify({
                    message: {
                        token: t.token,
                        data: payload,
                        android: { priority: "high", ttl: "45s" },
                    },
                }),
            });
            if (!res.ok) {
                const text = await res.text();
                if (text.includes("UNREGISTERED") || text.includes("NOT_FOUND")) {
                    await admin.from("device_tokens").delete().eq("token", t.token);
                } else console.error("FCM call error", text.slice(0, 250));
            }
        }));

        return new Response(JSON.stringify({ sent: tokens.length }), { status: 200, headers: CORS });
    } catch (e) {
        console.error(e);
        return new Response(JSON.stringify({ error: String(e) }), { status: 200, headers: CORS });
    }
});
